import React, { useState, useEffect, useMemo } from 'react';
import { SmartDataTable } from '../../../components/ui/SmartDataTable';
import { budgetService } from '../../../services/budgetService';
import { RecurrenceRule } from '../../../types/budget';
import { ArrowPathIcon, CloudArrowDownIcon, TrashIcon, PencilSquareIcon, PlusIcon } from '@heroicons/react/24/outline';
import { RecurrenceRuleFormModal } from '../components/RecurrenceRuleFormModal';

export const BudgetRecurring: React.FC = () => {
    const [rules, setRules] = useState<RecurrenceRule[]>([]);
    const [loading, setLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedRule, setSelectedRule] = useState<RecurrenceRule | undefined>(undefined);

    const loadRules = async () => {
        setLoading(true);
        try {
            const data = await budgetService.getRecurrenceRules();
            setRules(data);
        } catch (error) {
            console.error("Error loading rules:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadRules();
    }, []);

    const handleSeed = async () => {
        if (confirm("¿Estás seguro de que deseas cargar la configuración predeterminada de gastos recurrentes? Esto añadirá nuevas reglas a las existentes.")) {
            try {
                await budgetService.seedRecurringExpenses();
                await loadRules();
                alert("Configuración cargada exitosamente.");
            } catch (error) {
                alert("Error al cargar la configuración.");
            }
        }
    };

    const handleDelete = async (id: string) => {
        if (confirm('¿Eliminar esta regla recurrente?')) {
            await budgetService.deleteRecurrenceRule(id);
            loadRules(); // Reload
        }
    };

    const handleEdit = (rule: RecurrenceRule) => {
        setSelectedRule(rule);
        setIsModalOpen(true);
    };

    const handleCreate = () => {
        setSelectedRule(undefined);
        setIsModalOpen(true);
    };

    const handleSaveRule = async (data: any) => {
        try {
            // Destructure to remove 'id' from the object sent to Firestore add/update
            // Firestore throws error if a field is explicitly 'undefined'
            const { id, ...ruleData } = data;

            if (id) {
                await budgetService.updateRecurrenceRule(id, ruleData);
            } else {
                await budgetService.addRecurrenceRule(ruleData);
            }
            loadRules();
        } catch (error) {
            console.error("Error saving rule:", error);
            alert("Error al guardar la regla");
        }
    };

    const columns = useMemo(() => [
        {
            key: 'title',
            label: 'Descripción',
            sortable: true,
            filterable: true,
            render: (value: string) => <span className="font-semibold text-slate-700 dark:text-slate-200">{value}</span>
        },
        {
            key: 'amount',
            label: 'Monto',
            sortable: true,
            align: 'text-right' as const,
            render: (value: number) => <span className="font-mono text-slate-700 dark:text-slate-200">${value.toLocaleString()}</span>
        },
        {
            key: 'category',
            label: 'Categoría',
            sortable: true,
            filterable: true,
            render: (value: string) => (
                <span className="px-2 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded text-xs font-bold uppercase tracking-wider">
                    {value}
                </span>
            )
        },
        {
            key: 'frequency',
            label: 'Frecuencia',
            sortable: true,
            render: (value: string, item: RecurrenceRule) => {
                let text = '';
                const interval = item.interval || 1;

                if (value === 'weekly') {
                    const days = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
                    text = interval === 1 ? `Semanal (${days[item.dayToSend] || item.dayToSend})` : `Cada ${interval} semanas`;
                } else if (value === 'monthly') {
                    text = interval === 1 ? `Mensual (Día ${item.dayToSend})` : `Cada ${interval} meses (Día ${item.dayToSend})`;
                } else {
                    text = 'Anual';
                }
                return <span className="text-sm text-slate-500">{text}</span>;
            }
        },
        {
            key: 'active',
            label: 'Estado',
            align: 'text-center' as const,
            render: (value: boolean) => (
                <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${value ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>
                    {value ? 'Activo' : 'Inactivo'}
                </span>
            )
        },
        {
            key: 'actions',
            label: '',
            width: 'w-20',
            align: 'text-right' as const,
            render: (_: any, item: RecurrenceRule) => (
                <div className="flex justify-end gap-1">
                    <button
                        onClick={() => handleEdit(item)}
                        className="p-1 text-slate-400 hover:text-indigo-600 transition-colors"
                        title="Editar regla"
                    >
                        <PencilSquareIcon className="w-4 h-4" />
                    </button>
                    <button
                        onClick={() => handleDelete(item.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                        title="Eliminar regla"
                    >
                        <TrashIcon className="w-4 h-4" />
                    </button>
                </div>
            )
        }
    ], []);

    if (loading) {
        return (
            <div className="flex h-full items-center justify-center text-slate-400">
                <div className="flex flex-col items-center gap-2">
                    <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                    <span className="text-sm font-medium">Cargando reglas...</span>
                </div>
            </div>
        );
    }

    const handleBulkDelete = async (ids: Set<string>) => {
        try {
            await Promise.all(Array.from(ids).map(id => budgetService.deleteRecurrenceRule(id)));
            loadRules();
        } catch (error) {
            console.error("Error deleting rules:", error);
            alert("Error al eliminar las reglas seleccionadas.");
        }
    };

    return (
        <div className="h-full bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 overflow-hidden flex flex-col p-4">
            <div className="mb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <ArrowPathIcon className="w-5 h-5 text-indigo-500" />
                    Gastos Recurrentes
                </h2>

                <div className="flex gap-2">
                    <button
                        onClick={handleCreate}
                        className="flex items-center gap-2 px-3 py-1.5 bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg text-sm font-medium transition-colors shadow-sm shadow-indigo-500/30"
                    >
                        <PlusIcon className="w-4 h-4" />
                        Nueva Regla
                    </button>
                    <button
                        onClick={handleSeed}
                        className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-lg text-sm font-medium transition-colors border border-indigo-200"
                    >
                        <CloudArrowDownIcon className="w-4 h-4" />
                        {rules.length === 0 ? 'Cargar Plantilla' : 'Recargar Plantilla'}
                    </button>
                </div>
            </div>

            <SmartDataTable
                data={rules}
                columns={columns}
                enableSearch={true}
                enableColumnConfig={true}
                enableExport={true}
                enableSelection={true}
                onBulkDelete={handleBulkDelete}
                searchPlaceholder="Buscar regla..."
                containerClassName="h-full"
            />

            <RecurrenceRuleFormModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                initialRule={selectedRule}
                onSubmit={handleSaveRule}
            />
        </div>
    );
};
