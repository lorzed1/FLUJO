import React, { useEffect, useState, useMemo } from 'react';
import {
    CurrencyDollarIcon,
    ExclamationCircleIcon,
    BanknotesIcon,
    CheckCircleIcon
} from '@heroicons/react/24/outline';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { budgetService } from '../../../services/budgetService';
import { BudgetCommitment } from '../../../types/budget';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, isWithinInterval, parseISO, addDays } from 'date-fns';
import { es } from 'date-fns/locale';
import { useApp } from '../../../context/AppContext';

const getBarColor = (dayData: any) => {
    // Simple logic: if mostly paid, green. If mostly overdue, red. 
    // Or just static color. The image showed colorful bars.
    // Let's use a nice gradient or static teal if not specified.
    return '#4f46e5'; // Indigo
};

export const BudgetDashboard: React.FC = () => {
    const { categories } = useApp();
    const [commitments, setCommitments] = useState<BudgetCommitment[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const loadData = async () => {
            try {
                // Fetch broad range for dashboard? 
                // Let's fetch current month + next month for "Upcoming"
                // And maybe start of year for accumulated?
                // For simplicity/performance, let's Stick to Current Month + 1 Month
                const start = startOfMonth(new Date());
                const end = endOfMonth(addDays(new Date(), 30));

                // We need to handle "Deuda Total Acumulada". 
                // Ideally this requires a separate query for ALL pending/overdue < now.
                // For now, we will calculate based on the fetched window or maybe user can scroll.
                // To be robust: Fetch -3 months to +3 months? 

                const data = await budgetService.getCommitments(
                    format(start, 'yyyy-MM-dd'),
                    format(end, 'yyyy-MM-dd')
                );
                setCommitments(data);
            } catch (error) {
                console.error("Error loading dashboard data:", error);
            } finally {
                setIsLoading(false);
            }
        };
        loadData();
    }, []);

    // --- Stats Calculation ---
    const stats = useMemo(() => {
        const now = new Date();
        const currentMonthStart = startOfMonth(now);
        const currentMonthEnd = endOfMonth(now);

        const currentMonthItems = commitments.filter(c =>
            isWithinInterval(parseISO(c.dueDate), { start: currentMonthStart, end: currentMonthEnd })
        );

        const totalPending = currentMonthItems
            .filter(c => c.status === 'pending' || c.status === 'overdue')
            .reduce((sum, c) => sum + c.amount, 0);

        const totalPaid = currentMonthItems
            .filter(c => c.status === 'paid')
            .reduce((sum, c) => sum + c.amount, 0);

        const overdueCount = currentMonthItems.filter(c => c.status === 'overdue').length;

        // "Dias Promedio Mora" -> We'll replace with "Total Vencido" ($) easier to calc and impactful
        const totalOverdueAmount = currentMonthItems
            .filter(c => c.status === 'overdue')
            .reduce((sum, c) => sum + c.amount, 0);

        return [
            { name: 'Compromisos de Mes', value: `$${(totalPending + totalPaid).toLocaleString()}`, icon: BanknotesIcon, color: 'text-slate-600', bg: 'bg-slate-100' },
            { name: 'Pagado este mes', value: `$${totalPaid.toLocaleString()}`, icon: CheckCircleIcon, color: 'text-emerald-600', bg: 'bg-emerald-50' },
            { name: 'Por Pagar (Pendiente)', value: `$${totalPending.toLocaleString()}`, icon: CurrencyDollarIcon, color: 'text-indigo-600', bg: 'bg-indigo-50' },
            { name: 'Vencido', value: `${overdueCount} ($${totalOverdueAmount.toLocaleString()})`, icon: ExclamationCircleIcon, color: 'text-rose-600', bg: 'bg-rose-50' },
        ];
    }, [commitments]);

    // --- Chart Data (Weekly Flow) ---
    const chartData = useMemo(() => {
        const now = new Date();
        const weekStart = startOfWeek(now, { weekStartsOn: 1 }); // Monday
        const weekEnd = endOfWeek(now, { weekStartsOn: 1 });

        const weekItems = commitments.filter(c =>
            isWithinInterval(parseISO(c.dueDate), { start: weekStart, end: weekEnd })
        );

        const days = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

        return days.map((dayName, index) => {
            const date = addDays(weekStart, index);
            const dateStr = format(date, 'yyyy-MM-dd');

            const dayTotal = weekItems
                .filter(c => c.dueDate === dateStr)
                .reduce((sum, c) => sum + c.amount, 0);

            return {
                day: dayName,
                amount: dayTotal,
                // Determine color mainly by status of items?
                // Simplify: just amount bar.
                fill: '#6366f1' // Indigo-500
            };
        });
    }, [commitments]);

    // --- Upcoming List ---
    const upcomingList = useMemo(() => {
        const now = new Date();
        return commitments
            .filter(c => (c.status === 'pending' || c.status === 'overdue') && new Date(c.dueDate) >= now)
            .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
            .slice(0, 5);
    }, [commitments]);

    // Helper to get Category Name
    const getCategoryName = (id: string) => {
        return categories.find(c => c.id === id)?.name || 'Sin Categoría';
    };

    if (isLoading) return <div className="p-6">Cargando tablero...</div>;

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full overflow-y-auto custom-scrollbar pr-2 pb-20">
            {/* Stats Cards */}
            <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {stats.map((stat) => (
                    <div key={stat.name} className="bg-white dark:bg-slate-800 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{stat.name}</p>
                                <p className="text-lg lg:text-xl font-bold text-slate-900 dark:text-white mt-1">{stat.value}</p>
                            </div>
                            <div className={`p-3 rounded-xl ${stat.bg}`}>
                                <stat.icon className={`w-6 h-6 ${stat.color}`} />
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Main Chart */}
            <div className="lg:col-span-2 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6">Flujo de Pagos Semanal</h3>
                <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                            <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} />
                            <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b' }} />
                            <Tooltip
                                formatter={(value: number) => [`$${value.toLocaleString()}`, 'Total']}
                                cursor={{ fill: 'transparent' }}
                                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                            />
                            <Bar dataKey="amount" radius={[6, 6, 0, 0]} barSize={40}>
                                {chartData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.fill} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Upcoming List */}
            <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-4">Próximos Vencimientos</h3>
                <div className="space-y-4">
                    {upcomingList.length === 0 ? (
                        <p className="text-slate-500 text-sm">No hay vencimientos próximos.</p>
                    ) : (
                        upcomingList.map((item) => (
                            <div key={item.id} className="flex items-center justify-between p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 rounded-xl transition-colors cursor-pointer group">
                                <div className="flex items-center space-x-3 overflow-hidden">
                                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold text-xs flex-col leading-none">
                                        <span>{format(parseISO(item.dueDate), 'd')}</span>
                                        <span className="text-[9px] uppercase">{format(parseISO(item.dueDate), 'MMM', { locale: es })}</span>
                                    </div>
                                    <div className="min-w-0">
                                        <p className="text-sm font-semibold text-slate-900 dark:text-white truncate group-hover:text-indigo-600 transition-colors">
                                            {item.title}
                                        </p>
                                        <p className="text-xs text-slate-500 truncate">
                                            {getCategoryName(item.category || '')}
                                        </p>
                                    </div>
                                </div>
                                <span className="text-sm font-medium text-slate-900 dark:text-white whitespace-nowrap">
                                    ${item.amount.toLocaleString()}
                                </span>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};
