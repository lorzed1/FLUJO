Original Palette Backup (Tailwind Config):

colors: {
  'primary': '#4f46e5',   // Indigo-600
  'secondary': '#10b981', // Emerald-500
  'light-bg': '#f8fafc',  // Slate-50
  'dark-text': '#0f172a', // Slate-900
  'medium-text': '#475569', // Slate-600
  'light-text': '#94a3b8',  // Slate-400
}
