# 🤖 Sistema de Agentes - Proyecto FlowTrack

Bienvenido al sistema de configuración y memoria de agentes del proyecto.

---

## 📚 PUNTO DE ENTRADA

### Para Agentes AI
**INICIO OBLIGATORIO:** Lee primero `.agent/rules/SISTEMA_AGENTES.md`

Este archivo contiene:
- ⚡ Protocolo de inicialización automática
- 🎯 Lógica de selección de roles
- 📉 Reglas de eficiencia y ahorro de tokens
- 🛠️ Uso de Skills y creación de nuevos patrones

---

## 🗂️ ESTRUCTURA DEL DIRECTORIO

### 📁 `/profiles` - Roles Especializados
Define los diferentes "sombreros" que puede asumir un agente:

| Perfil | Archivo | Cuándo Activar |
|--------|---------|----------------|
| 🏛️ **Arquitecto** | `arquitecto.md` | Refactorización, nuevas features, estructura |
| 🛡️ **Guardián de Datos** | `guardian-datos.md` | Firebase, persistencia, seguridad de datos |
| 🎨 **Especialista UI/UX** | `especialista-ui.md` | Estilos, componentes visuales, UX |
| 🔍 **QA & Debugger** | `qa-debugger.md` | Bugs, validación, testing |

### 📁 `/skills` - Habilidades Técnicas
Manuales de "experto" para tareas específicas:

| Skill | Descripción |
|-------|-------------|
| `arquitectura-react/` | Patrones de componentes y hooks |
| `debugging-avanzado/` | Técnicas de debugging sistemático |
| `diseño-ui/` | Sistema de diseño y Tailwind |
| `estandares-firestore/` | Buenas prácticas de Firestore |
| `integridad-bd/` | Validación y seguridad de datos |
| `maestro-frontend/` | Experto en UI/UX moderno |
| `optimizacion-rendimiento/` | Performance y optimización |
| `revision-codigo/` | Estándares de calidad de código |
| `sistema-diseño-ui/` | Sistema de diseño completo |
| `tabla-datos-estandar/` | Implementación de tablas |
| `verificacion-estabilidad/` | Checklist antes de deployment |
| `versionado-semantico/` | Commits y versionado |

### 📁 `/rules` - Reglas Inquebrantables
Estándares que **NO** se pueden romper:

| Regla | Contenido |
|-------|-----------|
| `SISTEMA_AGENTES.md` | **⭐ PUNTO DE ENTRADA PRINCIPAL** |
| `BUSINESS_RULES.md` | Lógica de negocio (Lado A vs Lado B, filtros) |
| `coding-style.md` | Convenciones de código (TypeScript, naming) |
| `DESIGN_SYSTEM_RULES.md` | Estándares visuales estrictos |
| `directory-structure.md` | Organización de carpetas |
| `GEMINI.md` | Configuración específica para Gemini |
| `tech-stack.md` | Stack tecnológico aprobado |

### 📁 `/workflows` - Procedimientos Paso a Paso
Flujos de trabajo documentados:

| Workflow | Uso |
|----------|-----|
| `new-feature.md` | Protocolo para implementar nuevas funcionalidades |

### 📁 `/docs` - Documentación Técnica
Guías, soluciones y configuraciones:
- Configuración de Firebase
- Autenticación local
- Sistema de roles (Admin/Cajero)
- Optimizaciones de rendimiento
- Paleta de colores

### 📁 `/plans` - Planes de Implementación
Features en desarrollo o planificadas.

### 📁 `/verification` - Scripts de Verificación
- Verificación de migración a Firestore
- Validación de Data Guardian

### 📁 `/mcp` - Configuraciones MCP
Configuraciones de Model Context Protocol (para bases de datos y APIs).

---

## 🎯 ARCHIVOS RAÍZ IMPORTANTES

### `BLUEPRINT.md`
**Visión del Proyecto:** Objetivos, stack tecnológico, arquitectura general.

### `MEMORIA_TECNICA.md`
**Estado Actual:** Arquitectura implementada, bugs conocidos, pendientes críticos.

### `implementation_plan.md`
**Plan Activo:** Implementaciones en progreso.

---

## 🔄 FLUJO DE TRABAJO RECOMENDADO

### Para un Nuevo Agente
1. ✅ **Lee** `rules/SISTEMA_AGENTES.md` (obligatorio)
2. ✅ **Revisa** `MEMORIA_TECNICA.md` para contexto del proyecto
3. ✅ **Identifica** el perfil apropiado en `/profiles`
4. ✅ **Consulta** las skills relevantes en `/skills`
5. ✅ **Aplica** las reglas de `/rules`
6. ✅ **Ejecuta** la tarea
7. ✅ **Documenta** cambios en `MEMORIA_TECNICA.md`

### Para Implementar una Nueva Feature
1. Sigue el workflow: `workflows/new-feature.md`
2. Asume el rol de **Arquitecto**
3. Consulta `rules/BUSINESS_RULES.md` si afecta lógica de negocio
4. Usa skills: `arquitectura-react/`, `diseño-ui/`

### Para Resolver un Bug
1. Asume el rol de **QA & Debugger**
2. Consulta skill: `debugging-avanzado/`
3. Sigue checklist: `verificacion-estabilidad/`
4. Documenta la solución

### Para Cambios en Firebase
1. Asume el rol de **Guardián de Datos**
2. Consulta skills: `estandares-firestore/`, `integridad-bd/`
3. Verifica reglas de seguridad en `docs/REGLAS_SEGURIDAD_FIREBASE.md`

---

## 📝 CONVENCIONES

### Nombres de Archivos
- **Perfiles**: `kebab-case` en español (`arquitecto.md`)
- **Skills**: Carpetas en `kebab-case` con `SKILL.md` dentro
- **Reglas**: `SCREAMING_SNAKE_CASE` o `kebab-case` según importancia

### Idioma
- **Preferencia**: Español para nombres de perfiles y skills
- **Excepción**: Términos técnicos en inglés cuando sea estándar (React, Firestore)

---

## 🚀 INICIO RÁPIDO

```bash
# Para desarrolladores humanos
1. Lee BLUEPRINT.md para entender la visión
2. Revisa MEMORIA_TECNICA.md para el estado actual
3. Consulta docs/ para guías específicastales

# Para agentes AI
1. OBLIGATORIO: rules/SISTEMA_AGENTES.md
2. Selecciona perfil apropiado de profiles/
3. Consulta skills relevantes
4. Aplica rules/ correspondientes
5. Ejecuta con excelencia
```

---

**Última actualización:** Enero 2026  
**Configurado por:** Antigravity Multi-Agent System
