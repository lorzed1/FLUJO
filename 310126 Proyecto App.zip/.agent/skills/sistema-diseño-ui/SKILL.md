---
name: ui-ux-design-system
description: Reglas y estándares visuales ESTRICTOS para el diseño de la interfaz de usuario.
---

# UI/UX Design System & Guidelines

## 1. Filosofía de Diseño
Buscamos una interfaz **"Clean, Modern & Professional"**.
*   **Espaciado Generoso:** Evitar la saturación visual. Usar `gap-4` o `gap-6` como estándar.
*   **Jerarquía Clara:** Títulos grandes, textos secundarios en gris suave, botones de acción prominentes.
*   **Card-Based Layout:** El contenido siempre vive en contenedores blancos (`bg-white`) con bordes sutiles y sombras suaves sobre un fondo gris claro (`bg-slate-50`).

## 2. Paleta de Colores (Tailwind)
Colores semánticos definidos en `tailwind.config.js`. Usar siempre las clases semánticas, no hex codes directos.
*   **Brand Primary:** `text-primary` / `bg-primary` (Azul corporativo).
*   **Backgrounds:** `bg-slate-50` (Fondo App), `bg-white` (Tarjetas).
*   **Bordes:** `border-gray-100` (Sutil), `border-gray-200` (Estructural).
*   **Texto:**
    *   Principal: `text-slate-800` (Títulos, Data importante)
    *   Secundario: `text-slate-500` (Etiquetas, Metadatos)
    *   Deshabilitado: `text-slate-400`

## 3. Tipografía
Fuente Sans-serif moderna (Inter/Roboto/System).
*   **H1 (Página):** `text-2xl font-bold tracking-tight text-slate-900`
*   **H2 (Sección):** `text-lg font-bold text-slate-800`
*   **H3 (Tarjeta):** `text-sm font-bold uppercase tracking-wider text-slate-500`
*   **Body:** `text-sm font-medium text-slate-600`
*   **Small:** `text-xs text-slate-500`

## 4. Componentes Core

### Botones (`Button.tsx`)
No usar `<button>` nativo con clases ad-hoc. Usar variante `Button`.
*   **Primary:** `bg-primary text-white hover:bg-primary/90 shadow-sm rounded-lg`
*   **Secondary:** `bg-white text-slate-700 border border-gray-200 hover:bg-gray-50 shadow-sm rounded-lg`
*   **Ghost:** `text-slate-600 hover:bg-slate-100 rounded-lg`
*   **Destructive:** `bg-red-50 text-red-600 hover:bg-red-100 border border-red-100 rounded-lg`
*   **Icon-Only:** `p-2 rounded-lg hover:bg-slate-100 text-slate-500`

### Inputs y Selectores
Estandarizar altura y estados.
*   **Base:** `h-10 w-full rounded-lg border-gray-200 bg-white text-sm focus:ring-2 focus:ring-primary/10 focus:border-primary transition-all`
*   **Label:** `block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5`

### Tarjetas (`Card`)
*   **Estilo:** `bg-white border border-gray-100 shadow-sm rounded-xl overflow-hidden`
*   **Padding:** `p-6` (Estándar), `p-4` (Compacto).

### Tablas (`SmartDataTable`)
*   **Header:** `bg-slate-50/50 border-b border-gray-100 text-xs font-bold text-slate-500 uppercase tracking-wider`
*   **Row:** `hover:bg-slate-50 transition-colors border-b border-gray-50 last:border-0`
*   **Cell:** `py-3 px-4 text-sm text-slate-600`

## 5. Layout General (`App.tsx` & Vistas)
*   **Sidebar:** `w-64 bg-white border-r border-gray-100 h-screen fixed`
*   **Main Content:** `pl-64 min-h-screen bg-slate-50`
*   **Page Container:** `max-w-7xl mx-auto p-8`

## 6. Reglas de Implementación
1.  **NO usar sombras negras duras.** Usar `shadow-sm` o `shadow-md` de Tailwind (colores difusos).
2.  **Bordes redondeados consistentes:** `rounded-lg` (8px) para controles internos, `rounded-xl` (12px) para contenedores grandes.
3.  **Micro-interacciones:** Todos los elementos interactivos deben tener `:hover` y `:active` definidos (e.g., `transition-all duration-200`).
