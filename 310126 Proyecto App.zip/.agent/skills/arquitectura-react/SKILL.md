---
name: react-architecture
description: Estándares para escribir código React mantenible, modular y limpio.
---

# Habilidad: React Architecture & Clean Code

## Objetivo
Escribir código React mantenible, modular y performante.

## Reglas de Oro
1.  **Componentes Funcionales:** Usa siempre Functional Components con Hooks. Prohibido usar Class Components.
2.  **Principio de Responsabilidad Única:** Si un componente tiene más de 100 líneas o hace dos cosas distintas (ej. fetchear datos Y renderizar una tabla compleja), divídelo en subcomponentes.
3.  **Gestión de Estado:**
    * Usa `useState` solo para estados locales de UI.
    * Usa Context API o Custom Hooks para lógica de negocio compartida.
    * Evita el "Prop Drilling" (pasar props a través de 5 niveles).
4.  **Nombrado:** Usa PascalCase para componentes (`UserProfile.tsx`) y camelCase para funciones/variables (`handleUpdate`).
