---
name: code-review
description: Auditar calidad de código, seguridad y estilo.
---

# Skill: Code Review & Audit

**Objetivo**: Asegurar la calidad técnica antes de cerrar una tarea.

## Instrucciones de Ejecución

1.  **Escaneo Estático**:
    - Revisar los archivos modificados recientemente.
    - Buscar variables declaradas pero no usadas.
    - Verificar imports innecesarios o rotos.

2.  **Verificación de Tipado (TypeScript)**:
    - Buscar uso de `any`. Si se encuentra, sugerir un tipo específico.
    - Verificar que las interfaces en `types/` se estén utilizando correctamente.
    - Asegurar que no hay "Non-null assertions" (`!`) riesgosas.

3.  **Compliance con Estilo (.agent/rules/coding-style.md)**:
    - Naming conventions: `PascalCase` para componentes, `camelCase` para lógica.
    - Estructura: ¿Están los hooks al principio? ¿Están los estilos separados o inline (Tailwind)?

4.  **Seguridad y Manejo de Errores**:
    - ¿Las llamadas asíncronas tienen `try/catch`?
    - ¿Se muestran feedbacks al usuario en caso de error?

5.  **Reporte**:
    - Generar una lista de "Hallazgos" clasificados por severidad (Crítico, Importante, Sugerencia).
    - Proponer correcciones específicas (snippets de código).
