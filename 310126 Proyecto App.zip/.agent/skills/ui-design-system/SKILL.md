---
name: ui-design-system
description: Estándares visuales y de componentes UI usando Tailwind CSS y React.
version: 1.0.0
---
# REGLAS DE ORO (TAILWIND)
1. **Colores:** Primario `bg-blue-600` (hover `700`), Neutro `bg-white` (borde `gray-300`), Texto `gray-900`.
2. **Forma:** Bordes redondeados `rounded-lg` (8px), Sombras suaves `shadow-sm`.
3. **Tipografía:** Sans-serif, Inter o System fonts. Títulos `font-bold`.
4. **Código:** Componentes funcionales con TypeScript (`React.FC`), Props tipadas, sin `any`.
