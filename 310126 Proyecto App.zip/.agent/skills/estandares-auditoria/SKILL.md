# Audit Standards - Google Clean Architecture

## Criterio 1: Separación de Responsabilidades (SoC)
- **Principio**: La Capa de Presentación (UI) NO debe comunicarse directamente con la Capa de Datos (DB).
- **Regla**: Los componentes de React (`.tsx`, `.jsx`) solo deben llamar a hooks personalizados, servicios o APIs. Nunca deben importar clientes de base de datos directamente (ej: Supabase client directo en useEffect sin abstracción).

## Criterio 2: Modularidad y Complejidad Ciclomática
- **Principio**: Funciones pequeñas hacen una sola cosa bien.
- **Regla**: Funciones o Componentes de más de 30-50 líneas son sospechosos. Archivos de más de 200 líneas requieren refactorización inmediata.

## Criterio 3: Tipado Estricto (Safety)
- **Principio**: TypeScript debe ser usado para prevenir errores, no para silenciarlos.
- **Regla**: El uso de `any` está prohibido. Debe usarse `unknown` si el tipo es incierto, o genéricos adecuados. Las interfaces deben ser explícitas.

## Criterio 4: Manejo de Errores y Resiliencia
- **Principio**: El software debe fallar con gracia y logs claros.
- **Regla**: Evitar `try-catch` vacíos o `console.log` genéricos en producción. Usar límites de error (Error Boundaries) en React y manejo centralizado de excepciones en lógica de negocio.
