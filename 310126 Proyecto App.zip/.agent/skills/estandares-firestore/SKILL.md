---
name: firestore-best-practices
description: Estándares obligatorios para interactuar con Firestore y evitar límites de tamaño.
version: 1.0.0
---

REGLAS DE ORO:
1. **Colecciones sobre Documentos Gigantes:** NUNCA guardes arrays de objetos transaccionales dentro de un solo documento. Usa una sub-colección (ej: `users/{userId}/transactions/{transactionId}`).
2. **Consultas Eficientes:** Para leer datos, usa `query()` con filtros y paginación, nunca descargues la colección entera si no es necesario.
3. **Tipado Estricto:** Define una interfaz TypeScript `Transaction` y úsala en los convertidores de Firestore (`withConverter`). Prohibido usar `any`.
4. **Atomicidad:** Si una operación afecta dos lugares, usa `runTransaction` o `WriteBatch`.
5. **Zero Waste Writes (Importante):** NUNCA realices un `upsert` ciego. Antes de escribir (`set` o `update`), verifica si el dato ya existe y si es idéntico.
   - ❌ Mal: `batch.set(ref, data)` (Sobreescribe siempre, consume cuota $$$)
   - ✅ Bien: `if (JSON.stringify(existing) !== JSON.stringify(newItem)) batch.set(...)`
