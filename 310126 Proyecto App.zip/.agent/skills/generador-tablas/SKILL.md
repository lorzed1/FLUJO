---
name: Scaffold Table with SmartDataTable
description: Instrucciones para usar el componente SmartDataTable para crear tablas estandarizadas.
---

# 🚀 Scaffold Table Skill

Esta habilidad se activa cada vez que necesitas crear una "tabla", "lista de administración", "vista de datos" o cualquier interfaz tipo grid. En lugar de escribir HTML `<table>` y lógica de filtrado manual, **SIEMPRE** debes usar el componente `SmartDataTable`.

## 1. Importación

```typescript
import { SmartDataTable, Column } from '../../components/ui/SmartDataTable';
```

## 2. Definición (`Features` y `Views`)

Cuando crees una vista (ej. `ProductsView.tsx`), sigue este patrón:

### A. Definir las Columnas (fuera del componente para evitar re-renders o con useMemo)

```typescript
const columns: Column<ProductType>[] = [
    { 
        key: 'name', 
        label: 'Producto', 
        sortable: true, 
        filterable: true 
    },
    { 
        key: 'price', 
        label: 'Precio', 
        align: 'text-right',
        render: (item) => formatCurrency(item.price),
        sortable: true
    },
    {
        key: 'status',
        label: 'Estado',
        align: 'text-center',
        render: (item) => (
            <span className={`badge ${item.active ? 'bg-green-100' : 'bg-red-100'}`}>
                {item.active ? 'Activo' : 'Inactivo'}
            </span>
        ),
        getValue: (item) => item.active ? 'Activo' : 'Inactivo', // Para exportación/ordenamiento correcto
        filterable: true
    }
];
```

### B. Implementar el Componente

```tsx
const ProductsView = ({ products, deleteProduct }) => {
    
    // Lógica opcional de eliminación masiva
    const handleBulkDelete = (ids: Set<string>) => {
        ids.forEach(id => deleteProduct(id));
    };

    return (
        <div className="h-full p-4">
            <h1 className="text-2xl font-bold mb-4">Inventario</h1>
            
            <div className="h-[600px]"> {/* Contenedor con altura definida es importante */}
                <SmartDataTable 
                    data={products}
                    columns={columns}
                    enableSearch={true}
                    enableSelection={true}
                    enableExport={true}
                    onBulkDelete={handleBulkDelete}
                    searchPlaceholder="Buscar productos..."
                    onRowClick={(item) => console.log('Edit', item)}
                />
            </div>
        </div>
    );
};
```

## 3. Ventajas Automáticas

Al usar este componente, obtienes GRATIS:
*   ✅ Buscador global en tiempo real.
*   ✅ Filtros tipo Excel en cada columna (con lista de valores únicos).
*   ✅ Ordenamiento (Sort) por columna.
*   ✅ Selector de columnas visibles (Ojo/Eye icon).
*   ✅ Exportación a Excel, PDF y CSV.
*   ✅ UI estandarizada (Sticky headers, Zebra striping, Hover effects).
*   ✅ Selección múltiple y acciones en lote.

## 4. Reglas de Oro

1.  **Nunca** escribas una etiqueta `<table>` manualmente a menos que sea para un reporte impreso muy específico o una estructura no tabular estándar.
2.  Si necesitas una acción por fila (ej. botón eliminar individual), usa la prop `render` en la columna de acciones.
3.  Asegúrate de que el contenedor padre de `SmartDataTable` tenga una altura definida (ej. `h-full`, `h-screen`, `h-[500px]`) para que el scroll interno funcione.
