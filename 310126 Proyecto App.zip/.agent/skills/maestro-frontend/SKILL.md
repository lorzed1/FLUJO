---
name: frontend-master
description: Habilidad experta en UI/UX y Tailwind CSS para generar interfaces modernas.
---

# Habilidad: Frontend Master & UI/UX Expert

## Objetivo
Generar interfaces de usuario modernas, accesibles y completamente responsivas utilizando React y Tailwind CSS.

## Directrices de Tailwind CSS
1.  **Mobile-First:** Escribe siempre las clases base para móviles primero y usa breakpoints (`sm:`, `md:`, `lg:`) para pantallas más grandes.
    * *Mal:* `flex-row`
    * *Bien:* `flex-col md:flex-row`
2.  **Sin valores arbitrarios:** Evita usar corchetes como `w-[13px]` a menos que sea estrictamente necesario. Usa la escala de diseño del sistema (ej. `w-4`, `p-6`).
3.  **Componentes UI:** Para botones, inputs y tarjetas, busca reutilizar componentes existentes en lugar de reescribir clases larguísimas.

## Directrices de UX/Accesibilidad
1.  **Interactividad:** Todos los elementos interactivos deben tener estados de `:hover`, `:focus` y `:active`.
2.  **Accesibilidad (a11y):** Las imágenes deben tener `alt`, los botones deben tener `aria-label` si no tienen texto, y el contraste de colores debe ser legible.

## Manejo de Datos Numéricos y Moneda
1. **Robustez en Parseo**: Al importar datos (CSV/Excel) o leer inputs de usuario, NUNCA uses simples reemplazos de caracteres no numéricos (`replace(/\D/g, '')`) si esperas decimales.
   * **Regla de Oro**: Detecta inteligentemente el formato. Si hay múltiples separadores iguales (ej. dos puntos), son miles. El último separador diferente suele ser el decimal.
   * Usa `Intl.NumberFormat` para formatear salidas visuales.
2. **Ambigüedad de Separadores**: El sistema debe soportar tanto formato Latino (`1.000,00`) como Americano (`1,000.00`).
   * *Implementación de Referencia*: Ver `src/components/ui/Input.tsx` -> `parseCOP`.

## Configuración de Módulos de Importación
1. **Consulta Proactiva**: Siempre que se configure o modifique un nuevo módulo de importación (CSV, Excel), el agente DEBE preguntar al usuario cuáles son los campos específicos a mapear para ese caso particular.
2. **Personalización del Mapeo**: Aunque la lógica de lectura y preparación de archivos sea estándar (UTF-8, delimitadores, etc.), los campos "target" varían según el contexto (arqueos, extractos, conciliaciones).
3. **Consistencia Técnica**: Mantener siempre los estándares de manejo de fechas, separadores de miles/decimales y detección de duplicados definidos previamente.
