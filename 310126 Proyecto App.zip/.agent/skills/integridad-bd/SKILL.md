---
name: database-integrity
description: Estándares para interacciones seguras, eficientes y robustas con la base de datos.
---

# Habilidad: Database Integrity & Performance

## Objetivo
Gestionar interacciones con la base de datos asegurando integridad, seguridad y velocidad.

## Instrucciones
1.  **Eficiencia:** Nunca hagas consultas dentro de bucles (`for` loops). Usa operaciones en lote (batch) o joins.
2.  **Seguridad:** Nunca interpoles variables directamente en strings de consulta (SQL Injection). Usa siempre consultas parametrizadas o los métodos del ORM/SDK.
3.  **Manejo de Errores:** Todas las llamadas a la base de datos deben estar envueltas en bloques `try/catch` con logs claros del error.
4.  **Tipado:** Si usas TypeScript, asegúrate de que los datos recibidos coincidan con una `Interface` definida. No uses `any`.
