# 🌟 BLUEPRINT: FlowTrack (Proyector de Flujo de Caja)

## 🎯 Objetivo
Sistema de gestión financiera para PYMEs que permite proyectar el flujo de caja futuro, controlar el efectivo diario (arqueos) y gestionar conciliaciones bancarias, con un sistema de roles robusto (Administrador/Cajero).

## 🛠 Stack Tecnológico
- **Frontend**: React 19 + Vite (TypeScript).
- **Estilos**: TailwindCSS (Actualmente CDN, objetivo: PostCSS Nativo).
- **Backend/BaAS**: Firebase (Firestore, Auth).
- **Librerías Clave**: Recharts (Gráficos), jsPDF (Reportes), React Router 7.

## 🚀 Funcionalidades Principales
1. **Dashboard de Proyección**: Visualización híbrida de transacciones reales vs. proyectadas a 6 meses.
2. **Motor de Recurrencia**: Generación automática de proyecciones basadas en gastos fijos (semanales/mensuales) y excepciones.
3. **Módulo de Arqueo (Cajeros)**: Interfaz simplificada para conteo de efectivo, cálculo de descuadres y cierre de caja.
4. **Conciliación Bancaria**: Herramienta para cruzar movimientos bancarios con registros internos.
5. **Control de Accesos (RBAC)**:
   - *Admin*: Acceso total (Configuración, Usuarios, Reportes).
   - *Cajero*: Acceso restringido exclusivamente a `/arqueo`.

## 📐 Principios de Arquitectura
- **Feature-First**: Organizar código por dominio (ej: `features/cash-flow`, `features/auth`) y no por tipo técnico.
- **Separation of Concerns**: La lógica de cálculo (proyecciones) debe vivir fuera de los componentes UI.
- **Offline-First (Meta)**: Estructura preparada para eventual soporte offline (PWA) dado el uso en puntos de venta.
