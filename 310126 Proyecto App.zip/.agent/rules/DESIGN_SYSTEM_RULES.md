# 🎨 Reglas del Sistema de Diseño y UI (Protocolo Anti-Regresiones)

Estas reglas son **INVIOLABLES**. Cualquier cambio en la UI debe ser validado contra esta lista.

## 1. Integridad del Layout y Scroll
- **Contenedores Flex Anidados**:
  - Si un contenedor hijo debe tener scroll interno (ej. tablas), su contenedor padre Flex **DEBE** tener `min-h-0` (o `min-w-0` si es horizontal) para evitar que el contenido fuerce el tamaño del padre.
  - El contenedor con scroll debe tener `overflow-auto` (o `overflow-y-auto`) y una restricción de altura (ej. `h-full`, `flex-1`).
- **Altura de Pantalla**:
  - Evitar `h-screen` en componentes internos. Usar `h-full` relativo al contenedor principal de layout.
  - Para vistas principales de dashboard, asegurar que el contenedor raíz tenga altura definida (ej. `h-[calc(100vh-6rem)]`).

## 2. Formato de Datos (Validación Estricta)
- **Fechas**:
  - **Visualización**: SIEMPRE `DD/MM/YYYY` (ej. `28/01/2026`).
  - **Input**: El usuario ve `DD/MM/YYYY` (o browser default) pero el valor interno es `YYYY-MM-DD`.
  - **Prohibido**: Formatos de texto como "28 ene 2026" (rechazado por usuario).
- **Moneda (Pesos Colombianos)**:
  - **Visualización**: SIEMPRE `$ 120.000` (Signo pesos + Separador miles punto + Sin decimales).
  - **Función Autorizada**: Usar `formatCOP(valor)` de `Input.tsx`.
  - **Prohibido**: Decimales en visualización final (`,00`).

## 3. Estabilidad de Componentes
- **SmartDataTable**:
  - No remover `containerClassName="h-full"` a menos que se reemplace por una estrategia de altura explícita.
  - No remover `min-h-0` del contenedor de la tabla dentro del componente.

## 4. Persistencia Visual
- Los filtros críticos (fechas, cuentas seleccionadas) deben intentar persistir en la sesión o recuperarse de forma inteligente para no "resetear" la vista del usuario accidentalmente, a menos que sea una acción explícita de "Limpiar".
