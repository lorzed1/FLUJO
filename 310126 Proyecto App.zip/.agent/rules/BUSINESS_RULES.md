---
trigger: always_on
---

# Reglas de Negocio: Conciliación Bancaria

## Diferenciación Lado A vs Lado B

### Lado A: Extractos Bancarios (BankStatements)
- **Naturaleza:** Es un reflejo fiel del banco. **INMUTABLE**.
- **Tipo (Ingreso/Egreso):** Se **INFIERE AUTOMÁTICAMENTE** del signo del valor.
  - Valor Positivo (+) o Crédito = **INGRESO** (Verde)
  - Valor Negativo (-) o Débito = **EGRESO** (Rojo)
- **Edición:** El usuario NO edita el tipo. Solo ve la realidad bancaria.

### Lado B: Libro Oficial (OfficialBook)
- **Naturaleza:** Es el registro contable interno. **EDITABLE**.
- **Tipo (Ingreso/Egreso):** Es definido **MANUALMENTE** por el usuario.
  - El sistema puede dejarlo en blanco (**PENDIENTE**) inicialmente.
  - El usuario debe clasificar explícitamente si es un Ingreso o Gasto.
- **Comportamiento de Filtro:** 
  - Al filtrar, se buscan coincidencias exactas con la clasificación del usuario.
  - "PENDIENTE" es un estado válido y separado.

## Sincronización de Filtros (LINK)
- Los filtros de **FECHA** se sincronizan siempre.


## Persistencia
- Estas reglas son custodiadas por el **Product Owner Agent** y deben ser consultadas antes de modificar la lógica de filtrado o renderizado.
