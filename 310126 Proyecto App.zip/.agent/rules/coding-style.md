# Coding Style & Conventions

Estas reglas aseguran la legibilidad y mantenibilidad del código.

## Naming Conventions
- **Componentes React**: `PascalCase` (ej. `DashboardView.tsx`, `PrimaryButton.tsx`).
- **Funciones y Variables**: `camelCase` (ej. `calculateTotal`, `isActive`).
- **Constantes**: `UPPER_CASE` con guiones bajos (ej. `DEFAULT_TIMEOUT`, `MAX_RETRIES`).
- **Interfaces/Tipos**: `PascalCase`. Las interfaces no necesitan prefijo `I` (ej. `User` en lugar de `IUser`).
- **Archivos**: Deben coincidir con su export principal.

## Estructura de Componentes
```typescript
// 1. Imports (Librerías externas primero, luego internas)
import React from 'react';
import { useAuth } from '../../hooks/useAuth';

// 2. Interfaces de Props
interface MyComponentProps {
    title: string;
    isActive?: boolean;
}

// 3. Componente
const MyComponent: React.FC<MyComponentProps> = ({ title, isActive }) => {
    // Hooks
    // Handlers
    // Render
    return (
        <div className="p-4">
           {/* Contenido */}
        </div>
    );
};

export default MyComponent;
```

## TypeScript
- **No `any`**: Evitar `any` a toda costa. Definir tipos en `src/types/index.ts` o localmente si son privados.
- **No Non-Null Assertion (`!`)**: Usar Optional Chaining (`?.`) o comprobaciones explícitas.

## Manejo de Errores
- Usar bloques `try/catch` en todas las funciones asíncronas (`async/await`).
- Los errores de servicios deben ser logueados y/o mostrados al usuario mediante un sistema de notificaciones/alertas unificado, no solo `console.error`.

## Comentarios
- **JSDoc**: Para funciones complejas de utilidad o servicios.
- **Inline**: Solo para explicar "por qué" se hace algo no obvio, no "qué" hace el código (el código debe auto-explicarse).
