# FlowTrack Pro - Blueprint Técnico

## 1. Arquitectura del Sistema
El proyecto sigue una arquitectura modular y estricta, diseñada para escalabilidad y mantenimiento bajo las reglas definidas en `.agent/rules/`.

### Estructura de Directorios (Source of Truth)
- **`src/features/`**: Módulos de dominio encapsulados.
    - `auth/`: Login, Gestión de Usuarios y Herramientas Admin (incl. `FirebaseMigrationPanel`).
    - `dashboard/`: Analítica, Gráficos y KPIs.
    - `operations/`: Gestión diaria (Transacciones, Calendario, Gastos Recurrentes).
    - `reconciliation/`: Módulo avanzado de conciliación bancaria.
    - `cash-flow/`: Arqueos de caja y control de efectivo.
- **`src/types/`**: Definiciones de tipos globales. El punto de entrada es `index.ts`.
- **`src/services/`**: Capa de datos e infraestructura (Firebase, LocalStorage, Auth).
- **`src/components/ui/`**: Librería de componentes visuales puros y reutilizables.

## 2. Stack Tecnológico
- **Frontend**: React 18 + TypeScript + Vite.
- **Estilos**: Tailwind CSS + HeroIcons.
- **Persistencia**: Híbrida (LocalStorage + Firebase Firestore).
- **Utils**: `xlsx` (Excel), `jspdf` (PDF), `recharts` (Gráficos).

## 3. Reglas de Gobernanza
- Todo nuevo desarrollo debe seguir el workflow `new-feature`.
- No se permiten archivos sueltos en `src/` (excepto `App`, `main`, `vite-env`).
- Los imports deben respetar la jerarquía (features -> services/components).

## 4. Estado Actual
- **Refactorización Completada**: Todos los módulos extraídos a `features/`.
- **Tipos Unificados**: Centralizados en `src/types/index.ts`.
- **Errores Resueltos**: Imports corregidos y validados.
- **Gobernanza**: Reglas activas en `.agent/rules/`.
