import { useState, useMemo, useEffect, SetStateAction, Dispatch } from 'react';
import { Transaction, Category, ReconciliationResult, ReconciliationMatch, ReconciliationCandidate } from '../types';
import { ReconciliationService } from '../services/reconciliationService';
import { InteractiveReconciliationService } from '../services/interactiveReconciliation';

const BANK_TRANSACTIONS_KEY = 'conciliaciones_bank_transactions_multi';
const RECONCILIATION_RESULT_KEY = 'conciliaciones_result_multi';
const SELECTED_BANK_NAME_KEY = 'conciliaciones_selected_bank_name';

interface UseConciliacionProps {
    transactions: Transaction[];
    categories: Category[];
    bankTransactions: Record<string, Transaction[]>;
    reconciliationResults: Record<string, ReconciliationResult | null>;
    onUpdateBankTransactions: Dispatch<SetStateAction<Record<string, Transaction[]>>>;
    onUpdateReconciliationResults: Dispatch<SetStateAction<Record<string, ReconciliationResult | null>>>;
    addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
}

export const useConciliacion = (props: UseConciliacionProps) => {
    // UI State
    const [selectedBankAccountName, setSelectedBankAccountName] = useState<string>('');
    const [internalAccountFilter, setInternalAccountFilter] = useState<string>('');
    const [isInternalImportOpen, setIsInternalImportOpen] = useState(false);
    const [isBankImportOpen, setIsBankImportOpen] = useState(false);
    const [activeTab, setActiveTab] = useState<'workspace' | 'history'>('workspace');

    // Selection State
    const [selectedInternalIds, setSelectedInternalIds] = useState<Set<string>>(new Set());
    const [selectedExternalIds, setSelectedExternalIds] = useState<Set<string>>(new Set());

    // Interactive Reconciliation State
    const [isReconciliationModalOpen, setIsReconciliationModalOpen] = useState(false);
    const [selectedForReconciliation, setSelectedForReconciliation] = useState<Transaction | null>(null);
    const [reconciliationCandidates, setReconciliationCandidates] = useState<ReconciliationCandidate[]>([]);
    const [highlightedCandidateId, setHighlightedCandidateId] = useState<string | null>(null);
    const [reconciliationQueue, setReconciliationQueue] = useState<Transaction[]>([]);
    const [currentQueueIndex, setCurrentQueueIndex] = useState(0);

    // Filter Sync State
    const [isFiltersLinked, setIsFiltersLinked] = useState(false);
    const [sharedFilters, setSharedFilters] = useState({
        dateRange: { start: '', end: '' },
        selectedMonth: '',
        selectedYear: '',
        typeFilter: [] as string[],
        sortField: 'date',
        sortDirection: 'desc' as 'asc' | 'desc',
        selectedBankAccountName: ''
    });

    // Derived State
    const bankTransactions = useMemo(() => {
        if (!selectedBankAccountName) {
            return Object.values(props.bankTransactions).flat();
        }
        return props.bankTransactions[selectedBankAccountName] || [];
    }, [props.bankTransactions, selectedBankAccountName]);

    const reconciliationResult = useMemo(() => {
        if (!props.reconciliationResults) return null;

        if (selectedBankAccountName) {
            return props.reconciliationResults[selectedBankAccountName] || null;
        }

        const allMatches: ReconciliationMatch[] = [];
        const results = Object.values(props.reconciliationResults);

        if (!results) return null;

        results.forEach(res => {
            if (res) {
                allMatches.push(...res.matches);
            }
        });

        if (allMatches.length === 0) return null;

        return {
            matches: allMatches,
            unmatchedInternal: [],
            unmatchedExternal: []
        } as ReconciliationResult;
    }, [props.reconciliationResults, selectedBankAccountName]);

    // Effects
    useEffect(() => {
        setSelectedInternalIds(new Set());
        setSelectedExternalIds(new Set());
    }, [selectedBankAccountName]);

    useEffect(() => {
        localStorage.setItem(SELECTED_BANK_NAME_KEY, selectedBankAccountName);
    }, [selectedBankAccountName]);

    // Options computations
    const dynamicInternalAccountOptions = useMemo(() => {
        const counts = new Set<string>();
        const blacklisted = new Set(['CAJA', 'CTA_AHORROS_J', 'CTA_AHORROS_N']);

        if (!props.transactions || !Array.isArray(props.transactions)) {
            return [];
        }

        props.transactions.forEach(t => {
            const name = t.metadata?.cuenta_nombre || t.metadata?.banco_destino;
            if (name) {
                const trimmed = String(name).trim();
                if (!blacklisted.has(trimmed.toUpperCase())) {
                    counts.add(trimmed);
                }
            }
        });
        return Array.from(counts).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
    }, [props.transactions]);

    const dynamicBankOptions = useMemo(() => {
        const blacklisted = new Set(['CAJA', 'CTA_AHORROS_J', 'CTA_AHORROS_N', 'caja', 'cta_ahorros_j', 'cta_ahorros_n']);

        const fromBankData = Object.keys(props.bankTransactions).filter(key =>
            props.bankTransactions[key].length > 0 && !blacklisted.has(key.toLowerCase()) && !blacklisted.has(key.toUpperCase())
        );

        const fromInternalData = dynamicInternalAccountOptions;
        const combined = new Set([...fromBankData, ...fromInternalData]);
        return Array.from(combined).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
    }, [props.bankTransactions, dynamicInternalAccountOptions]);

    const displayInternal = useMemo(() => {
        let filtered = props.transactions || []; // Fallback a array vacío

        if (reconciliationResult) {
            const matchedIds = new Set(reconciliationResult.matches.flatMap(m => m.internalIds));
            filtered = filtered.filter(t => !matchedIds.has(t.id));
        }

        if (internalAccountFilter) {
            const search = internalAccountFilter.toUpperCase();
            filtered = filtered.filter(t => {
                const cuenta = t.metadata?.cuenta_nombre || t.metadata?.banco_destino || '';
                return String(cuenta).toUpperCase().includes(search);
            });
        }

        return filtered;
    }, [props.transactions, reconciliationResult, internalAccountFilter]);

    const displayExternal = useMemo(() => {
        if (!reconciliationResult) return bankTransactions;
        const matchedIds = new Set(reconciliationResult.matches.flatMap(m => m.externalIds));
        return bankTransactions.filter(t => !matchedIds.has(t.id));
    }, [bankTransactions, reconciliationResult]);

    const selectedInternalTotal = useMemo(() => {
        return displayInternal
            .filter(t => selectedInternalIds.has(t.id))
            .reduce((sum, t) => sum + (t.type === 'income' ? Math.abs(t.amount) : -Math.abs(t.amount)), 0);
    }, [displayInternal, selectedInternalIds]);

    const selectedExternalTotal = useMemo(() => {
        return displayExternal
            .filter(t => selectedExternalIds.has(t.id))
            .reduce((sum, t) => sum + (t.type === 'income' ? Math.abs(t.amount) : -Math.abs(t.amount)), 0);
    }, [displayExternal, selectedExternalIds]);

    const globalDifference = Math.abs(selectedInternalTotal - selectedExternalTotal);
    const canManualReconcile = selectedInternalIds.size > 0 && selectedExternalIds.size > 0;

    const lastImportDate = useMemo(() => {
        if (displayExternal.length === 0) return null;
        const dates = displayExternal.map(t => new Date(t.date).getTime());
        const maxDate = Math.max(...dates);
        return new Date(maxDate).toLocaleDateString('es-CO', { year: 'numeric', month: 'short', day: 'numeric' });
    }, [displayExternal]);

    const lastInternalDate = useMemo(() => {
        if (displayInternal.length === 0) return null;
        const dates = displayInternal.map(t => new Date(t.date).getTime());
        const maxDate = Math.max(...dates);
        return new Date(maxDate).toLocaleDateString('es-CO', { year: 'numeric', month: 'short', day: 'numeric' });
    }, [displayInternal]);


    // Handlers
    const setBankTransactionsHelper = (newTransactions: Transaction[] | ((prev: Transaction[]) => Transaction[])) => {
        props.onUpdateBankTransactions(prev => {
            const transactionsArray = typeof newTransactions === 'function' ? newTransactions([]) : newTransactions;
            const target = transactionsArray.length > 0 && (transactionsArray[0] as any).metadata?.banco_destino
                ? (transactionsArray[0] as any).metadata.banco_destino
                : selectedBankAccountName;

            const current = prev[target] || [];
            const updated = typeof newTransactions === 'function' ? newTransactions(current) : newTransactions;
            return { ...prev, [target]: updated };
        });
    };

    const setReconciliationResultHelper = (updater: ReconciliationResult | null | ((prev: ReconciliationResult | null) => ReconciliationResult | null)) => {
        if (!selectedBankAccountName) return;
        props.onUpdateReconciliationResults(prev => {
            const current = prev[selectedBankAccountName] || null;
            const next = typeof updater === 'function' ? (updater as any)(current) : updater;
            return { ...prev, [selectedBankAccountName]: next };
        });
    };

    const handleBankFilterChange = (newFilters: any) => {
        if (!isFiltersLinked) return;

        setSharedFilters(prev => {
            const updated = { ...prev, ...newFilters };
            if (newFilters.selectedBankAccountName !== undefined) {
                const newName = newFilters.selectedBankAccountName;
                setSelectedBankAccountName(newName);
                localStorage.setItem(SELECTED_BANK_NAME_KEY, newName);
            }
            return updated;
        });
    };

    const handleOfficialFilterChange = (newFilters: any) => {
        if (!isFiltersLinked) return;
        setSharedFilters(prev => ({ ...prev, ...newFilters }));
    };

    const handleAutoReconcile = () => {
        const result = ReconciliationService.reconcile(
            props.transactions,
            bankTransactions
        );
        setReconciliationResultHelper(result);
        setSelectedInternalIds(new Set());
        setSelectedExternalIds(new Set());
    };

    const handleManualReconcile = () => {
        let targetBank = selectedBankAccountName;
        if (!targetBank && selectedExternalIds.size > 0) {
            const firstExtId = Array.from(selectedExternalIds)[0];
            for (const [bankName, txs] of Object.entries(props.bankTransactions)) {
                if (txs.some(t => t.id === firstExtId)) {
                    targetBank = bankName;
                    break;
                }
            }
        }

        if (!targetBank) {
            alert("No se pudo identificar el banco para guardar la conciliación. Seleccione un banco específico.");
            return;
        }

        const newMatch: any = {
            id: `manual-${Date.now()}`,
            internalIds: Array.from(selectedInternalIds),
            externalIds: Array.from(selectedExternalIds),
            totalAmount: selectedExternalTotal,
            date: new Date().toISOString().split('T')[0],
            difference: globalDifference,
            status: 'matched_manual' as const,
            ruleInfo: 'Manual User Selection'
        };

        props.onUpdateReconciliationResults(prev => {
            const currentResult = prev[targetBank!] || null;
            let nextResult: ReconciliationResult;

            if (!currentResult) {
                nextResult = {
                    matches: [newMatch],
                    unmatchedInternal: props.transactions.filter(t => !selectedInternalIds.has(t.id)),
                    unmatchedExternal: (props.bankTransactions[targetBank!] || []).filter(t => !selectedExternalIds.has(t.id))
                };
            } else {
                nextResult = {
                    matches: [newMatch, ...currentResult.matches],
                    unmatchedInternal: currentResult.unmatchedInternal.filter(t => !selectedInternalIds.has(t.id)),
                    unmatchedExternal: currentResult.unmatchedExternal.filter(t => !selectedExternalIds.has(t.id))
                };
            }

            return { ...prev, [targetBank!]: nextResult };
        });

        setSelectedInternalIds(new Set());
        setSelectedExternalIds(new Set());
    };

    const handleRowClickFromBankSide = (transaction: Transaction) => {
        const candidates = InteractiveReconciliationService.findCandidates(transaction, displayInternal);
        setSelectedForReconciliation(transaction);
        setReconciliationCandidates(candidates);
        setIsReconciliationModalOpen(true);
        if (candidates.length > 0) setHighlightedCandidateId(candidates[0].transaction.id);
    };

    const handleBatchSmartReconcile = () => {
        const queue = displayExternal.filter(t => selectedExternalIds.has(t.id));
        if (queue.length === 0) return;
        setReconciliationQueue(queue);
        setCurrentQueueIndex(0);
        handleRowClickFromBankSide(queue[0]);
    };

    const handleConfirmReconciliation = (candidateTransaction: Transaction) => {
        if (!selectedForReconciliation) return;

        let targetBank = selectedBankAccountName;
        if (!targetBank) {
            targetBank = selectedForReconciliation.metadata?.banco_destino || '';
            if (!targetBank) {
                for (const [bankName, txs] of Object.entries(props.bankTransactions)) {
                    if (txs.some(t => t.id === selectedForReconciliation!.id)) {
                        targetBank = bankName;
                        break;
                    }
                }
            }
        }

        if (!targetBank) {
            const keys = Object.keys(props.bankTransactions);
            if (keys.length === 1) targetBank = keys[0];
        }

        if (!targetBank) {
            alert("No se pudo identificar el banco para guardar la conciliación.");
            return;
        }

        const newMatch = {
            id: `interactive-${Date.now()}`,
            internalIds: [candidateTransaction.id],
            externalIds: [selectedForReconciliation.id],
            totalAmount: selectedForReconciliation.amount,
            date: selectedForReconciliation.date,
            difference: Math.abs(selectedForReconciliation.amount - candidateTransaction.amount),
            status: 'matched_manual' as const,
            ruleInfo: 'Conciliación Interactiva',
            locked: true,
            createdAt: new Date().toISOString()
        };

        props.onUpdateReconciliationResults(prev => {
            const currentResult = prev[targetBank] || null;
            let updatedResult: ReconciliationResult;

            if (!currentResult) {
                updatedResult = {
                    matches: [newMatch],
                    unmatchedInternal: props.transactions.filter(t => t.id !== candidateTransaction.id),
                    unmatchedExternal: (props.bankTransactions[targetBank] || []).filter(t => t.id !== selectedForReconciliation.id)
                };
            } else {
                updatedResult = {
                    matches: [newMatch, ...currentResult.matches],
                    unmatchedInternal: currentResult.unmatchedInternal.filter(t => t.id !== candidateTransaction.id),
                    unmatchedExternal: currentResult.unmatchedExternal.filter(t => t.id !== selectedForReconciliation.id)
                };
            }

            return { ...prev, [targetBank]: updatedResult };
        });

        if (reconciliationQueue.length > 0 && currentQueueIndex < reconciliationQueue.length - 1) {
            const nextIndex = currentQueueIndex + 1;
            setCurrentQueueIndex(nextIndex);
            setTimeout(() => {
                const nextTransaction = reconciliationQueue[nextIndex];
                const candidates = InteractiveReconciliationService.findCandidates(nextTransaction, props.transactions);
                setSelectedForReconciliation(nextTransaction);
                setReconciliationCandidates(candidates);
                if (candidates.length > 0) setHighlightedCandidateId(candidates[0].transaction.id);
            }, 100);
        } else {
            setIsReconciliationModalOpen(false);
            setSelectedForReconciliation(null);
            setReconciliationCandidates([]);
            setHighlightedCandidateId(null);
            setReconciliationQueue([]);
            setCurrentQueueIndex(0);
            setSelectedExternalIds(new Set());
        }
    };

    const handleSkipReconciliation = () => {
        if (reconciliationQueue.length > 0 && currentQueueIndex < reconciliationQueue.length - 1) {
            const nextIndex = currentQueueIndex + 1;
            setCurrentQueueIndex(nextIndex);
            setTimeout(() => {
                const nextTransaction = reconciliationQueue[nextIndex];
                const currentUnmatchedInternal = reconciliationResult ? reconciliationResult.unmatchedInternal : props.transactions;
                const candidates = InteractiveReconciliationService.findCandidates(nextTransaction, currentUnmatchedInternal);
                setSelectedForReconciliation(nextTransaction);
                setReconciliationCandidates(candidates);
                if (candidates.length > 0) setHighlightedCandidateId(candidates[0].transaction.id);
            }, 100);
        } else {
            setIsReconciliationModalOpen(false);
            setSelectedForReconciliation(null);
            setReconciliationCandidates([]);
            setHighlightedCandidateId(null);
            setReconciliationQueue([]);
            setCurrentQueueIndex(0);
            setSelectedExternalIds(new Set());
        }
    };

    const handleUnlockMatch = (matchId: string) => {
        if (!reconciliationResult) return;
        setReconciliationResultHelper({
            ...reconciliationResult,
            matches: reconciliationResult.matches.map(m => m.id === matchId ? { ...m, locked: false } : m)
        });
    };

    const handleDeleteMatch = (matchId: string) => {
        if (!reconciliationResult) return;
        const matchToDelete = reconciliationResult.matches.find(m => m.id === matchId);
        if (!matchToDelete || matchToDelete.locked) return;
        const internalToRestore = props.transactions.filter(t => matchToDelete.internalIds.includes(t.id));
        const externalToRestore = bankTransactions.filter(t => matchToDelete.externalIds.includes(t.id));
        setReconciliationResultHelper((prev) => !prev ? prev! : ({
            matches: prev.matches.filter(m => m.id !== matchId),
            unmatchedInternal: [...prev.unmatchedInternal, ...internalToRestore],
            unmatchedExternal: [...prev.unmatchedExternal, ...externalToRestore]
        }));
    };

    const importBankTransaction = (t: Transaction) => {
        const target = t.metadata?.banco_destino || selectedBankAccountName;
        // Validación Anti-Duplicados (DataGuard 🛡️)
        const isDuplicate = (props.bankTransactions[target] || []).some(existing =>
            existing.date === t.date &&
            existing.amount === t.amount &&
            existing.description === t.description
        );

        if (isDuplicate) {
            console.warn("🛡️ DataGuard: Transacción bancaria duplicada ignorada:", t.description);
            return;
        }

        const newBankTx = { ...t, id: `bank-${Date.now()}-${Math.random().toString(36).substr(2, 9)}` } as Transaction;

        props.onUpdateBankTransactions(prev => {
            const current = prev[target] || [];
            return { ...prev, [target]: [...current, newBankTx] };
        });

        if (target && !dynamicBankOptions.includes(target)) {
            setSelectedBankAccountName(target);
        }
    }

    const deleteBankTransaction = (id: string) => {
        if (!selectedBankAccountName) {
            props.onUpdateBankTransactions(prev => {
                const next = { ...prev };
                Object.keys(next).forEach(key => {
                    next[key] = next[key].filter(t => t.id !== id);
                });
                return next;
            });
        } else {
            setBankTransactionsHelper(prev => prev.filter(t => t.id !== id));
        }
    }

    // Reset selections on modal close
    const closeModal = () => {
        setIsReconciliationModalOpen(false);
        setSelectedForReconciliation(null);
        setReconciliationCandidates([]);
        setHighlightedCandidateId(null);
        setReconciliationQueue([]);
        setCurrentQueueIndex(0);
    }


    return {
        // State
        selectedBankAccountName,
        setSelectedBankAccountName,
        internalAccountFilter,
        setInternalAccountFilter,
        isInternalImportOpen,
        setIsInternalImportOpen,
        isBankImportOpen,
        setIsBankImportOpen,
        activeTab,
        setActiveTab,
        selectedInternalIds,
        setSelectedInternalIds,
        selectedExternalIds,
        setSelectedExternalIds,
        isReconciliationModalOpen,
        selectedForReconciliation,
        reconciliationCandidates,
        highlightedCandidateId,
        setHighlightedCandidateId,
        reconciliationQueue,
        currentQueueIndex,
        isFiltersLinked,
        setIsFiltersLinked,
        sharedFilters,

        // Derived
        bankTransactions,
        reconciliationResult,
        setReconciliationResult: setReconciliationResultHelper,
        dynamicInternalAccountOptions,
        dynamicBankOptions,
        displayInternal,
        displayExternal,
        selectedInternalTotal,
        selectedExternalTotal,
        globalDifference,
        canManualReconcile,
        lastImportDate,
        lastInternalDate,

        // Actions
        handleBankFilterChange,
        handleOfficialFilterChange,
        handleAutoReconcile,
        handleManualReconcile,
        handleRowClickFromBankSide,
        handleBatchSmartReconcile,
        handleConfirmReconciliation,
        handleSkipReconciliation,
        handleUnlockMatch,
        handleDeleteMatch,
        setBankTransactions: setBankTransactionsHelper,
        importBankTransaction,
        deleteBankTransaction,
        closeModal
    };
};
