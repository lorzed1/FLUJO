import React from 'react';

const Showcase: React.FC = () => {
    return (
        <div className="p-10">
            <h1 className="text-3xl font-bold">Showcase Works</h1>
        </div>
    );
};

export default Showcase;
