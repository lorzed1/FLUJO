import React, { useState, useMemo } from 'react';
import { Category, TransactionType } from '../../types';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { TrashIcon, MagnifyingGlassIcon } from '../../components/ui/Icons';
import { SmartDataTable } from '../../components/ui/SmartDataTable';

interface CategoriesViewProps {
  categories: Category[];
  addCategory: (category: Omit<Category, 'id'>) => void;
  deleteCategory: (id: string) => void;
}

const CategoryManager: React.FC<{
  title: string;
  categories: Category[];
  categoryType: TransactionType;
  addCategory: (category: Omit<Category, 'id'>) => void;
  deleteCategory: (id: string) => void;
}> = ({ title, categories, categoryType, addCategory, deleteCategory }) => {
  const [newCategoryName, setNewCategoryName] = useState('');

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;
    addCategory({ name: newCategoryName.trim(), type: categoryType });
    setNewCategoryName('');
  };

  return (
    <Card className="flex flex-col h-[500px]">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-dark-text dark:text-white uppercase tracking-tight">{title}</h2>
        <span className="text-[10px] font-semibold text-gray-400 bg-gray-100 dark:bg-slate-800 px-2 py-1 rounded-full">{categories.length} Total</span>
      </div>

      <form onSubmit={handleAddCategory} className="flex gap-2 mb-6">
        <div className="relative flex-grow">
          <Input
            type="text"
            value={newCategoryName}
            onChange={(e) => setNewCategoryName(e.target.value)}
            placeholder="Nueva categoría..."
            className="w-full pr-10"
          />
        </div>
        <Button type="submit" className="min-w-[100px]">Añadir</Button>
      </form>

      <div className="flex-1 min-h-0 bg-gray-50/50 dark:bg-slate-900/20 rounded-xl border border-gray-100 dark:border-slate-800/50 overflow-hidden">
        <SmartDataTable
          data={categories}
          columns={[
            {
              key: 'name',
              label: 'Nombre de Categoría',
              sortable: true,
              filterable: false,
              render: (val) => (
                <span className="font-semibold text-gray-700 dark:text-gray-200">{val}</span>
              )
            },
            {
              key: 'actions' as any,
              label: '',
              width: 'w-16',
              align: 'text-right',
              render: (_, cat) => (
                <button
                  onClick={(e) => { e.stopPropagation(); deleteCategory(cat.id); }}
                  className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
                  title="Eliminar categoría"
                >
                  <TrashIcon className="h-5 w-5" />
                </button>
              )
            }
          ]}
          enableSearch={true}
          enableSelection={false}
          enableExport={false}
          enableColumnConfig={false}
          searchPlaceholder="Buscar categoría..."
        />
      </div>
    </Card>
  );
};

const CategoriesView: React.FC<CategoriesViewProps> = ({ categories, addCategory, deleteCategory }) => {
  const { incomeCategories, expenseCategories } = useMemo(() => {
    return {
      incomeCategories: categories.filter((c) => c.type === TransactionType.INCOME),
      expenseCategories: categories.filter((c) => c.type === TransactionType.EXPENSE),
    };
  }, [categories]);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-semibold text-dark-text dark:text-white">Gestionar Categorías</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CategoryManager
          title="Categorías de Ingresos"
          categories={incomeCategories}
          categoryType={TransactionType.INCOME}
          addCategory={addCategory}
          deleteCategory={deleteCategory}
        />
        <CategoryManager
          title="Categorías de Gastos"
          categories={expenseCategories}
          categoryType={TransactionType.EXPENSE}
          addCategory={addCategory}
          deleteCategory={deleteCategory}
        />
      </div>
    </div>
  );
};

export default CategoriesView;
