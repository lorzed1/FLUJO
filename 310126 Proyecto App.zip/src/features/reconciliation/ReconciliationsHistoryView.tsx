import React, { useState, useMemo } from 'react';
import { ReconciliationMatch, Transaction } from '../../types';
import { formatCOP } from '../../components/ui/Input';
import { formatDateToDisplay } from '../../utils/dateUtils';
import {
    ChevronDownIcon,
    ChevronRightIcon,
    LockClosedIcon,
    TrashIcon,
    CheckCircleIcon,
    MagnifyingGlassIcon,
    FunnelIcon,
    LockOpenIcon
} from '../../components/ui/Icons';
import { SmartDataTable } from '../../components/ui/SmartDataTable';

interface ReconciliationsHistoryViewProps {
    matches: ReconciliationMatch[];
    allTransactions: Transaction[];
    onUnlock: (matchId: string) => void;
    onDelete: (matchId: string) => void;
}

const ReconciliationsHistoryView: React.FC<ReconciliationsHistoryViewProps> = ({
    matches,
    allTransactions,
    onUnlock,
    onDelete
}) => {
    const [expandedMatches, setExpandedMatches] = useState<Set<string>>(new Set());
    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState<'all' | 'locked' | 'unlocked'>('all');

    const toggleExpand = (matchId: string) => {
        const newExpanded = new Set(expandedMatches);
        if (newExpanded.has(matchId)) {
            newExpanded.delete(matchId);
        } else {
            newExpanded.add(matchId);
        }
        setExpandedMatches(newExpanded);
    };

    const getTransactionById = (id: string): Transaction | undefined => {
        return allTransactions.find(t => t.id === id);
    };

    // Filtrar matches
    const filteredMatches = useMemo(() => {
        return matches.filter(match => {
            // Filtro por estado de bloqueo
            if (filterStatus === 'locked' && !match.locked) return false;
            if (filterStatus === 'unlocked' && match.locked) return false;

            // Filtro por búsqueda
            if (searchTerm) {
                const search = searchTerm.toLowerCase();
                const externalTxns = match.externalIds.map(getTransactionById).filter(Boolean) as Transaction[];
                const internalTxns = match.internalIds.map(getTransactionById).filter(Boolean) as Transaction[];

                const matchesSearch =
                    match.date.includes(search) ||
                    match.totalAmount.toString().includes(search) ||
                    externalTxns.some(t => t.description.toLowerCase().includes(search)) ||
                    internalTxns.some(t => t.description.toLowerCase().includes(search));

                if (!matchesSearch) return false;
            }

            return true;
        });
    }, [matches, searchTerm, filterStatus]);

    // Estadísticas
    const stats = useMemo(() => {
        const total = matches.length;
        const locked = matches.filter(m => m.locked).length;
        const totalAmount = matches.reduce((sum, m) => sum + m.totalAmount, 0);
        const avgDifference = matches.length > 0
            ? matches.reduce((sum, m) => sum + m.difference, 0) / matches.length
            : 0;

        return { total, locked, totalAmount, avgDifference };
    }, [matches]);

    if (matches.length === 0) {
        return (
            <div className="flex items-center justify-center h-full">
                <div className="text-center py-12 bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 max-w-md">
                    <div className="bg-gray-100 dark:bg-slate-700 p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                        <CheckCircleIcon className="h-10 w-10 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-700 dark:text-gray-200 mb-2">
                        Sin Conciliaciones
                    </h3>
                    <p className="text-gray-500 dark:text-gray-400 text-sm">
                        Aún no has realizado ninguna conciliación.<br />
                        Ve a la pestaña "Conciliaciones" para empezar.
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div className="h-full flex flex-col space-y-4">
            {/* Header con estadísticas */}
            <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-slate-700">
                <div className="flex items-center justify-between mb-4">
                    <div>
                        <h1 className="text-2xl font-bold text-dark-text dark:text-white flex items-center gap-2">
                            <CheckCircleIcon className="h-8 w-8 text-green-600" />
                            Historial de Conciliaciones
                        </h1>
                        <p className="text-gray-500 dark:text-gray-400 text-sm">Registro completo de emparejamientos</p>
                    </div>
                </div>

                {/* Estadísticas */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                    <div className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                        <p className="text-xs text-green-600 dark:text-green-400 font-bold uppercase mb-1">Total</p>
                        <p className="text-2xl font-black text-green-700 dark:text-green-300">{stats.total}</p>
                    </div>
                    <div className="bg-gradient-to-br from-yellow-50 to-amber-50 dark:from-yellow-900/20 dark:to-amber-900/20 p-4 rounded-lg border border-yellow-200 dark:border-yellow-800">
                        <p className="text-xs text-yellow-600 dark:text-yellow-400 font-bold uppercase mb-1">Bloqueados</p>
                        <p className="text-2xl font-black text-yellow-700 dark:text-yellow-300">{stats.locked}</p>
                    </div>
                    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                        <p className="text-xs text-blue-600 dark:text-blue-400 font-bold uppercase mb-1">Monto Total</p>
                        <p className="text-lg font-black text-blue-700 dark:text-blue-300">{formatCOP(stats.totalAmount)}</p>
                    </div>
                    <div className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 p-4 rounded-lg border border-orange-200 dark:border-orange-800">
                        <p className="text-xs text-orange-600 dark:text-orange-400 font-bold uppercase mb-1">Dif. Promedio</p>
                        <p className="text-lg font-black text-orange-700 dark:text-orange-300">{formatCOP(stats.avgDifference)}</p>
                    </div>
                </div>

                {/* Filtros y búsqueda */}
                <div className="flex items-center gap-3 mt-4">
                    <div className="flex-1 relative">
                        <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Buscar por fecha, monto o descripción..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-gray-200 dark:border-slate-600 rounded-lg text-sm focus:ring-2 focus:ring-primary focus:border-transparent dark:bg-slate-700 dark:text-white"
                        />
                    </div>
                    <div className="flex items-center gap-2">
                        <FunnelIcon className="h-4 w-4 text-gray-400" />
                        <select
                            value={filterStatus}
                            onChange={(e) => setFilterStatus(e.target.value as any)}
                            className="px-3 py-2 border border-gray-200 dark:border-slate-600 rounded-lg text-sm focus:ring-2 focus:ring-primary dark:bg-slate-700 dark:text-white"
                        >
                            <option value="all">Todos</option>
                            <option value="locked">Bloqueados</option>
                            <option value="unlocked">Desbloqueados</option>
                        </select>
                    </div>
                </div>
            </div>

            {/* Lista de conciliaciones */}
            <div className="flex-1 bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 overflow-hidden flex flex-col">
                <SmartDataTable
                    data={filteredMatches}
                    columns={[
                        {
                            key: 'expand',
                            label: '',
                            width: 'w-10',
                            render: (_, match) => (
                                <button
                                    onClick={(e) => { e.stopPropagation(); toggleExpand(match.id); }}
                                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                                >
                                    {expandedMatches.has(match.id) ? (
                                        <ChevronDownIcon className="h-5 w-5" />
                                    ) : (
                                        <ChevronRightIcon className="h-5 w-5" />
                                    )}
                                </button>
                            )
                        },
                        {
                            key: 'id',
                            label: 'ID',
                            width: 'w-24',
                            render: (_, __, idx) => (
                                <span className="font-bold text-gray-900 dark:text-white">
                                    #{filteredMatches.length - (idx ?? 0)}
                                </span>
                            )
                        } as any,
                        {
                            key: 'date',
                            label: 'Fecha',
                            width: 'w-32',
                            sortable: true,
                            render: (val) => <span className="font-mono">{formatDateToDisplay(val)}</span>
                        },
                        {
                            key: 'status',
                            label: 'Estado',
                            width: 'w-24',
                            render: (val, match) => (
                                <div className="flex flex-col gap-1">
                                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold text-center ${val === 'matched_auto' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
                                        val === 'matched_manual' ? 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400' :
                                            'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400'
                                        }`}>
                                        {val === 'matched_auto' ? 'Automático' : 'Manual'}
                                    </span>
                                    {match.locked && (
                                        <span className="inline-flex items-center justify-center gap-1 px-2 py-0.5 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400 rounded-full text-[10px] font-bold">
                                            <LockClosedIcon className="h-3 w-3" />
                                            Bloqueado
                                        </span>
                                    )}
                                </div>
                            )
                        },
                        {
                            key: 'totalAmount',
                            label: 'Monto Total',
                            width: 'w-32',
                            align: 'text-right',
                            sortable: true,
                            render: (val) => <span className="font-bold text-green-600 dark:text-green-400">{formatCOP(val)}</span>
                        },
                        {
                            key: 'difference',
                            label: 'Diferencia',
                            width: 'w-32',
                            align: 'text-right',
                            render: (val) => val > 0 ? (
                                <span className="text-xs text-orange-600 dark:text-orange-400 font-bold">
                                    {formatCOP(val)}
                                </span>
                            ) : '-'
                        },
                        { key: 'ruleInfo', label: 'Regla', width: 'w-auto' },
                        {
                            key: 'actions' as any,
                            label: 'Acciones',
                            width: 'w-24',
                            align: 'text-right',
                            render: (_, match) => (
                                <div className="flex items-center justify-end gap-1">
                                    {match.locked ? (
                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                if (confirm('¿Desbloquear esta conciliación?')) onUnlock(match.id);
                                            }}
                                            className="p-2 text-yellow-600 hover:bg-yellow-50 dark:hover:bg-yellow-900/20 rounded-lg transition-colors"
                                            title="Desbloquear"
                                        >
                                            <LockOpenIcon className="h-5 w-5" />
                                        </button>
                                    ) : (
                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                if (confirm('¿Eliminar esta conciliación? Las transacciones volverán a estar pendientes.')) onDelete(match.id);
                                            }}
                                            className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                                            title="Eliminar"
                                        >
                                            <TrashIcon className="h-5 w-5" />
                                        </button>
                                    )}
                                </div>
                            )
                        }
                    ]}
                    enableSelection={false}
                    enableExport={true}
                    onRowClick={(match) => toggleExpand(match.id)}
                />
            </div>

            {/* Detalles expandidos (fuera de la tabla para no romper el layout) */}
            {expandedMatches.size > 0 && Array.from(expandedMatches).map(id => {
                const match = matches.find(m => m.id === id);
                if (!match) return null;
                const externalTxns = match.externalIds.map(getTransactionById).filter(Boolean) as Transaction[];
                const internalTxns = match.internalIds.map(getTransactionById).filter(Boolean) as Transaction[];

                return (
                    <div key={`expanded-${id}`} className="p-4 bg-gray-50 dark:bg-slate-900/30 border-t border-gray-100 dark:border-slate-800 animate-slideInDown">
                        <div className="flex items-center justify-between mb-4">
                            <h4 className="text-sm font-black text-gray-700 dark:text-white uppercase italic">Detalles Conciliación #{id.substring(0, 8)}</h4>
                            <button onClick={() => toggleExpand(match.id)} className="text-xs font-bold text-gray-400 hover:text-red-500 uppercase">Cerrar Detalle ×</button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Lado A */}
                            <div className="bg-indigo-50/50 dark:bg-indigo-900/20 p-4 rounded-xl border border-indigo-100 dark:border-indigo-800">
                                <p className="text-xs font-black text-indigo-700 dark:text-indigo-400 uppercase mb-3 flex items-center gap-2">
                                    <span className="bg-indigo-600 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px]">A</span>
                                    Lado A - Extractos ({externalTxns.length})
                                </p>
                                <div className="space-y-2">
                                    {externalTxns.map(tx => (
                                        <div key={tx.id} className="text-xs text-gray-700 dark:text-gray-300 py-2 border-b border-indigo-100/50 dark:border-indigo-800/50 flex justify-between last:border-0 hover:bg-indigo-100/30 dark:hover:bg-indigo-800/20 px-2 rounded-lg transition-colors">
                                            <div className="flex flex-col">
                                                <span className="font-bold">{tx.description}</span>
                                                <span className="opacity-50 text-[10px]">{formatDateToDisplay(tx.date)}</span>
                                            </div>
                                            <span className="font-black text-indigo-700 dark:text-indigo-300">{formatCOP(tx.amount)}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Lado B */}
                            <div className="bg-emerald-50/50 dark:bg-emerald-900/20 p-4 rounded-xl border border-emerald-100 dark:border-emerald-800">
                                <p className="text-xs font-black text-emerald-700 dark:text-emerald-400 uppercase mb-3 flex items-center gap-2">
                                    <span className="bg-emerald-600 text-white w-5 h-5 rounded-full flex items-center justify-center text-[10px]">B</span>
                                    Lado B - Libro Oficial ({internalTxns.length})
                                </p>
                                <div className="space-y-2">
                                    {internalTxns.map(tx => (
                                        <div key={tx.id} className="text-xs text-gray-700 dark:text-gray-300 py-2 border-b border-emerald-100/50 dark:border-emerald-800/50 flex justify-between last:border-0 hover:bg-emerald-100/30 dark:hover:bg-emerald-800/20 px-2 rounded-lg transition-colors">
                                            <div className="flex flex-col">
                                                <span className="font-bold">{tx.description}</span>
                                                <span className="opacity-50 text-[10px]">{formatDateToDisplay(tx.date)}</span>
                                            </div>
                                            <span className="font-black text-emerald-700 dark:text-emerald-300">{formatCOP(tx.amount)}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

export default ReconciliationsHistoryView;
