import React, { useEffect, useRef } from 'react';
import { Transaction, ReconciliationCandidate } from '../../types';
import { formatCOP } from '../../components/ui/Input';
import { formatDateToDisplay } from '../../utils/dateUtils';
import { CheckCircleIcon, XCircleIcon, LockClosedIcon } from '../../components/ui/Icons';

interface ReconciliationModalProps {
    isOpen: boolean;
    selectedTransaction: Transaction;
    candidates: ReconciliationCandidate[];
    onConfirm: (candidateTransaction: Transaction) => void;
    onSkip?: () => void;
    onCancel: () => void;
    onScrollToCandidate?: (transactionId: string) => void;
    batchInfo?: {
        current: number;
        total: number;
    };
}

const ReconciliationModal: React.FC<ReconciliationModalProps> = ({
    isOpen,
    selectedTransaction,
    candidates,
    onConfirm,
    onSkip,
    onCancel,
    onScrollToCandidate,
    batchInfo
}) => {
    const modalRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen && candidates.length > 0 && onScrollToCandidate) {
            // Auto-scroll al mejor candidato
            setTimeout(() => {
                onScrollToCandidate(candidates[0].transaction.id);
            }, 300);
        }
    }, [isOpen, candidates, onScrollToCandidate]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
            <div
                ref={modalRef}
                className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col border border-gray-200 dark:border-slate-700"
            >
                {/* Header */}
                <div className="bg-gradient-to-r from-indigo-600 to-blue-600 p-6 text-white">
                    <div className="flex items-center justify-between">
                        <div>
                            <h2 className="text-2xl font-bold mb-1">🔍 Modo Conciliación Interactiva</h2>
                            <p className="text-indigo-100 text-sm">
                                {batchInfo
                                    ? `Procesando lote: Registro ${batchInfo.current} de ${batchInfo.total}`
                                    : 'Buscando coincidencias para el registro seleccionado'
                                }
                            </p>
                        </div>
                        <button
                            onClick={onCancel}
                            className="text-white hover:bg-white/20 p-2 rounded-lg transition-colors"
                        >
                            <XCircleIcon className="h-6 w-6" />
                        </button>
                    </div>
                </div>

                {/* Selected Transaction Info */}
                <div className="bg-indigo-50 dark:bg-indigo-900/20 p-4 border-b border-indigo-100 dark:border-indigo-800">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-xs text-gray-500 dark:text-gray-400 font-bold uppercase mb-1">Registro Seleccionado (Lado A)</p>
                            <p className="font-bold text-gray-900 dark:text-white">{selectedTransaction.description}</p>
                            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                                <span className="font-mono">{formatDateToDisplay(selectedTransaction.date)}</span>
                                {selectedTransaction.metadata?.documento && (
                                    <span className="ml-3 text-indigo-600 dark:text-indigo-400">Ref: {selectedTransaction.metadata.documento}</span>
                                )}
                            </p>
                        </div>
                        <div className="text-right">
                            <p className="text-xs text-gray-500 dark:text-gray-400 font-bold uppercase mb-1">Monto</p>
                            <p className={`text-2xl font-bold ${selectedTransaction.type === 'income' ? 'text-green-600' : 'text-gray-900 dark:text-white'}`}>
                                {formatCOP(selectedTransaction.amount)}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Candidates List */}
                <div className="flex-1 overflow-y-auto p-4">
                    {candidates.length > 0 ? (
                        <div className="space-y-3">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-sm font-bold text-gray-700 dark:text-gray-200 uppercase tracking-wide">
                                    {candidates.length} Candidato{candidates.length !== 1 ? 's' : ''} Encontrado{candidates.length !== 1 ? 's' : ''}
                                </h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400">Ordenados por probabilidad</p>
                            </div>

                            {candidates.map((candidate, idx) => (
                                <div
                                    key={candidate.transaction.id}
                                    className={`p-4 rounded-xl border-2 transition-all cursor-pointer hover:shadow-lg ${idx === 0
                                        ? 'border-green-400 bg-green-50 dark:bg-green-900/20'
                                        : 'border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-indigo-300'
                                        }`}
                                    onClick={() => onConfirm(candidate.transaction)}
                                >
                                    <div className="flex items-start justify-between">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-2 mb-2">
                                                {idx === 0 && (
                                                    <span className="bg-green-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                                                        Mejor Match
                                                    </span>
                                                )}
                                                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${candidate.score >= 75 ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' :
                                                    candidate.score >= 50 ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400' :
                                                        'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400'
                                                    }`}>
                                                    {candidate.score}% Match
                                                </span>
                                            </div>

                                            {/* Jerarquía Principal: Fecha, Valor y Tercero */}
                                            <div className="flex items-center justify-between mb-3 border-b border-gray-100 dark:border-slate-800 pb-2">
                                                <div className="flex flex-col gap-1">
                                                    <span className="text-[14px] font-bold text-slate-900 dark:text-white leading-tight">
                                                        {candidate.transaction.metadata?.tercero || 'SIN TERCERO'}
                                                        {candidate.transaction.metadata?.nit && (
                                                            <span className="text-slate-400 font-normal text-[11px] ml-1.5">
                                                                ({candidate.transaction.metadata.nit})
                                                            </span>
                                                        )}
                                                    </span>
                                                    <span className="text-[12px] font-semibold text-slate-500">
                                                        {formatDateToDisplay(candidate.transaction.date)}
                                                    </span>
                                                </div>
                                                <div className="text-right">
                                                    <span className={`text-[16px] font-bold ${candidate.transaction.type === 'income' ? 'text-green-600' : 'text-slate-900 dark:text-white'}`}>
                                                        {formatCOP(candidate.transaction.amount)}
                                                    </span>
                                                </div>
                                            </div>

                                            {/* Datos Secundarios: Descripción, Documento, Cuenta */}
                                            <div className="space-y-1.5 mb-3">
                                                <p className="text-[12px] text-slate-600 dark:text-gray-400 font-medium italic">
                                                    "{candidate.transaction.description}"
                                                </p>
                                                <div className="flex flex-wrap gap-x-4 gap-y-1">
                                                    {candidate.transaction.metadata?.documento && (
                                                        <div className="flex items-center gap-1.5">
                                                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Documento:</span>
                                                            <span className="text-[11px] font-semibold text-slate-700 dark:text-gray-300">
                                                                {candidate.transaction.metadata.documento}
                                                            </span>
                                                        </div>
                                                    )}
                                                    {candidate.transaction.metadata?.cuenta_nombre && (
                                                        <div className="flex items-center gap-1.5">
                                                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Cuenta:</span>
                                                            <span className="text-[11px] font-semibold text-indigo-600/70 dark:text-indigo-400/70">
                                                                {candidate.transaction.metadata.cuenta_nombre}
                                                            </span>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>

                                            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-900/20 px-2.5 py-1 rounded-lg inline-flex items-center gap-1.5 border border-emerald-100 dark:border-emerald-800/30">
                                                <span className="text-[13px]">💡</span> {candidate.reason}
                                            </p>
                                        </div>

                                        <button
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                e.preventDefault();
                                                onConfirm(candidate.transaction);
                                            }}
                                            className="ml-4 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-bold text-sm transition-all transform hover:scale-105 shadow-md flex-shrink-0"
                                        >
                                            <CheckCircleIcon className="h-5 w-5 inline mr-1" />
                                            Confirmar
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-12">
                            <div className="bg-gray-100 dark:bg-slate-700 p-6 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                                <XCircleIcon className="h-10 w-10 text-gray-400" />
                            </div>
                            <h3 className="text-lg font-bold text-gray-700 dark:text-gray-200 mb-2">
                                No se encontraron candidatos
                            </h3>
                            <p className="text-gray-500 dark:text-gray-400 text-sm max-w-md mx-auto">
                                No hay transacciones en el Libro Oficial que coincidan con los criterios de búsqueda.
                                Intenta ajustar los filtros o realiza una conciliación manual.
                            </p>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="bg-gray-50 dark:bg-slate-900 p-4 border-t border-gray-200 dark:border-slate-700 flex justify-between items-center">
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                        <LockClosedIcon className="h-4 w-4 inline mr-1" />
                        Las conciliaciones confirmadas se bloquearán automáticamente
                    </p>
                    <div className="flex gap-3">
                        {batchInfo && onSkip && (
                            <button
                                onClick={onSkip}
                                className="px-4 py-2 bg-amber-50 dark:bg-amber-900/20 hover:bg-amber-100 text-amber-700 dark:text-amber-400 rounded-lg font-bold border border-amber-200 dark:border-amber-800 transition-colors"
                            >
                                Saltar / Siguiente
                            </button>
                        )}
                        <button
                            onClick={onCancel}
                            className="px-4 py-2 bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 dark:hover:bg-slate-600 text-gray-700 dark:text-gray-200 rounded-lg font-medium transition-colors"
                        >
                            Cancelar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ReconciliationModal;
