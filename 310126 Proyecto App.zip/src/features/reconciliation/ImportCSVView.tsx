import React, { useState, useRef, useEffect, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { Transaction, TransactionType, Category, ExpenseType } from '../../types';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { ArrowDownTrayIcon, CheckCircleIcon, TrashIcon, MagnifyingGlassIcon } from '../../components/ui/Icons';
import { formatCOP, parseCOP } from '../../components/ui/Input';
import { formatDateToDisplay } from '../../utils/dateUtils';
import { DataService } from '../../services/storage';

// Alias para consistencia con código pegado
const formatCurrency = formatCOP;

interface ImportCSVViewProps {
    addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
    categories: Category[];
    existingTransactions?: Transaction[];
    onComplete?: () => void;
    mode?: 'full' | 'bank';
    availableAccounts?: string[]; // Para modo banco, sugerir nombres de cuenta existentes
}

type ProcessedRow = {
    id: string; // Temporal ID
    data: Omit<Transaction, 'id'>;
    isDuplicate: boolean;
    isValid: boolean;
    selected: boolean;
    rawRow: string[];
};

const ImportCSVView: React.FC<ImportCSVViewProps> = ({ addTransaction, categories, existingTransactions = [], onComplete, mode = 'full', availableAccounts = [] }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [csvData, setCsvData] = useState<string[][]>([]);
    const [headers, setHeaders] = useState<string[]>([]);
    const [fileName, setFileName] = useState('');

    const [columnMapping, setColumnMapping] = useState<{
        date: number;
        description: number;
        amount: number;       // Monto Global (con signo)
        debit: number;        // Columna Débito (Salidas)
        credit: number;       // Columna Crédito (Entradas)
        type: number;
        // Metadata fields
        doc_ref: number;
        tercero_nit: number;
        tercero_nombre: number;
        cuenta_codigo: number;
        cuenta_nombre: number;
        description_mov: number;
    }>({
        date: -1, description: -1, amount: -1, debit: -1, credit: -1, type: -1,
        doc_ref: -1, tercero_nit: -1, tercero_nombre: -1, cuenta_codigo: -1, cuenta_nombre: -1,
        description_mov: -1
    });

    const [processedRows, setProcessedRows] = useState<ProcessedRow[]>([]);
    const [showPreview, setShowPreview] = useState(false);

    // NUEVOS ESTADOS PARA ASIGNACIÓN MASIVA
    const [previewSearch, setPreviewSearch] = useState('');
    const [bulkCategoryId, setBulkCategoryId] = useState('');
    const [targetAccount, setTargetAccount] = useState<string>('');
    const [isCreatingNewAccount, setIsCreatingNewAccount] = useState(false);
    const [newAccountName, setNewAccountName] = useState('');

    const filteredRows = useMemo(() => {
        if (!previewSearch) return processedRows;
        const lowSearch = previewSearch.toLowerCase();
        return processedRows.filter(row =>
            row.data.description.toLowerCase().includes(lowSearch) ||
            String(row.data.metadata?.documento || '').toLowerCase().includes(lowSearch) ||
            String(row.data.metadata?.tercero || '').toLowerCase().includes(lowSearch)
        );
    }, [processedRows, previewSearch]);

    // Función para encontrar la fila de encabezados real
    const findHeaderRow = (data: string[][]) => {
        const headerKeywords = ['fecha', 'date', 'descripcion', 'descripción', 'monto', 'valor', 'debito', 'débito', 'credito', 'crédito', 'documento', 'referencia'];

        // Analizar las primeras 20 filas
        const maxRowsToSearch = Math.min(data.length, 20);
        let bestRowIdx = 0;
        let maxMatches = 0;

        for (let i = 0; i < maxRowsToSearch; i++) {
            const row = data[i];
            let matches = 0;
            row.forEach(cell => {
                const lowCell = String(cell || '').toLowerCase().trim();
                if (headerKeywords.some(k => lowCell.includes(k))) matches++;
            });

            if (matches > maxMatches) {
                maxMatches = matches;
                bestRowIdx = i;
            }
        }
        return bestRowIdx;
    };

    // Función unificada para procesar datos crudos (Array de Arrays de Strings)
    const processRawData = (data: string[][]) => {
        if (!data || data.length < 2) {
            alert('El archivo parece estar vacío o no tiene encabezados.');
            return;
        }

        const headerIdx = findHeaderRow(data);
        const newHeaders = data[headerIdx];

        // Solo guardar encabezados que tengan texto (filtrar ruidos de Excel)
        setHeaders(newHeaders);
        // Los datos empiezan después de los encabezados
        setCsvData(data.slice(headerIdx + 1));
        setProcessedRows([]);
        setShowPreview(false);

        // AUTO-DETECCIÓN DE COLUMNAS
        const mapping: any = {
            date: -1, description: -1, amount: -1, debit: -1, credit: -1, type: -1,
            doc_ref: -1, tercero_nit: -1, tercero_nombre: -1, cuenta_codigo: -1, cuenta_nombre: -1,
            description_mov: -1
        };

        const keywords: Record<string, string[]> = {
            date: ['fecha', 'date', 'día', 'dia', 'momento'],
            description: ['descripcion', 'descripción', 'description', 'detalle', 'concepto', 'memo'],
            amount: ['monto', 'valor', 'amount', 'total', 'saldo'],
            debit: ['debito', 'débito', 'debit', 'egreso', 'salida', 'cargo', 'retiro'],
            credit: ['credito', 'crédito', 'credit', 'ingreso', 'entrada', 'abono', 'deposito'],
            doc_ref: ['documento', 'referencia', 'numero', 'doc', 'ref', 'comprobante', 'documento'],
            tercero_nit: ['nit', 'identificacion', 'id', 'rut', 'cedula', 'identificación'],
            tercero_nombre: ['tercero', 'nombre', 'cliente', 'proveedor', 'beneficiario', 'razon social', 'nombre_tercero', 'nom', 'contacto'],
            cuenta_codigo: ['codigo cuenta', 'cod cuenta', 'puc', 'cuenta codigo', 'cod', 'cuenta_puc', 'cuenta'],
            cuenta_nombre: ['nombre cuenta', 'denominacion', 'cuenta contable', 'nombre_cuenta', 'detalle cuenta', 'nombre de cuenta'],
            description_mov: ['descripción del movimiento', 'descripcion del movimiento', 'detalle movimiento', 'movimiento']
        };

        newHeaders.forEach((h, idx) => {
            if (!h || String(h).trim() === '') return;
            const lowerH = String(h).toLowerCase();
            for (const [field, words] of Object.entries(keywords)) {
                if (mapping[field] !== -1) continue;
                // En modo 'full' (Libro), no queremos detectar columna 'type' automáticamente
                if (field === 'type' && mode === 'full') continue;

                if (words.some(word => lowerH.includes(word))) {
                    mapping[field] = idx;
                    break;
                }
            }
        });

        setColumnMapping(mapping);
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setFileName(file.name);

        // Detección de tipo
        const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');

        if (isExcel) {
            const reader = new FileReader();
            reader.onload = (evt) => {
                try {
                    const bstr = evt.target?.result;
                    const wb = XLSX.read(bstr, { type: 'binary', cellDates: true });

                    // --- NUEVA LÓGICA: Encontrar la hoja con más datos ---
                    let bestSheetName = wb.SheetNames[0];
                    let maxRows = 0;

                    wb.SheetNames.forEach(name => {
                        const ws = wb.Sheets[name];
                        const ref = ws['!ref'];
                        if (ref) {
                            const range = XLSX.utils.decode_range(ref);
                            const rowCount = range.e.r - range.s.r;
                            if (rowCount > maxRows) {
                                maxRows = rowCount;
                                bestSheetName = name;
                            }
                        }
                    });

                    const ws = wb.Sheets[bestSheetName];
                    const rawData = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' }) as any[][];

                    // Convert to string array, handling dates specially
                    const data: string[][] = rawData.map(row =>
                        row.map(cell => {
                            // If it's a Date object, format it
                            if (cell instanceof Date) {
                                const year = cell.getFullYear();
                                const month = String(cell.getMonth() + 1).padStart(2, '0');
                                const day = String(cell.getDate()).padStart(2, '0');
                                return `${year}-${month}-${day}`;
                            }
                            // Otherwise convert to string
                            return String(cell ?? '').trim();
                        })
                    );

                    processRawData(data);
                } catch (err) {
                    console.error('Error parsing Excel:', err);
                    alert('Error al leer el archivo Excel. Asegúrate de que no esté corrupto.');
                }
            };
            reader.readAsBinaryString(file);
        } else {
            // CSV Fallback
            const reader = new FileReader();
            reader.onload = (evt) => {
                const text = evt.target?.result as string;
                const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');
                if (lines.length === 0) return;

                const firstLine = lines[0];
                const separator = firstLine.includes(';') ? ';' : ',';
                const parsedData = lines.map(line => line.split(separator).map(cell => cell.trim().replace(/^"|"$/g, '')));

                processRawData(parsedData);
            };
            reader.readAsText(file);
        }
    };

    const updateMapping = (field: keyof typeof columnMapping, index: string) => {
        setColumnMapping(prev => ({ ...prev, [field]: parseInt(index) }));
    };

    // Helper to strictly parse import amounts
    // Accepts: (5000), -5000, 5000-, 5.000,00
    const parseImportAmount = (value: string): number => {
        if (!value) return 0;
        let str = String(value).trim();

        // 1. Detect negative by parenthesis: (5000) -> -5000
        const isParenthesisNegative = str.startsWith('(') && str.endsWith(')');
        if (isParenthesisNegative) {
            str = str.slice(1, -1);
        }

        // 2. Detect negative by trailing sign: 5000- -> -5000
        const isTrailingNegative = str.endsWith('-');
        if (isTrailingNegative) {
            str = str.slice(0, -1); // Remove trailing '-'
        }

        // 3. Clean structure using standard parseCOP but strictly for value
        const absValue = parseCOP(str);

        // 4. Apply sign
        if (isParenthesisNegative || isTrailingNegative || str.startsWith('-')) {
            return -Math.abs(absValue);
        }

        return absValue;
    };

    // Helper to clean numbers -> DELEGATED TO parseImportAmount
    const parseNumber = (value: string): number => {
        return parseImportAmount(value);
    };

    // Process Data based on mapping
    useEffect(() => {
        const hasAmount = columnMapping.amount !== -1;
        const hasDebitCredit = columnMapping.debit !== -1 && columnMapping.credit !== -1;

        if (columnMapping.date === -1 || columnMapping.description === -1 || (!hasAmount && !hasDebitCredit)) {
            setShowPreview(false);
            return;
        }

        // Map strictly 1:1 with csvData to preserve order
        const newProcessedRows: ProcessedRow[] = csvData.map((row, idx) => {
            const maxIndex = Math.max(...Object.values(columnMapping).map(v => Number(v)));

            // If row is too short, return an invalid placeholder
            if (row.length <= maxIndex) {
                return { id: `tmp-${idx}`, data: {} as any, isDuplicate: false, isValid: false, selected: false, rawRow: row };
            }

            // Extract Data
            const dateRaw = row[columnMapping.date];
            const descRaw = row[columnMapping.description];

            let amount = 0;
            let type: TransactionType | undefined = mode === 'bank' ? TransactionType.EXPENSE : undefined;
            // let isDebitTransaction = false; // REMOVED: Rely strictly on sign

            let debitValue = 0;
            let creditValue = 0;

            if (hasDebitCredit) {
                debitValue = Math.abs(parseNumber(String(row[columnMapping.debit] || '0')));
                creditValue = Math.abs(parseNumber(String(row[columnMapping.credit] || '0')));

                // Lógica contable diferenciada por lado:
                // Lado A (Banco): Débito = Salida (Expense), Crédito = Entrada (Income)
                // Lado B (Libro): Débito = Entrada (Income), Crédito = Salida (Expense)
                if (debitValue > 0) {
                    amount = debitValue;
                    type = mode === 'full' ? TransactionType.INCOME : TransactionType.EXPENSE;
                } else {
                    amount = creditValue;
                    type = mode === 'full' ? TransactionType.EXPENSE : TransactionType.INCOME;
                }
            } else {
                // Single amount column - STRICT SIGN RESPECT
                const rawAmount = parseNumber(row[columnMapping.amount]);
                amount = Math.abs(rawAmount);

                if (mode === 'bank') {
                    // Mode Bank: Negative = Expense, Positive = Income
                    if (rawAmount < 0) {
                        type = TransactionType.EXPENSE;
                        debitValue = amount;
                    } else {
                        type = TransactionType.INCOME;
                        creditValue = amount;
                    }
                } else {
                    // Mode Full: Signed amount determines debit/credit columns but type is Pending
                    if (rawAmount < 0) {
                        debitValue = amount;
                    } else {
                        creditValue = amount;
                    }
                    type = undefined; // Force manual classification
                }
            }

            // If strict 0, mark as invalid but KEEP row to preserve order
            if (amount === 0) {
                return { id: `tmp-${idx}`, data: { description: descRaw, date: dateRaw } as any, isDuplicate: false, isValid: false, selected: false, rawRow: row };
            }

            // Category Initialization
            let categoryId = '';

            // Metadata Extraction
            const metadata: Record<string, any> = {};
            if (columnMapping.doc_ref !== -1) metadata.documento = row[columnMapping.doc_ref];
            if (columnMapping.tercero_nit !== -1) metadata.nit = row[columnMapping.tercero_nit];
            if (columnMapping.tercero_nombre !== -1) metadata.tercero = row[columnMapping.tercero_nombre];
            if (columnMapping.cuenta_codigo !== -1) metadata.cuenta_codigo = row[columnMapping.cuenta_codigo];
            if (columnMapping.cuenta_nombre !== -1) metadata.cuenta_nombre = row[columnMapping.cuenta_nombre];
            if (columnMapping.description_mov !== -1) metadata.descripcion_movimiento = row[columnMapping.description_mov];

            metadata.debit = debitValue;
            metadata.credit = creditValue;

            let finalDescription = descRaw || '';
            if (columnMapping.description_mov !== -1 && row[columnMapping.description_mov]) {
                const movDesc = row[columnMapping.description_mov];
                if (movDesc !== finalDescription) {
                    finalDescription = `${finalDescription} - ${movDesc}`.trim();
                }
            }

            // Normalize Date
            let finalDate = new Date().toISOString().slice(0, 10);
            if (dateRaw) {
                // ... (Existing Date Parsing Logic - Kept as is for now)
                let trimmedDate = String(dateRaw).trim();
                const numDate = Number(trimmedDate);
                if (!isNaN(numDate) && numDate > 10000 && numDate < 60000 && !trimmedDate.includes('-') && !trimmedDate.includes('/')) {
                    const excelEpoch = new Date(1899, 11, 30);
                    const dateObj = new Date(excelEpoch.getTime() + numDate * 86400000);
                    finalDate = dateObj.toISOString().slice(0, 10);
                } else if (/^\d{4}-\d{2}-\d{2}$/.test(trimmedDate)) {
                    finalDate = trimmedDate;
                } else if (trimmedDate.includes('/')) {
                    const parts = trimmedDate.split('/');
                    if (parts.length === 3) {
                        // Simple heuristic: if part[2] is year...
                        if (parts[2].length === 4) finalDate = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
                        else if (parts[0].length === 4) finalDate = `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
                    }
                } else if (trimmedDate.includes('-')) {
                    const parts = trimmedDate.split('-');
                    if (parts.length === 3 && parts[2].length === 4) {
                        finalDate = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
                    }
                }
            }

            const transactionData: Omit<Transaction, 'id'> = {
                date: finalDate,
                description: finalDescription,
                amount: Math.abs(amount),
                type,
                expenseType: ExpenseType.VARIABLE,
                categoryId,
                isRecurring: false,
                metadata: Object.keys(metadata).length > 0 ? metadata : undefined
            };

            // Duplication Logic (simplified for speed in map)
            // Note: intra-file dup check is harder in simple map without accumulation, but acceptable to skip complexity for now or use find on previous index
            const isRefDuplicateInFile = false; // Simplify for now to prioritize order

            let isDuplicateInDB = false;
            // ... (Existing DB duplicate logic)
            if (existingTransactions.length > 0) {
                isDuplicateInDB = existingTransactions.some(t => {
                    const sameDate = t.date === transactionData.date;
                    const sameAmount = Math.abs(t.amount - transactionData.amount) < 1;
                    // Weak check
                    return sameDate && sameAmount;
                });
            }

            return {
                id: `tmp-${idx}`,
                data: transactionData,
                isDuplicate: isDuplicateInDB,
                isValid: transactionData.amount > 0 && !!transactionData.date,
                selected: !isDuplicateInDB && transactionData.amount > 0,
                rawRow: row
            };
        });

        setProcessedRows(newProcessedRows);
        setShowPreview(true);

    }, [columnMapping, csvData, categories, existingTransactions, mode]);

    const toggleRowSelection = (id: string) => {
        setProcessedRows(prev => prev.map(row =>
            row.id === id ? { ...row, selected: !row.selected } : row
        ));
    };

    const updateRowCategory = (id: string, catId: string) => {
        setProcessedRows(prev => prev.map(row =>
            row.id === id ? { ...row, data: { ...row.data, categoryId: catId } } : row
        ));
    };

    const updateRowType = (id: string, type: TransactionType) => {
        setProcessedRows(prev => prev.map(row =>
            row.id === id ? { ...row, data: { ...row.data, type, categoryId: '' } } : row
        ));
    };

    const handleBulkApplyCategory = () => {
        if (!bulkCategoryId) {
            alert('Por favor selecciona una categoría primero.');
            return;
        }

        const count = filteredRows.length;
        if (count === 0) return;

        if (confirm(`¿Asignar la categoría seleccionada a las ${count} transacciones visibles?`)) {
            const visibleIds = new Set(filteredRows.map(r => r.id));
            setProcessedRows(prev => prev.map(row =>
                visibleIds.has(row.id) ? { ...row, data: { ...row.data, categoryId: bulkCategoryId } } : row
            ));
            setBulkCategoryId('');
            setPreviewSearch('');
            alert('¡Categorías asignadas con éxito!');
        }
    };

    const handleFinalImport = async () => {
        if (mode === 'bank' && !targetAccount && !newAccountName) {
            alert('Por favor selecciona o crea una cuenta de destino para este extracto.');
            return;
        }

        const finalAccount = isCreatingNewAccount ? newAccountName.trim().toUpperCase() : targetAccount;

        const selectedRows = processedRows.filter(r => r.selected);
        if (selectedRows.length === 0) {
            alert('No hay transacciones seleccionadas para importar.');
            return;
        }

        selectedRows.forEach(row => {
            const dataWithAccount = {
                ...row.data,
                metadata: {
                    ...row.data.metadata,
                    banco_destino: finalAccount // Campo automático para identificar fuente
                }
            };
            addTransaction(dataWithAccount);
        });

        alert(`¡Éxito! Se importaron ${selectedRows.length} transacciones a la cuenta ${finalAccount}.`);
        setFileName('');
        setCsvData([]);
        setProcessedRows([]);
        setShowPreview(false);
        if (onComplete) onComplete();
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-dark-text">Importar {mode === 'bank' ? 'Extracto Bancario' : 'Transacciones'}</h1>

            {/* 1. Upload Section */}
            {!csvData.length && (
                <Card className="p-12 border-dashed border-2 border-gray-200 dark:border-slate-700 bg-gray-50/50 dark:bg-slate-800/50 flex flex-col items-center justify-center text-center gap-4 hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors">
                    <div className="p-5 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-full mb-2">
                        <ArrowDownTrayIcon className="h-12 w-12" />
                    </div>
                    <div>
                        <h3 className="text-xl font-bold text-gray-700 dark:text-gray-200">Sube tu archivo {mode === 'bank' ? 'del Banco' : 'CSV'}</h3>
                        <p className="text-gray-500 dark:text-gray-400 mt-1">Soporta .csv y .xlsx</p>
                    </div>
                    <input type="file" accept=".csv, .xlsx, .xls" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                    <Button type="button" className="mt-4" onClick={() => fileInputRef.current?.click()}>Seleccionar Archivo</Button>
                </Card>
            )}

            {/* 2. Mapping & Preview Section */}
            {csvData.length > 0 && (
                <div className="space-y-6 animate-in slide-in-from-bottom duration-500">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white dark:bg-slate-800 p-4 rounded-3xl border border-gray-100 dark:border-slate-700 shadow-sm">
                        <p className="font-medium text-slate-700 dark:text-gray-200 text-sm">Archivo: <span className="text-primary font-black ml-1 bg-indigo-50 dark:bg-indigo-900/40 px-2 py-0.5 rounded-lg border border-indigo-100 dark:border-indigo-800">{fileName}</span> <span className="text-slate-400 ml-2 text-xs font-bold">({csvData.length} filas detectadas)</span></p>

                        {mode === 'bank' && (
                            <div className="flex items-center gap-2 bg-indigo-50/50 dark:bg-indigo-900/10 p-2 rounded-2xl border border-indigo-100 dark:border-indigo-800">
                                <label className="text-[10px] font-black text-indigo-700 dark:text-indigo-300 uppercase px-2">Importar a:</label>
                                {isCreatingNewAccount ? (
                                    <div className="flex items-center gap-2">
                                        <input
                                            type="text"
                                            placeholder="Nombre de nueva cuenta..."
                                            className="p-1.5 text-xs font-bold border border-indigo-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-100"
                                            value={newAccountName}
                                            onChange={e => setNewAccountName(e.target.value)}
                                            autoFocus
                                        />
                                        <button onClick={() => setIsCreatingNewAccount(false)} className="text-[10px] font-bold text-gray-400 hover:text-indigo-600">Volver</button>
                                    </div>
                                ) : (
                                    <select
                                        className="p-1.5 text-xs font-bold border border-indigo-200 rounded-lg outline-none bg-white dark:bg-slate-800 dark:text-indigo-300"
                                        value={targetAccount}
                                        onChange={e => {
                                            if (e.target.value === 'NEW') setIsCreatingNewAccount(true);
                                            else setTargetAccount(e.target.value);
                                        }}
                                    >
                                        <option value="">Seleccionar cuenta...</option>
                                        {availableAccounts.map(acc => <option key={acc} value={acc}>{acc}</option>)}
                                        <option value="NEW">+ CREAR NUEVA CUENTA</option>
                                    </select>
                                )}
                            </div>
                        )}

                        <button onClick={() => setCsvData([])} className="text-rose-500 hover:text-rose-600 hover:bg-rose-50 px-3 py-1.5 rounded-lg transition-all text-xs font-black uppercase">Cancelar / Subir otro</button>
                    </div>

                    <Card className="space-y-6 border-indigo-100/50 shadow-md shadow-indigo-500/5">
                        <div className="flex justify-between border-b border-gray-100 dark:border-slate-800 pb-4">
                            <h3 className="font-black text-lg text-slate-800 dark:text-white flex items-center gap-2">
                                <span className="bg-indigo-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs">1</span>
                                Mapeo de Columnas
                            </h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-6">
                            {mode === 'bank' ? (
                                <>
                                    {/* MODO BANCO: Solo 4 campos según imagen */}
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Fecha <span className="text-rose-500">*</span></label>
                                        <MappingSelect headers={headers} csvData={csvData} value={columnMapping.date} onChange={(val) => updateMapping('date', val)} />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Descripción <span className="text-rose-500">*</span></label>
                                        <MappingSelect headers={headers} csvData={csvData} value={columnMapping.description} onChange={(val) => updateMapping('description', val)} />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Referencia <span className="text-rose-500">*</span></label>
                                        <MappingSelect headers={headers} csvData={csvData} value={columnMapping.doc_ref} onChange={(val) => updateMapping('doc_ref', val)} />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Valor <span className="text-rose-500">*</span></label>
                                        <MappingSelect headers={headers} csvData={csvData} value={columnMapping.amount} onChange={(val) => updateMapping('amount', val)} />
                                    </div>
                                </>
                            ) : (
                                <>
                                    {/* MODO FULL (Lado B): Interfaz simplificada según imagen solicitada */}
                                    <div className="col-span-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                        <div>
                                            <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Fecha <span className="text-rose-500">*</span></label>
                                            <MappingSelect headers={headers} csvData={csvData} value={columnMapping.date} onChange={(val) => updateMapping('date', val)} />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Descripción <span className="text-rose-500">*</span></label>
                                            <MappingSelect headers={headers} csvData={csvData} value={columnMapping.description} onChange={(val) => updateMapping('description', val)} />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Desc. Movimiento</label>
                                            <MappingSelect headers={headers} csvData={csvData} value={columnMapping.description_mov} onChange={(val) => updateMapping('description_mov', val)} />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Documento / Ref</label>
                                            <MappingSelect headers={headers} csvData={csvData} value={columnMapping.doc_ref} onChange={(val) => updateMapping('doc_ref', val)} />
                                        </div>

                                        <div>
                                            <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Cuenta (Código)</label>
                                            <MappingSelect headers={headers} csvData={csvData} value={columnMapping.cuenta_codigo} onChange={(val) => updateMapping('cuenta_codigo', val)} />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Nombre de Cuenta</label>
                                            <MappingSelect headers={headers} csvData={csvData} value={columnMapping.cuenta_nombre} onChange={(val) => updateMapping('cuenta_nombre', val)} />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Contacto (Nombre)</label>
                                            <MappingSelect headers={headers} csvData={csvData} value={columnMapping.tercero_nombre} onChange={(val) => updateMapping('tercero_nombre', val)} />
                                        </div>
                                        <div>
                                            <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">Identificación (NIT)</label>
                                            <MappingSelect headers={headers} csvData={csvData} value={columnMapping.tercero_nit} onChange={(val) => updateMapping('tercero_nit', val)} />
                                        </div>

                                        {/* Bloque de Valores (Débito/Crédito) */}
                                        <div className="col-span-full p-4 bg-indigo-50/50 dark:bg-indigo-900/10 rounded-2xl border border-indigo-100 dark:border-indigo-900/50 grid grid-cols-1 md:grid-cols-2 gap-6 mt-2">
                                            <div className="space-y-4">
                                                <div className="flex items-center justify-between">
                                                    <p className="text-[10px] font-black text-indigo-800 dark:text-indigo-300 uppercase tracking-widest">Columna Débito</p>
                                                </div>
                                                <MappingSelect headers={headers} csvData={csvData} value={columnMapping.debit} onChange={(val) => updateMapping('debit', val)} />
                                            </div>
                                            <div className="space-y-4">
                                                <div className="flex items-center justify-between">
                                                    <p className="text-[10px] font-black text-indigo-800 dark:text-indigo-300 uppercase tracking-widest">Columna Crédito</p>
                                                </div>
                                                <MappingSelect headers={headers} csvData={csvData} value={columnMapping.credit} onChange={(val) => updateMapping('credit', val)} />
                                            </div>
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>
                    </Card>
                </div>
            )}

            {/* 3. Preview & Actions Section */}
            {csvData.length > 0 && (
                <div className="space-y-4 animate-in slide-in-from-bottom duration-700 delay-100">

                    {/* Barra de Asignación Masiva (SOLO FULL) */}
                    {mode === 'full' && (
                        <div className="flex flex-col md:flex-row justify-between items-end gap-4 bg-white dark:bg-slate-800 p-4 rounded-3xl border border-gray-100 dark:border-slate-700 shadow-sm">
                            <div className="w-full md:w-auto flex-1 gap-4 flex flex-col md:flex-row">
                                <div className="w-full md:w-64">
                                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Asignación Masiva</label>
                                    <div className="flex gap-2">
                                        <select
                                            className="w-full p-2 border border-slate-200 rounded-xl text-xs font-bold bg-slate-50 dark:bg-slate-700 dark:text-gray-200 dark:border-slate-600 focus:ring-2 focus:ring-indigo-100 outline-none"
                                            value={bulkCategoryId}
                                            onChange={(e) => setBulkCategoryId(e.target.value)}
                                        >
                                            <option value="">Seleccionar Categoría...</option>
                                            <optgroup label="Ingresos">
                                                {categories.filter(c => c.type === TransactionType.INCOME).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                            </optgroup>
                                            <optgroup label="Egresos">
                                                {categories.filter(c => c.type === TransactionType.EXPENSE).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                            </optgroup>
                                        </select>
                                        <Button
                                            type="button"
                                            onClick={handleBulkApplyCategory}
                                            variant="secondary"
                                            size="sm"
                                            className="whitespace-nowrap"
                                            disabled={!bulkCategoryId || !previewSearch && filteredRows.length === 0}
                                        >
                                            Aplicar
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    <div className="flex gap-3 justify-end w-full">
                        <Button
                            variant="ghost"
                            onClick={() => {
                                if (confirm('¿Reiniciar todo?')) {
                                    setCsvData([]);
                                    setProcessedRows([]);
                                }
                            }}
                            className="text-slate-400 hover:text-rose-500 hover:bg-rose-50"
                        >
                            Cancelar
                        </Button>
                        <Button
                            type="button"
                            onClick={handleFinalImport}
                            variant="primary"
                            className="shadow-xl shadow-emerald-500/20 bg-emerald-600 hover:bg-emerald-700 border-none px-8"
                            disabled={processedRows.filter(r => r.selected).length === 0}
                        >
                            IMPORTAR {processedRows.filter(r => r.selected).length} REGISTROS
                        </Button>
                    </div>

                    {/* Tabla de Previsualización */}
                    <Card noPadding className="overflow-x-auto max-h-[500px] border border-gray-200 dark:border-slate-800 shadow-md shadow-gray-200/50 dark:shadow-none">
                        <table className="w-full text-sm text-left relative">
                            <thead className="sticky top-0 z-10 bg-gray-50/95 dark:bg-slate-900/95 backdrop-blur-sm text-xs text-gray-500 dark:text-gray-400 uppercase font-bold shadow-sm">
                                <tr>
                                    <th className="p-3 w-10 text-center">
                                        <input
                                            type="checkbox"
                                            onChange={(e) => {
                                                const visibleIds = new Set(filteredRows.map(r => r.id));
                                                setProcessedRows(prev => prev.map(r =>
                                                    visibleIds.has(r.id) && !r.isDuplicate ? { ...r, selected: e.target.checked } : r
                                                ));
                                            }}
                                            className="rounded border-gray-300 dark:border-slate-600 text-primary focus:ring-primary dark:bg-slate-700"
                                        />
                                    </th>
                                    {mode === 'full' && <th className="p-3">Estado</th>}
                                    {mode !== 'full' && <th className="p-3">Tipo</th>}
                                    <th className="p-3">Fecha</th>
                                    <th className="p-3">Descripción</th>
                                    <th className="p-3">Referencia</th>
                                    {mode === 'full' ? (
                                        <>
                                            <th className="p-3 text-right">Débito</th>
                                            <th className="p-3 text-right">Crédito</th>
                                        </>
                                    ) : (
                                        <th className="p-3 text-right">Valor</th>
                                    )}
                                    {mode === 'full' && (
                                        <>
                                            <th className="p-3">Tercero</th>
                                            <th className="p-3">Cuenta/Cat</th>
                                        </>
                                    )}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-slate-700">
                                {filteredRows.map((row) => (
                                    <tr
                                        key={row.id}
                                        className={`hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors cursor-pointer ${row.isDuplicate ? 'bg-amber-50/50 dark:bg-amber-900/20' : ''} ${!row.selected && !row.isDuplicate ? 'opacity-50' : ''}`}
                                        onClick={() => toggleRowSelection(row.id)}
                                    >
                                        <td className="p-3 text-center">
                                            <input
                                                type="checkbox"
                                                checked={row.selected}
                                                onChange={() => { }}
                                                className="rounded border-gray-300 dark:border-slate-600 text-primary focus:ring-primary pointer-events-none dark:bg-slate-700"
                                            />
                                        </td>
                                        {mode === 'full' && (
                                            <td className="p-3">
                                                {row.isDuplicate ? (
                                                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400">
                                                        DUPLICADO
                                                    </span>
                                                ) : (
                                                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-400">
                                                        NUEVO
                                                    </span>
                                                )}
                                            </td>
                                        )}
                                        {mode !== 'full' && (
                                            <td className="p-3" onClick={(e) => e.stopPropagation()}>
                                                <span
                                                    onClick={() => {
                                                        const currentType = row.data.type;
                                                        const nextType = currentType === TransactionType.INCOME ? TransactionType.EXPENSE : TransactionType.INCOME;
                                                        updateRowType(row.id, nextType);
                                                    }}
                                                    className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest cursor-pointer hover:opacity-80 transition-all ${row.data.type === TransactionType.INCOME ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : row.data.type === TransactionType.EXPENSE ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-slate-100 text-slate-500 border border-slate-200'}`}
                                                >
                                                    {row.data.type === TransactionType.INCOME ? '↑ ING' : row.data.type === TransactionType.EXPENSE ? '↓ EGR' : 'PENDIENTE'}
                                                </span>
                                            </td>
                                        )}
                                        <td className="p-3 whitespace-nowrap text-medium-text dark:text-gray-400 font-medium text-xs">{formatDateToDisplay(row.data.date)}</td>
                                        <td className="p-3 text-dark-text dark:text-gray-200 max-w-[200px] truncate text-xs" title={row.data.description}>{row.data.description}</td>
                                        <td className="p-3 text-xs text-gray-500 dark:text-gray-400 max-w-[100px] truncate">
                                            {row.data.metadata?.documento || '-'}
                                        </td>
                                        {mode === 'full' ? (
                                            <>
                                                <td className={`p-3 font-bold text-xs text-right ${row.data.type === TransactionType.EXPENSE ? 'text-red-600 dark:text-red-400' : row.data.type === TransactionType.INCOME ? 'text-green-600 dark:text-green-400' : 'text-slate-500'}`}>
                                                    {Math.abs(row.data.metadata?.debit || 0) > 0 ? formatCOP(Math.abs(row.data.metadata.debit).toString()) : '-'}
                                                </td>
                                                <td className={`p-3 font-bold text-xs text-right ${row.data.type === TransactionType.EXPENSE ? 'text-red-600 dark:text-red-400' : row.data.type === TransactionType.INCOME ? 'text-green-600 dark:text-green-400' : 'text-slate-500'}`}>
                                                    {Math.abs(row.data.metadata?.credit || 0) > 0 ? formatCOP(Math.abs(row.data.metadata.credit).toString()) : '-'}
                                                </td>
                                            </>
                                        ) : (
                                            <td className={`p-3 font-bold text-xs text-right ${row.data.type === TransactionType.EXPENSE ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                                                {formatCOP(row.data.type === TransactionType.EXPENSE ? -row.data.amount : row.data.amount)}
                                            </td>
                                        )}
                                        {mode === 'full' && (
                                            <>
                                                <td className="p-3 text-xs text-gray-500 dark:text-gray-400 max-w-[150px] truncate">
                                                    {row.data.metadata?.tercero || row.data.metadata?.nit || '-'}
                                                </td>
                                                <td className="p-3 text-[10px] text-gray-400" onClick={(e) => e.stopPropagation()}>
                                                    <select
                                                        value={row.data.categoryId}
                                                        onChange={(e) => updateRowCategory(row.id, e.target.value)}
                                                        className={`w-full p-1.5 border rounded-lg text-[10px] focus:outline-none transition-all dark:bg-slate-700 ${row.data.categoryId ? 'border-primary/30 bg-indigo-50 dark:bg-indigo-900/20 text-primary dark:text-blue-400 font-bold' : 'border-red-200 dark:border-red-900/50 bg-red-50 dark:bg-red-900/10 text-red-500 dark:text-red-400'}`}
                                                    >
                                                        <option value="">{row.data.type ? '-- ASIGNAR --' : '-- ASIGNA TIPO --'}</option>
                                                        {categories
                                                            .filter(c => !row.data.type || c.type === row.data.type)
                                                            .map(cat => (
                                                                <option key={cat.id} value={cat.id}>{cat.name.toUpperCase()}</option>
                                                            ))
                                                        }
                                                    </select>
                                                </td>
                                            </>
                                        )}
                                    </tr>
                                ))}
                                {filteredRows.length === 0 && (
                                    <tr>
                                        <td colSpan={mode === 'bank' ? 6 : 9} className="p-8 text-center text-gray-400 italic">
                                            No hay transacciones para mostrar. Revisa el mapeo de columnas.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </Card>
                </div>
            )}
        </div>
    );
};

export default ImportCSVView;

const MappingSelect = ({ headers, value, onChange, csvData }: { headers: string[], value: number, onChange: (val: string) => void, csvData: string[][] }) => {
    // Filtrar encabezados: Solo mostrar si el encabezado tiene nombre Y la columna tiene algún dato en las filas
    const validOptions = headers.map((header, idx) => {
        const h = String(header || '').trim();
        if (!h) return null;

        // Verificar si la columna tiene al menos un dato no vacío en las primeras 100 filas
        const hasData = csvData.slice(0, 100).some(row => row[idx] && String(row[idx]).trim() !== '');
        if (!hasData) return null;

        return { label: h, value: idx };
    }).filter(opt => opt !== null) as { label: string, value: number }[];

    return (
        <select
            className={`w-full p-2 border rounded-lg text-xs outline-none transition-all dark:bg-slate-700 dark:text-white ${value !== -1 ? 'border-indigo-300 dark:border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 font-semibold' : 'border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-gray-500 dark:text-gray-300'}`}
            onChange={(e) => onChange(e.target.value)}
            value={value}
        >
            <option value="-1">-- Seleccionar --</option>
            {validOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
        </select>
    );
};
