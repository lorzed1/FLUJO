import React, { useState, useMemo } from 'react';
import { Transaction, TransactionType, Category } from '../../types';
import { TrashIcon, ArrowDownTrayIcon, ArrowUpTrayIcon, InformationCircleIcon, MagnifyingGlassIcon, ChevronUpIcon, ChevronDownIcon, ChevronUpDownIcon, EyeIcon, EyeSlashIcon, CalendarIcon, FunnelIcon, LockClosedIcon, LinkIcon, PlayIcon, PauseIcon, PencilIcon } from '../../components/ui/Icons';
import { formatCOP, parseCOP } from '../../components/ui/Input';
import { formatDateToDisplay } from '../../utils/dateUtils';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SmartDataTable, Column } from '../../components/ui/SmartDataTable';
import { LabeledField } from '../../components/ui/LabeledField';
import { CalendarDaysIcon } from '../../components/ui/Icons';

interface OfficialBookViewProps {
    transactions: Transaction[];
    categories: Category[];
    deleteTransaction: (id: string) => void;
    updateTransaction?: (id: string, updatedFields: Partial<Transaction>) => void;
    selectedIds?: Set<string>;
    onSelectionChange?: (ids: Set<string>) => void;
    // Props para sincronización
    externalFilters?: {
        dateRange?: { start: string; end: string };
        selectedMonth?: string;
        selectedYear?: string;
        typeFilter?: string[];
        sortField?: string;
        sortDirection?: 'asc' | 'desc';
        selectedBankAccountName?: string;
    };
    onFilterChange?: (filters: any) => void;
}

type SortField = keyof Transaction | 'amount';
type SortDirection = 'asc' | 'desc';

const OfficialBookView: React.FC<OfficialBookViewProps> = ({
    transactions,
    categories,
    deleteTransaction,
    updateTransaction,
    selectedIds: propSelectedIds,
    onSelectionChange,
    externalFilters,
    onFilterChange
}) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [sortField, setSortField] = useState<SortField>('date');
    const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

    // Estado para edición en línea
    const [editingCell, setEditingCell] = useState<{ id: string; field: keyof Transaction } | null>(null);
    const [editValue, setEditValue] = useState('');

    // --- NUEVOS ESTADOS PARA FUNCIONALIDADES AVANZADAS ---
    const [localSelectedIds, setLocalSelectedIds] = useState<Set<string>>(new Set());
    const selectedIds = propSelectedIds || localSelectedIds;
    const setSelectedIds = onSelectionChange || setLocalSelectedIds;
    const [showColumnSelector, setShowColumnSelector] = useState(false);

    // --- ESTADOS DE FECHAS ---
    const [dateRange, setDateRange] = useState<{ start: string; end: string }>({ start: '', end: '' });
    const [selectedMonth, setSelectedMonth] = useState<string>('');
    const [selectedYear, setSelectedYear] = useState<string>('');
    const [localActiveFilters, setLocalActiveFilters] = useState<Record<string, string[]>>({});

    // --- COLUMNAS ---
    const initialColumns = [
        { key: 'type' as const, label: 'Tipo', width: 'w-24', visible: true, align: 'text-center' },
        { key: 'date' as const, label: 'Fecha', width: 'w-32', visible: true },
        { key: 'description' as const, label: 'Descripción', width: 'w-auto', visible: true },
        { key: 'debit' as const, label: 'Débito', width: 'w-32', visible: true, align: 'text-right' },
        { key: 'credit' as const, label: 'Crédito', width: 'w-32', visible: true, align: 'text-right' },
        { key: 'documento' as const, label: 'Consecutivo', width: 'w-32', visible: true },
        { key: 'nit' as const, label: 'NIT', width: 'w-32', visible: false },
        { key: 'tercero' as const, label: 'Tercero', width: 'w-48', visible: false },
        { key: 'cuenta_codigo' as const, label: 'Cód. Cuenta', width: 'w-32', visible: false },
        { key: 'cuenta_nombre' as const, label: 'Nombre Cuenta', width: 'w-48', visible: false },
    ];

    const [visibleColumns, setVisibleColumns] = useState<Record<string, boolean>>(() => {
        const saved = localStorage.getItem('official_book_visible_columns');
        if (saved) return JSON.parse(saved);
        return initialColumns.reduce((acc, col) => ({ ...acc, [col.key]: col.visible }), {});
    });

    const [columnOrder, setColumnOrder] = useState<string[]>(() => {
        const saved = localStorage.getItem('official_book_column_order');
        if (saved) return JSON.parse(saved);
        return initialColumns.map(col => col.key);
    });

    const orderedInitialColumns = useMemo(() => {
        return [...initialColumns].sort((a, b) => columnOrder.indexOf(a.key) - columnOrder.indexOf(b.key));
    }, [columnOrder]);

    const columns = orderedInitialColumns.filter(col => visibleColumns[col.key]);

    const toggleColumn = (key: string) => {
        const newVisible = { ...visibleColumns, [key]: !visibleColumns[key] };
        setVisibleColumns(newVisible);
        localStorage.setItem('official_book_visible_columns', JSON.stringify(newVisible));
    };

    const months = [
        { value: '01', label: 'Enero' }, { value: '02', label: 'Febrero' },
        { value: '03', label: 'Marzo' }, { value: '04', label: 'Abril' },
        { value: '05', label: 'Mayo' }, { value: '06', label: 'Junio' },
        { value: '07', label: 'Julio' }, { value: '08', label: 'Agosto' },
        { value: '09', label: 'Septiembre' }, { value: '10', label: 'Octubre' },
        { value: '11', label: 'Noviembre' }, { value: '12', label: 'Diciembre' }
    ];

    const availableYears = useMemo(() => {
        const years = new Set<string>();
        transactions.forEach(t => {
            const year = t.date.split('-')[0];
            if (year) years.add(year);
        });
        if (years.size === 0) years.add(new Date().getFullYear().toString());
        return Array.from(years).sort((a, b) => b.localeCompare(a));
    }, [transactions]);

    // --- LÓGICA DE FILTRADO Y PROCESAMIENTO ---
    const transactionsToProcess = useMemo(() => {
        // Solo las transacciones completadas (no proyectadas)
        return transactions.filter(t => t.status ? t.status === 'completed' : !t.isRecurring);
    }, [transactions]);

    // Unificación de filtros externos para SmartDataTable
    const mergedActiveFilters = useMemo(() => {
        const filters = { ...localActiveFilters };
        if (externalFilters?.typeFilter && externalFilters.typeFilter.length > 0) {
            const mappedTypes = externalFilters.typeFilter.map(t => t.toUpperCase());
            // REGLA: Si filtra por tipo (INGRESO/EGRESO), incluir siempre PENDIENTE
            // para no ocultar transacciones del Libro Oficial que aún no han sido clasificadas.
            if (!mappedTypes.includes('PENDIENTE')) {
                mappedTypes.push('PENDIENTE');
            }
            filters.type = mappedTypes;
        }
        return filters;
    }, [localActiveFilters, externalFilters]);

    const handleFilterChange = (next: Record<string, string[]>) => {
        setLocalActiveFilters(next);
        // Permitir que el Libro Oficial también reporte cambios si onFilterChange existe
        if (onFilterChange) {
            onFilterChange({ typeFilter: next.type || [] });
        }
    };

    // Filtros de fecha (estos siguen siendo externos a SmartDataTable por ahora)
    const processedTransactions = useMemo(() => {
        let result = [...transactionsToProcess];

        // Rango de Fechas
        const currentRange = externalFilters?.dateRange || dateRange;
        if (currentRange.start) result = result.filter(t => t.date >= currentRange.start);
        if (currentRange.end) result = result.filter(t => t.date <= currentRange.end);

        // Mes y Año
        const currentMonth = externalFilters?.selectedMonth !== undefined ? externalFilters.selectedMonth : selectedMonth;
        const currentYear = externalFilters?.selectedYear !== undefined ? externalFilters.selectedYear : selectedYear;

        if (currentMonth) result = result.filter(t => t.date.split('-')[1] === currentMonth);
        if (currentYear) result = result.filter(t => t.date.startsWith(currentYear));

        // Filtrar por Nombre de Cuenta (Banco)
        const accountFilter = externalFilters?.selectedBankAccountName;
        if (accountFilter) {
            result = result.filter(t => t.metadata?.cuenta_nombre?.toUpperCase() === accountFilter.toUpperCase());
        }

        return result;
    }, [transactionsToProcess, dateRange, selectedMonth, selectedYear, externalFilters]);

    // Definición de Columnas para SmartDataTable
    const smartColumns: Column<Transaction>[] = [
        {
            key: 'type',
            label: 'Tipo',
            width: 'w-24',
            align: 'text-center',
            filterable: true,
            render: (val, t) => (
                <span
                    onClick={() => {
                        if (updateTransaction) {
                            const newType = val === TransactionType.INCOME ? TransactionType.EXPENSE : TransactionType.INCOME;
                            updateTransaction(t.id, { type: newType });
                        }
                    }}
                    className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider cursor-pointer hover:opacity-80 transition-all ${val === TransactionType.INCOME
                        ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                        : val === TransactionType.EXPENSE
                            ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                            : 'bg-slate-100 text-slate-400 border border-slate-200 dark:bg-slate-800 dark:border-slate-700'
                        }`}
                >
                    {val === TransactionType.INCOME ? '↑ ING' : val === TransactionType.EXPENSE ? '↓ EGR' : 'PEND'}
                </span>
            ),
            getValue: (t) => {
                const type = (t.type || '').toString().toUpperCase();
                if (type === 'INCOME' || type === 'INGRESO') return 'INGRESO';
                if (type === 'EXPENSE' || type === 'EGRESO') return 'EGRESO';
                return 'PENDIENTE';
            }
        },
        {
            key: 'date',
            label: 'Fecha',
            width: 'w-32',
            sortable: true,
            filterable: true,
            render: (val, t) => (
                editingCell?.id === t.id && editingCell?.field === 'date' ? (
                    <input
                        autoFocus
                        type="date"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={saveEdit}
                        onKeyDown={handleKeyDown}
                        className="w-full bg-white dark:bg-slate-700 border-none p-0 text-xs focus:ring-0 font-semibold"
                    />
                ) : (
                    <span onDoubleClick={() => startEdit(t, 'date')} className="cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-700 px-1 rounded transition-colors text-slate-500 dark:text-slate-400">
                        {formatDateToDisplay(val)}
                    </span>
                )
            )
        },
        {
            key: 'description',
            label: 'Descripción',
            width: 'w-auto',
            sortable: true,
            filterable: true,
            render: (val, t) => (
                editingCell?.id === t.id && editingCell?.field === 'description' ? (
                    <input
                        autoFocus
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={saveEdit}
                        onKeyDown={handleKeyDown}
                        className="w-full bg-white dark:bg-slate-700 border-none p-0 text-xs focus:ring-0"
                    />
                ) : (
                    <span onDoubleClick={() => startEdit(t, 'description')} className="cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-700 px-1 rounded transition-colors text-slate-700 dark:text-gray-300">
                        {val}
                    </span>
                )
            )
        },
        {
            key: 'debit' as any,
            label: 'Débito',
            width: 'w-32',
            align: 'text-right',
            sortable: true,
            render: (_, t) => {
                const val = Math.abs(t.metadata?.debit || 0);
                const colorClass = t.type === TransactionType.EXPENSE ? 'text-red-600 dark:text-red-400' : t.type === TransactionType.INCOME ? 'text-green-600 dark:text-green-400' : 'text-slate-600 dark:text-slate-300';
                return (
                    <span className={`font-semibold tabular-nums ${colorClass}`}>
                        {val > 0 ? formatCOP(val) : '-'}
                    </span>
                );
            },
            getValue: (t) => t.metadata?.debit || 0
        },
        {
            key: 'credit' as any,
            label: 'Crédito',
            width: 'w-32',
            align: 'text-right',
            sortable: true,
            render: (_, t) => {
                const val = Math.abs(t.metadata?.credit || 0);
                const colorClass = t.type === TransactionType.EXPENSE ? 'text-red-600 dark:text-red-400' : t.type === TransactionType.INCOME ? 'text-green-600 dark:text-green-400' : 'text-slate-600 dark:text-slate-300';
                return (
                    <span className={`font-semibold tabular-nums ${colorClass}`}>
                        {val > 0 ? formatCOP(val) : '-'}
                    </span>
                );
            },
            getValue: (t) => t.metadata?.credit || 0
        },
        {
            key: 'documento',
            label: 'Consecutivo',
            width: 'w-32',
            render: (_, t) => <span className="text-blue-600 dark:text-blue-400 font-semibold">{t.metadata?.documento || t.id.substring(0, 4)}</span>,
            getValue: (t) => t.metadata?.documento || ''
        },
        { key: 'nit' as any, label: 'NIT', width: 'w-32', filterable: true, render: (_, t) => t.metadata?.nit || '', getValue: (t) => t.metadata?.nit || '' },
        { key: 'tercero' as any, label: 'Tercero', width: 'w-48', filterable: true, render: (_, t) => t.metadata?.tercero || '', getValue: (t) => t.metadata?.tercero || '' },
        { key: 'cuenta_codigo' as any, label: 'Cód. Cuenta', width: 'w-32', filterable: true, render: (_, t) => t.metadata?.cuenta_codigo || '', getValue: (t) => t.metadata?.cuenta_codigo || '' },
        { key: 'cuenta_nombre' as any, label: 'Nombre Cuenta', width: 'w-48', filterable: true, render: (_, t) => t.metadata?.cuenta_nombre || '', getValue: (t) => t.metadata?.cuenta_nombre || '' },
        {
            key: 'actions' as any,
            label: 'Acciones',
            width: 'w-20',
            align: 'text-right',
            render: (_, t) => (
                <button
                    onClick={(e) => { e.stopPropagation(); if (confirm('¿Eliminar transacción?')) deleteTransaction(t.id); }}
                    className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
                >
                    <TrashIcon className="h-4 w-4" />
                </button>
            )
        }
    ];

    // --- HELPERS ---
    // --- HELPERS ---
    const formatCurrency = (value: number) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(value);

    function getCategoryName(id?: string) {
        return categories.find(c => c.id === id)?.name || 'N/A';
    }

    const handleSort = (field: SortField) => {
        let newDir: SortDirection = 'asc';
        if (sortField === field) {
            newDir = sortDirection === 'asc' ? 'desc' : 'asc';
            setSortDirection(newDir);
        } else {
            setSortField(field);
            setSortDirection('asc');
        }

        if (onFilterChange) {
            onFilterChange({ sortField: field, sortDirection: newDir });
        }
    };

    // --- LÓGICA DE EDICIÓN ---
    const startEdit = (t: Transaction, field: keyof Transaction) => {
        if (!updateTransaction) return; // Si no hay función de update, no editar
        setEditingCell({ id: t.id, field });

        // Valor inicial
        if (field === 'amount') {
            setEditValue(String(t.amount));
        } else {
            setEditValue(String(t[field]));
        }
    };

    const saveEdit = () => {
        if (!editingCell || !updateTransaction) return;

        const { id, field } = editingCell;
        let newValue: any = editValue;

        if (field === 'amount') {
            newValue = parseCOP(editValue);
        }

        updateTransaction(id, { [field]: newValue });
        setEditingCell(null);
        setEditValue('');
    };

    const cancelEdit = () => {
        setEditingCell(null);
        setEditValue('');
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter') saveEdit();
        if (e.key === 'Escape') cancelEdit();
    };

    // --- FUNCIONAMIENTO DE ARRASTRE DE COLUMNAS ---
    const handleDragStart = (e: React.DragEvent, columnKey: string) => {
        e.dataTransfer.setData('columnKey', columnKey);
    };

    const handleDrop = (e: React.DragEvent, targetKey: string) => {
        e.preventDefault(); // Necesario para permitir el drop
        const sourceKey = e.dataTransfer.getData('columnKey');
        if (!sourceKey || sourceKey === targetKey) return;

        const newOrder = [...columnOrder];
        const sourceIndex = newOrder.indexOf(sourceKey);
        const targetIndex = newOrder.indexOf(targetKey);

        if (sourceIndex === -1 || targetIndex === -1) return;

        // Mover el elemento en el array completo de orden
        newOrder.splice(sourceIndex, 1);
        newOrder.splice(targetIndex, 0, sourceKey);

        setColumnOrder(newOrder);
        localStorage.setItem('official_book_column_order', JSON.stringify(newOrder));
    };

    // --- SELECCIÓN Y ELIMINACIÓN MASIVA ---
    const toggleSelectAll = () => {
        if (selectedIds.size === processedTransactions.length) setSelectedIds(new Set());
        else setSelectedIds(new Set(processedTransactions.map(t => t.id)));
    };

    const toggleSelectRow = (id: string) => {
        const next = new Set(selectedIds);
        if (next.has(id)) next.delete(id);
        else next.add(id);
        setSelectedIds(next);
    };

    const handleBulkDelete = () => {
        if (confirm(`¿Eliminar ${selectedIds.size} transacciones permanentemente?`)) {
            selectedIds.forEach(id => deleteTransaction(id));
            setSelectedIds(new Set());
        }
    };

    const handleBulkCategoryAssign = (catId: string) => {
        if (!updateTransaction || !catId) return;
        if (confirm(`¿Asignar esta categoría a los ${selectedIds.size} movimientos seleccionados?`)) {
            selectedIds.forEach(id => updateTransaction(id, { categoryId: catId }));
            setSelectedIds(new Set());
            alert('Categorías actualizadas correctamente.');
        }
    };

    const handleBulkTypeAssign = (type: TransactionType) => {
        if (!updateTransaction || !type) return;
        if (confirm(`¿Asignar tipo ${type === TransactionType.INCOME ? 'INGRESO' : 'EGRESO'} a los ${selectedIds.size} movimientos seleccionados?`)) {
            selectedIds.forEach(id => updateTransaction(id, { type, categoryId: '' })); // Reset category on type change
            setSelectedIds(new Set());
            alert('Tipos actualizados correctamente.');
        }
    };

    // --- FUNCIONES DE EXPORTACIÓN ---
    const getExportData = () => {
        const data = selectedIds.size > 0
            ? processedTransactions.filter(t => selectedIds.has(t.id))
            : processedTransactions;
        return data.map(t => ({
            Fecha: t.date,
            Descripción: t.description,
            Categoría: getCategoryName(t.categoryId),
            Tipo: t.type === TransactionType.INCOME ? 'Ingreso' : 'Egreso',
            Débito: t.metadata?.debit || 0,
            Crédito: t.metadata?.credit || 0,
            Documento: t.metadata?.documento || '',
            NIT: t.metadata?.nit || '',
            Tercero: t.metadata?.tercero || '',
            Cuenta_Cod: t.metadata?.cuenta_codigo || '',
            Cuenta_Nom: t.metadata?.cuenta_nombre || ''
        }));
    };

    const exportToExcel = () => {
        const data = getExportData();
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Transacciones");
        XLSX.writeFile(wb, `libro_oficial_${new Date().toISOString().split('T')[0]}.xlsx`);
    };

    const exportToPDF = () => {
        const doc = new jsPDF();
        const data = getExportData();
        const headers = Object.keys(data[0]);
        const rows = data.map(row => Object.values(row));
        doc.text('Libro Oficial', 14, 15);
        autoTable(doc, {
            head: [headers],
            body: rows,
            startY: 25,
            theme: 'grid',
            headStyles: { fillColor: [79, 70, 229] }
        });
        doc.save(`libro_oficial_${new Date().toISOString().split('T')[0]}.pdf`);
    };

    const exportToCSV = () => {
        const data = getExportData();
        const headers = Object.keys(data[0]);
        const csvContent = [headers.join(','), ...data.map(r => headers.map(h => (r as any)[h]).join(','))].join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `libro_oficial_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
    };

    const [showExportOptions, setShowExportOptions] = useState(false);


    // --- RENDER ---
    return (
        <div className="space-y-2 h-full flex flex-col">
            {/* Tabla Principal */}
            <div className="flex-1 min-h-0">
                <SmartDataTable
                    data={processedTransactions}
                    columns={smartColumns}
                    containerClassName="h-full"
                    enableSearch={true}
                    enableSelection={true}
                    enableExport={true}
                    selectedIds={selectedIds}
                    onSelectionChange={setSelectedIds}
                    activeFilters={mergedActiveFilters}
                    onFilterChange={handleFilterChange}
                    searchTerm={searchTerm}
                    onSearchChange={setSearchTerm}
                    sortConfig={{ key: externalFilters?.sortField || sortField, direction: externalFilters?.sortDirection || sortDirection }}
                    onSortChange={(config) => {
                        setSortField(config.key as SortField);
                        setSortDirection(config.direction);
                        if (onFilterChange) {
                            onFilterChange({ sortField: config.key, sortDirection: config.direction });
                        }
                    }}
                    onBulkDelete={handleBulkDelete}
                    renderSelectionActions={() => (
                        <div className="flex items-center gap-2">
                            <select
                                onChange={(e) => handleBulkTypeAssign(e.target.value as TransactionType)}
                                className="bg-white text-emerald-700 text-[10px] font-bold py-1.5 px-3 rounded-lg border border-emerald-200 focus:ring-2 focus:ring-emerald-500 cursor-pointer transition-all dark:bg-emerald-900/20 dark:text-emerald-300 dark:border-emerald-800 w-32 shadow-sm"
                            >
                                <option value="">TIPO...</option>
                                <option value={TransactionType.INCOME}>↑ INGRESO</option>
                                <option value={TransactionType.EXPENSE}>↓ EGRESO</option>
                            </select>

                            <select
                                onChange={(e) => handleBulkCategoryAssign(e.target.value)}
                                className="bg-white text-slate-700 text-[10px] font-semibold py-1.5 px-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-emerald-500 cursor-pointer transition-all dark:bg-slate-700 dark:text-gray-200 dark:border-slate-600 w-40 truncate shadow-sm uppercase tracking-wide"
                            >
                                <option value="">CATEGORÍA...</option>
                                <optgroup label="INGRESOS">
                                    {categories.filter(c => c.type === TransactionType.INCOME).map(c => <option key={c.id} value={c.id}>{c.name.toUpperCase()}</option>)}
                                </optgroup>
                                <optgroup label="EGRESOS">
                                    {categories.filter(c => c.type === TransactionType.EXPENSE).map(c => <option key={c.id} value={c.id}>{c.name.toUpperCase()}</option>)}
                                </optgroup>
                            </select>

                            <button onClick={handleBulkDelete} className="flex items-center gap-1 bg-rose-500 hover:bg-rose-600 text-white px-3 py-1.5 rounded-lg font-semibold transition-all shadow-sm">
                                <TrashIcon className="h-3.5 w-3.5" />
                            </button>
                        </div>
                    )}
                    renderExtraFilters={() => (
                        <div className="flex items-center gap-2">
                            {/* Rango Fechas */}
                            <div className="flex items-center gap-2">
                                <LabeledField
                                    label="Fecha inicial"
                                    icon={<CalendarDaysIcon className="h-4 w-4" />}
                                    className="w-40"
                                >
                                    <input
                                        type="date"
                                        value={externalFilters?.dateRange?.start ?? dateRange.start}
                                        onChange={e => {
                                            const newRange = { ...dateRange, start: e.target.value };
                                            setDateRange(newRange);
                                            onFilterChange?.({ dateRange: newRange });
                                        }}
                                        className="w-full bg-transparent border-none p-0 text-[13px] font-semibold text-slate-700 dark:text-gray-200 focus:ring-0 uppercase"
                                    />
                                </LabeledField>
                                <LabeledField
                                    label="Fecha final"
                                    icon={<CalendarDaysIcon className="h-4 w-4" />}
                                    className="w-40"
                                >
                                    <input
                                        type="date"
                                        value={externalFilters?.dateRange?.end ?? dateRange.end}
                                        onChange={e => {
                                            const newRange = { ...dateRange, end: e.target.value };
                                            setDateRange(newRange);
                                            onFilterChange?.({ dateRange: newRange });
                                        }}
                                        className="w-full bg-transparent border-none p-0 text-[13px] font-semibold text-slate-700 dark:text-gray-200 focus:ring-0 uppercase"
                                    />
                                </LabeledField>
                            </div>

                            {/* Mes / Año */}
                            <div className="flex items-center gap-1 bg-emerald-50 dark:bg-emerald-900/30 p-1 rounded-xl border border-emerald-100 dark:border-emerald-800 flex-shrink-0">
                                <select
                                    value={externalFilters?.selectedMonth ?? selectedMonth}
                                    onChange={e => {
                                        setSelectedMonth(e.target.value);
                                        onFilterChange?.({ selectedMonth: e.target.value });
                                    }}
                                    className="text-[10px] font-semibold bg-transparent border-none focus:ring-0 text-emerald-700 dark:text-emerald-300 cursor-pointer py-1 pl-2 pr-6 uppercase tracking-tight"
                                >
                                    <option value="">MES</option>
                                    {months.map(m => <option key={m.value} value={m.value} className="dark:bg-slate-800">{m.label.substring(0, 3)}</option>)}
                                </select>
                                <div className="h-4 w-px bg-emerald-200 dark:bg-emerald-700"></div>
                                <select
                                    value={externalFilters?.selectedYear ?? selectedYear}
                                    onChange={e => {
                                        setSelectedYear(e.target.value);
                                        onFilterChange?.({ selectedYear: e.target.value });
                                    }}
                                    className="text-[10px] font-semibold bg-transparent border-none focus:ring-0 text-emerald-700 dark:text-emerald-300 cursor-pointer py-1 pl-2 pr-6 uppercase tracking-tight"
                                >
                                    <option value="">AÑO</option>
                                    {availableYears.map(y => <option key={y} value={y} className="dark:bg-slate-800">{y}</option>)}
                                </select>
                            </div>
                        </div>
                    )}
                />
            </div>
        </div>
    );
};

export default OfficialBookView;