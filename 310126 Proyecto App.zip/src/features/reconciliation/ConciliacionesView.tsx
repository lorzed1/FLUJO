import React from 'react';
import OfficialBookView from './OfficialBookView';
import { Transaction, Category, ReconciliationResult } from '../../types';
import { MagnifyingGlassIcon, ArrowPathIcon, ScaleIcon, ArrowUpTrayIcon, ArrowDownTrayIcon, TrashIcon, BuildingLibraryIcon, LinkIcon, ClockIcon, Squares2X2Icon, ArrowLeftIcon, ChevronDownIcon } from '../../components/ui/Icons';
import ReconciliationModal from './ReconciliationModal';
import ReconciliationsHistoryView from './ReconciliationsHistoryView';
import BankStatementsView from './BankStatementsView';
import ImportCSVView from './ImportCSVView';
// import { Card } from '../../components/ui/Card';
// import { Button } from '../../components/ui/Button';
import { LabeledField } from '../../components/ui/LabeledField';
import { useConciliacion } from '../../hooks/useConciliacion';
import { Dispatch, SetStateAction } from 'react';

// Constantes
const SELECTED_BANK_NAME_KEY = 'conciliaciones_selected_bank_name';

interface ConciliacionesViewProps {
    transactions: Transaction[];
    categories: Category[];
    deleteTransaction?: (id: string) => void;
    updateTransaction?: (id: string, updatedFields: Partial<Transaction>) => void;
    addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
    onBankChange?: (bankId: string) => void;

    // Data Guardian Props
    bankTransactions: Record<string, Transaction[]>;
    reconciliationResults: Record<string, ReconciliationResult | null>;
    onUpdateBankTransactions: Dispatch<SetStateAction<Record<string, Transaction[]>>>;
    onUpdateReconciliationResults: Dispatch<SetStateAction<Record<string, ReconciliationResult | null>>>;
}

const ConciliacionesView: React.FC<ConciliacionesViewProps> = (props) => {

    // Custom Hook: Segregación de Responsabilidades
    const {
        // State
        selectedBankAccountName, setSelectedBankAccountName,
        internalAccountFilter, setInternalAccountFilter,
        isInternalImportOpen, setIsInternalImportOpen,
        isBankImportOpen, setIsBankImportOpen,
        activeTab, setActiveTab,
        selectedInternalIds, setSelectedInternalIds,
        selectedExternalIds, setSelectedExternalIds,
        isReconciliationModalOpen, selectedForReconciliation, reconciliationCandidates, highlightedCandidateId, setHighlightedCandidateId, reconciliationQueue, currentQueueIndex,
        isFiltersLinked, setIsFiltersLinked, sharedFilters,

        // Data
        bankTransactions, reconciliationResult, setReconciliationResult,
        dynamicInternalAccountOptions, dynamicBankOptions,
        displayInternal, displayExternal,
        selectedInternalTotal, selectedExternalTotal, globalDifference, canManualReconcile,
        lastImportDate, lastInternalDate,

        // Actions
        handleBankFilterChange, handleOfficialFilterChange,
        handleAutoReconcile, handleManualReconcile, handleRowClickFromBankSide, handleBatchSmartReconcile,
        handleConfirmReconciliation, handleSkipReconciliation, handleUnlockMatch, handleDeleteMatch,
        setBankTransactions, importBankTransaction, deleteBankTransaction, closeModal

    } = useConciliacion(props);


    // ================== RENDERIZADO ==================

    if (isInternalImportOpen) {
        return (
            <div className="space-y-4">
                <button onClick={() => setIsInternalImportOpen(false)} className="flex items-center gap-2 text-primary hover:underline font-bold">
                    <ArrowLeftIcon className="h-4 w-4" /> Volver a Conciliaciones
                </button>
                <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-gray-100 dark:border-slate-700 shadow-sm">
                    <h2 className="text-xl font-bold mb-4 text-emerald-600 dark:text-emerald-400">Importar al Libro Oficial</h2>
                    <ImportCSVView addTransaction={props.addTransaction} categories={props.categories} existingTransactions={props.transactions} onComplete={() => setIsInternalImportOpen(false)} />
                </div>
            </div>
        );
    }

    if (isBankImportOpen) {
        return (
            <div className="space-y-4">
                <button onClick={() => setIsBankImportOpen(false)} className="flex items-center gap-2 text-primary hover:underline font-bold">
                    <ArrowLeftIcon className="h-4 w-4" /> Volver a Conciliaciones
                </button>
                <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-gray-100 dark:border-slate-700 shadow-sm">
                    <h2 className="text-xl font-bold mb-4 text-indigo-600 dark:text-indigo-400 flex items-center gap-2">
                        <span>Importar Extracto:</span>
                        <span className="bg-indigo-100 dark:bg-indigo-900/40 px-3 py-1 rounded-lg text-sm uppercase tracking-wider">{selectedBankAccountName || 'SIN SELECCIONAR'}</span>
                    </h2>
                    <ImportCSVView
                        mode="bank"
                        availableAccounts={dynamicBankOptions}
                        addTransaction={importBankTransaction}
                        categories={props.categories}
                        existingTransactions={bankTransactions}
                        onComplete={() => setIsBankImportOpen(false)}
                    />
                </div>
            </div>
        );
    }

    return (
        <>
            <div className="space-y-4 h-[calc(100vh-6rem)] flex flex-col relative">

                {/* FLOATING ACTION BAR FOR RECONCILIATION */}
                {(selectedInternalIds.size > 0 || selectedExternalIds.size > 0) && (
                    <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white p-4 rounded-2xl shadow-2xl z-50 flex items-center gap-6 animate-fadeIn border border-gray-700 w-auto max-w-2xl">
                        <div className="flex flex-col">
                            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Lado B (Interno)</span>
                            <span className="font-mono font-bold text-lg text-emerald-400">{selectedInternalTotal.toLocaleString()}</span>
                        </div>
                        <div className="text-gray-500 font-semibold">VS</div>
                        <div className="flex flex-col">
                            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Lado A (Banco)</span>
                            <span className="font-mono font-bold text-lg text-indigo-400">{selectedExternalTotal.toLocaleString()}</span>
                        </div>
                        <div className="h-8 w-px bg-gray-700 mx-2"></div>
                        <div className="flex flex-col">
                            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Diferencia</span>
                            <span className={`font-mono font-bold text-lg ${Math.abs(globalDifference) < 0.01 ? 'text-green-500' : 'text-red-400'} `}>{globalDifference.toLocaleString()}</span>
                        </div>
                        {selectedExternalIds.size > 1 && selectedInternalIds.size === 0 && (
                            <button onClick={handleBatchSmartReconcile} className="bg-indigo-600 text-white hover:bg-indigo-700 px-6 py-2 rounded-xl font-bold text-sm shadow-md transition-all transform hover:scale-105 ml-4 flex items-center gap-2">
                                <MagnifyingGlassIcon className="h-4 w-4" /> INTELIGENCIA EN LOTE ({selectedExternalIds.size})
                            </button>
                        )}
                        <button onClick={handleManualReconcile} disabled={!canManualReconcile} className={`${canManualReconcile ? 'bg-white text-gray-900 hover:bg-gray-100' : 'bg-gray-700 text-gray-500 cursor-not-allowed'} px-6 py-2 rounded-xl font-bold text-sm shadow-md transition-all transform hover:scale-105 ml-4`}>
                            CONCILIAR COMBINADOS
                        </button>
                        <button onClick={() => { setSelectedInternalIds(new Set()); setSelectedExternalIds(new Set()); }} className="text-gray-500 hover:text-white">×</button>
                    </div>
                )}


                {/* HEADER */}
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white dark:bg-slate-800 p-4 rounded-3xl shadow-sm border border-gray-100 dark:border-slate-700 flex-shrink-0">
                    <div className="flex items-center gap-6">
                        <div>
                            <h1 className="text-2xl font-semibold text-slate-800 dark:text-white flex items-center gap-2">
                                <ScaleIcon className="h-8 w-8 text-primary" /> Conciliaciones
                            </h1>
                            <p className="text-slate-500 dark:text-gray-400 text-sm font-medium">Auditoría y Comparación Bancaria</p>
                        </div>
                        <div className="flex bg-slate-100 dark:bg-slate-900 p-1.5 rounded-2xl border border-gray-200 dark:border-slate-700 ml-4">
                            <button onClick={() => setActiveTab('workspace')} className={`px-4 py-2 ${activeTab === 'workspace' ? 'bg-white text-primary shadow-sm font-bold' : 'text-slate-500 hover:text-slate-700 font-medium'} rounded-xl transition-all flex items-center`}>
                                <Squares2X2Icon className="h-4 w-4 mr-2" /> ÁREA DE TRABAJO
                            </button>
                            <button onClick={() => setActiveTab('history')} className={`px-4 py-2 ${activeTab === 'history' ? 'bg-white text-primary shadow-sm font-bold' : 'text-slate-500 hover:text-slate-700 font-medium'} rounded-xl transition-all flex items-center`}>
                                <ClockIcon className="h-4 w-4 mr-2" /> HISTORIAL
                                {reconciliationResult && reconciliationResult.matches.length > 0 && <span className="ml-2 px-1.5 py-0.5 bg-primary/10 text-primary text-[10px] rounded-full border border-primary/20">{reconciliationResult.matches.length}</span>}
                            </button>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        {activeTab === 'workspace' && (
                            <button onClick={handleAutoReconcile} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl flex items-center shadow-md shadow-indigo-500/20 font-bold transition-all">
                                <ArrowPathIcon className="h-5 w-5 mr-2 animate-pulse" /> Conciliar Automáticamente
                            </button>
                        )}
                    </div>
                </div>

                {/* CONTENT */}
                {activeTab === 'history' ? (
                    <ReconciliationsHistoryView
                        matches={reconciliationResult?.matches || []}
                        allTransactions={props.transactions}
                        onUnlock={handleUnlockMatch}
                        onDelete={handleDeleteMatch}
                    />
                ) : activeTab === 'workspace' ? (
                    <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-2">

                        {/* LADO A: BANCO */}
                        <div className="h-full min-h-0 overflow-hidden flex flex-col border border-indigo-100 dark:border-indigo-900 shadow-md shadow-indigo-500/5 rounded-xl bg-white dark:bg-slate-800">
                            <div className="bg-indigo-50/80 dark:bg-indigo-900/40 p-3 border-b border-indigo-100 dark:border-indigo-800 flex justify-between items-center px-4 shrink-0 backdrop-blur-sm">
                                <span className="font-semibold text-indigo-700 dark:text-indigo-300 text-xs uppercase tracking-widest">Lado A: Extractos Bancarios</span>
                                <div className="flex items-center gap-2">
                                    <span className="bg-white/80 dark:bg-slate-800/80 px-2.5 py-1 rounded-lg text-[10px] font-bold border border-indigo-200 dark:border-indigo-700 shadow-sm text-indigo-600 dark:text-indigo-300">{displayExternal.length} pendientes</span>
                                    {lastImportDate && <span className="bg-white/50 dark:bg-slate-800/50 px-2 py-0.5 rounded text-[9px] font-medium text-slate-500 dark:text-slate-400">Último: {lastImportDate}</span>}
                                </div>
                            </div>
                            <div className="bg-white dark:bg-slate-900 border-b border-gray-100 dark:border-slate-800 p-2.5 flex items-center justify-between gap-2 shrink-0">
                                <div className="flex items-center gap-2">
                                    <LabeledField label="Banco" icon={<BuildingLibraryIcon className="h-4 w-4" />} className="w-64">
                                        <div className="relative w-full flex items-center">
                                            <select
                                                value={selectedBankAccountName}
                                                onChange={(e) => {
                                                    const val = e.target.value;
                                                    setSelectedBankAccountName(val);
                                                    localStorage.setItem(SELECTED_BANK_NAME_KEY, val);
                                                    if (isFiltersLinked) {
                                                        handleBankFilterChange({ selectedBankAccountName: val });
                                                        setInternalAccountFilter(val);
                                                    }
                                                }}
                                                className="w-full bg-transparent border-none p-0 pr-6 text-[13px] font-semibold text-slate-700 dark:text-gray-200 focus:ring-0 appearance-none cursor-pointer uppercase tracking-tight"
                                            >
                                                <option value="">TODOS LOS BANCOS</option>
                                                {dynamicBankOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                            </select>
                                            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center text-indigo-500"><ChevronDownIcon className="h-4 w-4" /></div>
                                        </div>
                                    </LabeledField>
                                    <button
                                        onClick={() => setIsBankImportOpen(true)}
                                        disabled={!selectedBankAccountName}
                                        className={`flex items-center px-3 py-2 text-[10px] font-semibold uppercase rounded-xl transition-all ${!selectedBankAccountName ? 'opacity-50 cursor-not-allowed bg-gray-100 text-gray-400' : 'text-indigo-600 border border-indigo-100 bg-indigo-50/50 hover:bg-indigo-100 hover:border-indigo-200'}`}
                                        title={!selectedBankAccountName ? "Selecciona un banco para importar" : "Importar extracto"}
                                    >
                                        <ArrowDownTrayIcon className="h-3.5 w-3.5 mr-1.5" /> Importar
                                    </button>
                                </div>
                                <div className="flex items-center gap-2">
                                    <button onClick={() => setIsFiltersLinked(!isFiltersLinked)} className={`flex items-center gap-1.5 px-3 py-2 text-[10px] font-semibold rounded-xl transition-all border ${isFiltersLinked ? 'bg-indigo-100 text-indigo-700 border-indigo-200' : 'bg-white text-slate-400 border-gray-200 hover:border-gray-300'}`} title="Vincular Filtros">
                                        <LinkIcon className={`h-3 w-3 ${isFiltersLinked ? 'animate-pulse' : ''}`} /> {isFiltersLinked ? 'LINK ON' : 'LINK OFF'}
                                    </button>
                                    {bankTransactions.length > 0 && selectedBankAccountName && (
                                        <button onClick={() => { if (confirm(`¿Borrar todos los extractos de ${selectedBankAccountName}?`)) setBankTransactions([]); }} className="p-2 bg-rose-50 text-rose-500 hover:bg-rose-100 hover:text-rose-600 rounded-xl border border-rose-100 transition-all shadow-sm" title="Limpiar Banco Seleccionado">
                                            <TrashIcon className="h-3.5 w-3.5" />
                                        </button>
                                    )}
                                </div>
                            </div>
                            <div className="flex-1 bg-white dark:bg-slate-800 relative z-20 min-h-0">
                                <BankStatementsView
                                    onSelectionChange={setSelectedExternalIds}
                                    onRowClick={handleRowClickFromBankSide}
                                    externalFilters={isFiltersLinked ? sharedFilters : undefined}
                                    onFilterChange={handleBankFilterChange}
                                    transactions={displayExternal}
                                    onDelete={deleteBankTransaction}
                                    selectedIds={selectedExternalIds}
                                />
                            </div>
                        </div>

                        {/* LADO B: LIBRO */}
                        <div className="h-full min-h-0 overflow-hidden flex flex-col border border-emerald-100 dark:border-emerald-900 shadow-md shadow-emerald-500/5 rounded-xl bg-white dark:bg-slate-800">
                            <div className="bg-emerald-50/80 dark:bg-emerald-900/40 p-3 border-b border-emerald-100 dark:border-emerald-800 flex justify-between items-center px-4 shrink-0 backdrop-blur-sm">
                                <span className="font-semibold text-emerald-700 dark:text-emerald-300 text-xs uppercase tracking-widest">Lado B: Libro Oficial</span>
                                <div className="flex items-center gap-2">
                                    <span className="bg-white/80 dark:bg-slate-800/80 px-2.5 py-1 rounded-lg text-[10px] font-bold border border-emerald-200 dark:border-emerald-700 shadow-sm text-emerald-600 dark:text-emerald-300">{displayInternal.length} pendientes</span>
                                    {internalAccountFilter && props.transactions.length > displayInternal.length && (
                                        <span className="text-[10px] uppercase font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 animate-pulse">
                                            ⚠️ FILTRO ACTIVO ({props.transactions.length - displayInternal.length} OCULTOS)
                                        </span>
                                    )}
                                    {lastInternalDate && <span className="bg-white/50 dark:bg-slate-800/50 px-2 py-0.5 rounded text-[9px] font-medium text-slate-500 dark:text-slate-400">Último: {lastInternalDate}</span>}
                                </div>
                            </div>
                            <div className="bg-white dark:bg-slate-900 border-b border-gray-100 dark:border-slate-800 p-2.5 flex items-center justify-between gap-2 shrink-0">
                                <div className="flex items-center gap-2">
                                    <LabeledField label="Cuenta Libro" icon={<BuildingLibraryIcon className="h-4 w-4" />} className="w-64">
                                        <div className="relative w-full flex items-center">
                                            <select
                                                value={internalAccountFilter}
                                                onChange={(e) => {
                                                    const val = e.target.value;
                                                    setInternalAccountFilter(val);

                                                    if (isFiltersLinked) {
                                                        setSelectedBankAccountName(val);
                                                        localStorage.setItem(SELECTED_BANK_NAME_KEY, val);
                                                        handleBankFilterChange({ selectedBankAccountName: val });
                                                    }
                                                }}
                                                className="w-full bg-transparent border-none p-0 pr-6 text-[13px] font-semibold text-slate-700 dark:text-gray-200 focus:ring-0 appearance-none cursor-pointer uppercase tracking-tight"
                                            >
                                                <option value="">FILTRAR CUENTA...</option>
                                                {dynamicInternalAccountOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                            </select>
                                            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center text-emerald-500"><ChevronDownIcon className="h-4 w-4" /></div>
                                        </div>
                                    </LabeledField>
                                    <button onClick={() => setIsInternalImportOpen(true)} className="flex items-center px-3 py-2 text-[10px] font-semibold uppercase rounded-xl transition-all text-emerald-600 border border-emerald-100 bg-emerald-50/50 hover:bg-emerald-100 hover:border-emerald-200">
                                        <ArrowDownTrayIcon className="h-3.5 w-3.5 mr-1.5" /> Importar
                                    </button>
                                </div>
                            </div>
                            <div className="flex-1 bg-white dark:bg-slate-800 relative z-20 min-h-0">
                                <OfficialBookView
                                    {...props}
                                    deleteTransaction={props.deleteTransaction || (() => { })}
                                    transactions={displayInternal}
                                    selectedIds={selectedInternalIds}
                                    onSelectionChange={setSelectedInternalIds}
                                    externalFilters={{ ...(isFiltersLinked ? sharedFilters : {}), selectedBankAccountName: selectedBankAccountName }}
                                    onFilterChange={handleOfficialFilterChange}
                                />
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="flex-1 min-h-0 animate-in fade-in slide-in-from-right-4">
                        <ReconciliationsHistoryView matches={reconciliationResult?.matches || []} allTransactions={[...props.transactions, ...bankTransactions]} onUnlock={handleUnlockMatch} onDelete={handleDeleteMatch} />
                    </div>
                )}
            </div>
            {selectedForReconciliation && (
                <ReconciliationModal isOpen={isReconciliationModalOpen} selectedTransaction={selectedForReconciliation} candidates={reconciliationCandidates} onConfirm={handleConfirmReconciliation} onSkip={handleSkipReconciliation} onCancel={closeModal} onScrollToCandidate={(id) => setHighlightedCandidateId(id)} batchInfo={reconciliationQueue.length > 0 ? { current: currentQueueIndex + 1, total: reconciliationQueue.length } : undefined} />
            )}
        </>
    );
};

export default ConciliacionesView;
