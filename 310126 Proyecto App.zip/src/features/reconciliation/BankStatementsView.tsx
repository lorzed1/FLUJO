import React, { useState, useMemo } from 'react';
import { Transaction, TransactionType } from '../../types';
import {
    TrashIcon, ArrowDownTrayIcon, MagnifyingGlassIcon, ChevronUpIcon, ChevronDownIcon,
    EyeIcon, FunnelIcon
} from '../../components/ui/Icons';
import { formatCOP } from '../../components/ui/Input';
import { formatDateToDisplay } from '../../utils/dateUtils';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SmartDataTable, Column } from '../../components/ui/SmartDataTable';
import { LabeledField } from '../../components/ui/LabeledField';
import { CalendarDaysIcon } from '../../components/ui/Icons';

interface BankStatementsViewProps {
    transactions?: Transaction[];
    onDelete?: (id: string) => void;
    selectedIds?: Set<string>;
    onSelectionChange?: (ids: Set<string>) => void;
    onRowClick?: (transaction: Transaction) => void;
    // Props para sincronización
    externalFilters?: {
        dateRange?: { start: string; end: string };
        selectedMonth?: string;
        selectedYear?: string;
        typeFilter?: string[];
        sortField?: string;
        sortDirection?: 'asc' | 'desc';
        selectedBankAccountName?: string;
    };
    onFilterChange?: (filters: any) => void;
}

type SortField = keyof Transaction | 'amount';
type SortDirection = 'asc' | 'desc';

const BankStatementsView: React.FC<BankStatementsViewProps> = ({
    transactions = [],
    onDelete,
    selectedIds: propSelectedIds,
    onSelectionChange,
    onRowClick,
    externalFilters,
    onFilterChange
}) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [sortField, setSortField] = useState<SortField>('date');
    const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

    // --- NUEVOS ESTADOS PARA FUNCIONALIDADES AVANZADAS (IGUAL QUE LADO B) ---
    const [localSelectedIds, setLocalSelectedIds] = useState<Set<string>>(new Set());
    const selectedIds = propSelectedIds || localSelectedIds;
    const setSelectedIds = onSelectionChange || setLocalSelectedIds;
    const [showColumnSelector, setShowColumnSelector] = useState(false);
    const [showExportOptions, setShowExportOptions] = useState(false);

    // --- ESTADOS DE FECHAS ---
    const [dateRange, setDateRange] = useState<{ start: string; end: string }>({ start: '', end: '' });
    const [selectedMonth, setSelectedMonth] = useState<string>('');
    const [selectedYear, setSelectedYear] = useState<string>('');

    // --- ESTADO PARA ETIQUETAS ---
    const [transactionTags, setTransactionTags] = useState<Record<string, string[]>>({});

    // --- COLUMNAS DEL LADO A ---
    const initialColumns = [
        { key: 'date' as const, label: 'Fecha', width: 'w-32', visible: true },
        { key: 'type' as const, label: 'Tipo', width: 'w-24', visible: true, align: 'text-center' },
        { key: 'description' as const, label: 'Descripción', width: 'w-auto', visible: true },
        { key: 'metadata.documento' as const, label: 'Referencia', width: 'w-32', visible: true },
        { key: 'amount' as const, label: 'Valor', width: 'w-48', visible: true, align: 'text-right' },
        { key: 'tags' as const, label: 'Etiquetas', width: 'w-40', visible: true },
        { key: 'status' as const, label: 'Estado', width: 'w-24', visible: true, align: 'text-center' },
    ];


    const [visibleColumns, setVisibleColumns] = useState<Record<string, boolean>>(() => {
        // Podríamos persistir esto en localStorage si quisiéramos
        return initialColumns.reduce((acc, col) => ({ ...acc, [col.key]: col.visible }), {});
    });

    const columns = initialColumns.filter(col => visibleColumns[col.key]);

    const toggleColumn = (key: string) => {
        setVisibleColumns(prev => ({ ...prev, [key]: !prev[key] }));
    };

    // --- HELPERS PARA FECHAS ---
    const months = [
        { value: '01', label: 'Enero' }, { value: '02', label: 'Febrero' },
        { value: '03', label: 'Marzo' }, { value: '04', label: 'Abril' },
        { value: '05', label: 'Mayo' }, { value: '06', label: 'Junio' },
        { value: '07', label: 'Julio' }, { value: '08', label: 'Agosto' },
        { value: '09', label: 'Septiembre' }, { value: '10', label: 'Octubre' },
        { value: '11', label: 'Noviembre' }, { value: '12', label: 'Diciembre' }
    ];

    const availableYears = useMemo(() => {
        const years = new Set<string>();
        transactions.forEach(t => {
            const year = t.date.split('-')[0];
            if (year) years.add(year);
        });
        if (years.size === 0) years.add(new Date().getFullYear().toString());
        return Array.from(years).sort((a, b) => b.localeCompare(a));
    }, [transactions]);

    const [localActiveFilters, setLocalActiveFilters] = useState<Record<string, string[]>>({});
    const mergedActiveFilters = useMemo(() => {
        const filters = { ...localActiveFilters };
        if (externalFilters?.typeFilter) {
            // Sincronizar con los valores 'INGRESO' / 'EGRESO' que vienen del estado compartido
            filters.type = externalFilters.typeFilter.map(t => t.toUpperCase());
        }
        return filters;
    }, [localActiveFilters, externalFilters?.typeFilter]);

    const handleFilterChange = (next: Record<string, string[]>) => {
        setLocalActiveFilters(next);
        if (onFilterChange) {
            // Enviar siempre el tipo de filtro, incluso si está vacío, para que la sincronización (LINK) funcione al limpiar
            onFilterChange({ typeFilter: next.type || [] });
        }
    };



    // --- PROCESAMIENTO DE TRANSACCIONES ---
    const processedTransactions = useMemo(() => {
        let result = [...transactions];

        // Rango de Fechas
        const currentRange = externalFilters?.dateRange || dateRange;
        if (currentRange.start) result = result.filter(t => t.date >= currentRange.start);
        if (currentRange.end) result = result.filter(t => t.date <= currentRange.end);

        // Mes y Año
        const currentMonth = externalFilters?.selectedMonth !== undefined ? externalFilters.selectedMonth : selectedMonth;
        const currentYear = externalFilters?.selectedYear !== undefined ? externalFilters.selectedYear : selectedYear;

        if (currentMonth) result = result.filter(t => t.date.split('-')[1] === currentMonth);
        if (currentYear) result = result.filter(t => t.date.startsWith(currentYear));

        return result;
    }, [transactions, dateRange, selectedMonth, selectedYear, externalFilters]);

    // Definición de Columnas para SmartDataTable
    const smartColumns: Column<Transaction>[] = [
        {
            key: 'date',
            label: 'Fecha',
            width: 'w-32',
            sortable: true,
            render: (val) => <span className="text-slate-500 dark:text-gray-400">{formatDateToDisplay(val)}</span>
        },
        {
            key: 'type',
            label: 'Tipo',
            width: 'w-24',
            align: 'text-center',
            sortable: true,
            filterable: true,
            render: (val, t) => {
                // Determinar el tipo usando la misma lógica que getValue
                let displayType = '';
                const type = (val || '').toString().toUpperCase();

                if (type === 'INCOME' || type === 'INGRESO') {
                    displayType = 'INGRESO';
                } else if (type === 'EXPENSE' || type === 'EGRESO') {
                    displayType = 'EGRESO';
                } else {
                    // Inferir desde metadata si no hay tipo
                    const debit = Math.abs(t.metadata?.debit || 0);
                    const credit = Math.abs(t.metadata?.credit || 0);

                    if (debit > 0) displayType = 'EGRESO';
                    else if (credit > 0) displayType = 'INGRESO';
                    else displayType = 'PENDIENTE';
                }

                const isIncome = displayType === 'INGRESO';
                const isExpense = displayType === 'EGRESO';

                return (
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider ${isIncome ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : isExpense ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-gray-100 text-gray-500 dark:bg-slate-700 dark:text-gray-400'}`}>
                        {isIncome ? '↑ ING' : isExpense ? '↓ EGR' : 'PEND'}
                    </span>
                );
            },
            getValue: (t) => {
                // Primero intentar con el campo 'type' si existe
                const type = (t.type || '').toString().toUpperCase();
                if (type === 'INCOME' || type === 'INGRESO') return 'INGRESO';
                if (type === 'EXPENSE' || type === 'EGRESO') return 'EGRESO';

                // Si no tiene tipo, inferir desde metadata (para transacciones importadas antiguas)
                const debit = Math.abs(t.metadata?.debit || 0);
                const credit = Math.abs(t.metadata?.credit || 0);

                if (debit > 0) return 'EGRESO';
                if (credit > 0) return 'INGRESO';

                return 'PENDIENTE';
            }
        },
        {
            key: 'description',
            label: 'Descripción',
            width: 'w-auto',
            sortable: true,
            render: (val) => <span className="text-slate-700 dark:text-gray-200 block truncate max-w-[250px]" title={val}>{val}</span>
        },
        {
            key: 'metadata.documento' as any,
            label: 'Referencia',
            width: 'w-32',
            getValue: (t) => t.metadata?.documento || '',
            render: (val) => <span className="text-blue-600 dark:text-blue-400 font-semibold">{val || '-'}</span>
        },
        {
            key: 'amount',
            label: 'Valor',
            width: 'w-48',
            align: 'text-right',
            sortable: true,
            render: (_, tx) => {
                // Determinar el tipo usando la misma lógica de inferencia
                let isExpense = false;
                const type = (tx.type || '').toString().toUpperCase();

                if (type === 'EXPENSE' || type === 'EGRESO') {
                    isExpense = true;
                } else if (type === 'INCOME' || type === 'INGRESO') {
                    isExpense = false;
                } else {
                    // Inferir desde metadata si no hay tipo
                    const debit = Math.abs(tx.metadata?.debit || 0);
                    const credit = Math.abs(tx.metadata?.credit || 0);
                    isExpense = debit > 0;
                }

                const displayAmount = isExpense ? -tx.amount : tx.amount;
                return (
                    <span className={`font-semibold tabular-nums ${isExpense ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                        {formatCOP(displayAmount)}
                    </span>
                );
            }
        },
        {
            key: 'tags' as any,
            label: 'Etiquetas',
            width: 'w-48',
            render: (_, tx) => (
                <div className="flex flex-wrap gap-1 items-center max-w-[200px]">
                    {(transactionTags[tx.id] || []).map((tag, i) => (
                        <span key={i} className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full text-[10px] font-bold">
                            {tag}
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setTransactionTags(prev => ({
                                        ...prev,
                                        [tx.id]: (prev[tx.id] || []).filter((_, idx) => idx !== i)
                                    }));
                                }}
                                className="hover:text-red-500 transition-colors"
                            >×</button>
                        </span>
                    ))}
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            const newTag = prompt('Nueva etiqueta:');
                            if (newTag && newTag.trim()) {
                                setTransactionTags(prev => ({
                                    ...prev,
                                    [tx.id]: [...(prev[tx.id] || []), newTag.trim()]
                                }));
                            }
                        }}
                        className="text-[10px] text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 font-bold"
                    >+ Añadir</button>
                </div>
            )
        },
        {
            key: 'status',
            label: 'Estado',
            width: 'w-24',
            align: 'text-center',
            render: () => (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-black bg-gray-100 dark:bg-slate-700 text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Pendiente
                </span>
            )
        }
    ];

    const toggleSelectAll = () => {
        if (selectedIds.size === processedTransactions.length) setSelectedIds(new Set());
        else setSelectedIds(new Set(processedTransactions.map(t => t.id)));
    };

    const handleBulkDelete = () => {
        if (!onDelete) return;
        if (confirm(`¿Eliminar ${selectedIds.size} registros importados?`)) {
            selectedIds.forEach(id => onDelete(id));
            setSelectedIds(new Set());
        }
    };

    // --- EXPORTACIÓN ---
    const getExportData = () => {
        const data = selectedIds.size > 0
            ? processedTransactions.filter(t => selectedIds.has(t.id))
            : processedTransactions;
        return data.map(t => ({
            Fecha: t.date,
            Tipo: t.type === 'income' ? 'Ingreso' : 'Egreso',
            Descripción: t.description,
            Referencia: t.metadata?.documento || '',
            Valor: t.type === 'expense' ? -t.amount : t.amount,
            Etiquetas: (transactionTags[t.id] || []).join(', '),
            Estado: 'Pendiente'
        }));
    };

    const exportToExcel = () => {
        const data = getExportData();
        const ws = XLSX.utils.json_to_sheet(data);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Extractos Bancarios");
        XLSX.writeFile(wb, `extractos_${new Date().toISOString().split('T')[0]}.xlsx`);
    };

    const exportToPDF = () => {
        const doc = new jsPDF();
        const data = getExportData();
        const headers = Object.keys(data[0]);
        const rows = data.map(row => Object.values(row));
        doc.text('Extractos Bancarios', 14, 15);
        autoTable(doc, {
            head: [headers],
            body: rows,
            startY: 25,
            theme: 'grid',
            headStyles: { fillColor: [79, 70, 229] }
        });
        doc.save(`extractos_${new Date().toISOString().split('T')[0]}.pdf`);
    };

    const exportToCSV = () => {
        const data = getExportData();
        const headers = Object.keys(data[0]);
        const csvContent = [headers.join(','), ...data.map(r => headers.map(h => (r as any)[h]).join(','))].join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `extractos_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
    };

    return (
        <div className="space-y-2 h-full flex flex-col">
            {/* TABLA DE EXTRACTOS IMPORTADOS */}
            <div className="flex-1 min-h-0">
                <SmartDataTable
                    data={processedTransactions}
                    columns={smartColumns}
                    containerClassName="h-full"
                    enableSearch={true}
                    enableSelection={true}
                    enableExport={true}
                    selectedIds={selectedIds}
                    onSelectionChange={setSelectedIds}
                    activeFilters={mergedActiveFilters}
                    onFilterChange={handleFilterChange}
                    searchTerm={searchTerm}
                    onSearchChange={setSearchTerm}
                    sortConfig={{ key: externalFilters?.sortField || sortField, direction: externalFilters?.sortDirection || sortDirection }}
                    onSortChange={(config) => {
                        setSortField(config.key as SortField);
                        setSortDirection(config.direction);
                        if (onFilterChange) {
                            onFilterChange({ sortField: config.key, sortDirection: config.direction });
                        }
                    }}
                    onRowClick={onRowClick}
                    onBulkDelete={handleBulkDelete}
                    renderExtraFilters={() => (
                        <div className="flex items-center gap-2">
                            {/* Rango Fechas */}
                            <div className="flex items-center gap-2">
                                <LabeledField
                                    label="Fecha inicial"
                                    icon={<CalendarDaysIcon className="h-4 w-4" />}
                                    className="w-40"
                                >
                                    <input
                                        type="date"
                                        value={externalFilters?.dateRange?.start ?? dateRange.start}
                                        onChange={e => {
                                            const newRange = { ...dateRange, start: e.target.value };
                                            setDateRange(newRange);
                                            onFilterChange?.({ dateRange: newRange });
                                        }}
                                        className="w-full bg-transparent border-none p-0 text-[13px] font-semibold text-slate-700 dark:text-gray-200 focus:ring-0 uppercase"
                                    />
                                </LabeledField>
                                <LabeledField
                                    label="Fecha final"
                                    icon={<CalendarDaysIcon className="h-4 w-4" />}
                                    className="w-40"
                                >
                                    <input
                                        type="date"
                                        value={externalFilters?.dateRange?.end ?? dateRange.end}
                                        onChange={e => {
                                            const newRange = { ...dateRange, end: e.target.value };
                                            setDateRange(newRange);
                                            onFilterChange?.({ dateRange: newRange });
                                        }}
                                        className="w-full bg-transparent border-none p-0 text-[13px] font-semibold text-slate-700 dark:text-gray-200 focus:ring-0 uppercase"
                                    />
                                </LabeledField>
                            </div>

                            {/* Mes / Año */}
                            <div className="flex items-center gap-1 bg-indigo-50 dark:bg-indigo-900/30 p-1 rounded-xl border border-indigo-100 dark:border-indigo-800 flex-shrink-0">
                                <select
                                    value={externalFilters?.selectedMonth ?? selectedMonth}
                                    onChange={e => {
                                        setSelectedMonth(e.target.value);
                                        onFilterChange?.({ selectedMonth: e.target.value });
                                    }}
                                    className="text-[10px] font-black bg-transparent border-none focus:ring-0 text-indigo-700 dark:text-indigo-300 cursor-pointer py-1 pl-2 pr-6 uppercase tracking-tight"
                                >
                                    <option value="">MES</option>
                                    {months.map(m => <option key={m.value} value={m.value} className="dark:bg-slate-800">{m.label.substring(0, 3)}</option>)}
                                </select>
                                <div className="h-4 w-px bg-indigo-200 dark:bg-indigo-700"></div>
                                <select
                                    value={externalFilters?.selectedYear ?? selectedYear}
                                    onChange={e => {
                                        setSelectedYear(e.target.value);
                                        onFilterChange?.({ selectedYear: e.target.value });
                                    }}
                                    className="text-[10px] font-black bg-transparent border-none focus:ring-0 text-indigo-700 dark:text-indigo-300 cursor-pointer py-1 pl-2 pr-6 uppercase tracking-tight"
                                >
                                    <option value="">AÑO</option>
                                    {availableYears.map(y => <option key={y} value={y} className="dark:bg-slate-800">{y}</option>)}
                                </select>
                            </div>
                        </div>
                    )}
                />
            </div>
        </div>
    );
};

export default BankStatementsView;
