import React, { useState, useMemo } from 'react';
import {
  ChartBarIcon,
  BanknotesIcon,
  ArrowTrendingUpIcon,
  CreditCardIcon,
  CalendarDaysIcon,
  UserIcon,
  UsersIcon,
  CalendarIcon
} from '../../components/ui/Icons';
import { Transaction, TransactionType } from '../../types';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell, Legend, ComposedChart, PieChart, Pie
} from 'recharts';

interface DashboardViewProps {
  projectedTransactions: Transaction[];
  realTransactions: Transaction[];
  categories: any[];
  arqueos?: any[];
}

type DashboardTab = 'analytics' | 'financial';
type PeriodMode = 'month' | 'year' | 'yearWeeks' | 'range';
type ViewMode = 'projected' | 'real';
const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f97316', '#10b981', '#3b82f6'];
const DAYS_OF_WEEK = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

const DashboardView: React.FC<DashboardViewProps> = ({
  projectedTransactions,
  realTransactions,
  categories,
  arqueos = []
}) => {
  const [activeTab, setActiveTab] = useState<DashboardTab>('analytics');
  const [analyticsView, setAnalyticsView] = useState<'daily' | 'weekly' | 'monthly' | 'yearly' | 'yoy'>('daily');
  const [analyticsMetric, setAnalyticsMetric] = useState<'sales' | 'visits' | 'both'>('sales');
  const [filterWeekday, setFilterWeekday] = useState<number | null>(null);
  const [filterWeek, setFilterWeek] = useState<number | null>(null);
  const [showCompare, setShowCompare] = useState(false);
  const [compareMonth, setCompareMonth] = useState<number>(new Date().getMonth());
  const [compareYear, setCompareYear] = useState<number>(new Date().getFullYear() - 1);

  // Estados para Finanzas
  const [viewMode, setViewMode] = useState<ViewMode>('projected');
  const [periodMode, setPeriodMode] = useState<PeriodMode>('month');
  const transactions = viewMode === 'projected' ? projectedTransactions : realTransactions;
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(value);

  const months = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  const analyticsData = useMemo(() => {
    if (!arqueos || arqueos.length === 0) return null;

    const dataset = arqueos.filter(a => {
      const d = new Date(a.fecha + 'T12:00:00');
      const monthMatch = d.getMonth() === selectedMonth && d.getFullYear() === selectedYear;
      const weekdayMatch = filterWeekday === null || ((d.getDay() + 6) % 7) === filterWeekday;
      const weekMatch = filterWeek === null || Math.ceil(d.getDate() / 7) === filterWeek;
      return monthMatch && weekdayMatch && weekMatch;
    });

    const totalSales = dataset.reduce((sum, a) => sum + (a.totalRecaudado || 0), 0);
    const totalVisits = dataset.reduce((sum, a) => sum + (a.visitas || 0), 0);
    const avgTicket = totalVisits > 0 ? totalSales / totalVisits : 0;

    const dataByDayMap = dataset.reduce((acc, curr) => {
      const d = new Date(curr.fecha + 'T12:00:00');
      const day = d.getDate().toString();
      if (!acc[day]) acc[day] = { sales: 0, visits: 0, date: curr.fecha };
      acc[day].sales += curr.totalRecaudado || 0;
      acc[day].visits += curr.visitas || 0;
      return acc;
    }, {} as Record<string, { sales: number; visits: number; date: string }>);

    const compDataset = showCompare ? arqueos.filter(a => {
      const d = new Date(a.fecha + 'T12:00:00');
      const monthMatch = d.getMonth() === compareMonth && d.getFullYear() === compareYear;
      const weekdayMatch = filterWeekday === null || ((d.getDay() + 6) % 7) === filterWeekday;
      const weekMatch = filterWeek === null || Math.ceil(d.getDate() / 7) === filterWeek;
      return monthMatch && weekdayMatch && weekMatch;
    }).sort((a, b) => a.fecha.localeCompare(b.fecha)) : [];

    const salesByDayData = Object.keys(dataByDayMap).sort((a, b) => parseInt(a) - parseInt(b)).map((day, idx) => {
      const base: any = {
        name: filterWeekday !== null ? `Sem ${idx + 1}` : day,
        amount: dataByDayMap[day].sales,
        visits: dataByDayMap[day].visits,
        fullDate: dataByDayMap[day].date
      };

      if (showCompare && compDataset[idx]) {
        base['amountComp'] = compDataset[idx].totalRecaudado || 0;
        base['visitsComp'] = compDataset[idx].visitas || 0;
        base['compDate'] = compDataset[idx].fecha;
      }
      return base;
    });

    const paymentMethods = dataset.reduce((acc, curr) => ({
      efectivo: acc.efectivo + (curr.efectivo || 0),
      nequi: acc.nequi + (curr.nequi || 0),
      daviplata: acc.daviplata + (curr.daviplata || 0) + (curr.datafonoDavid || 0),
      bancolombia: acc.bancolombia + (curr.transfBancolombia || 0),
      datafono: acc.datafono + (curr.datafonoJulian || 0),
      rappi: acc.rappi + (curr.rappi || 0),
    }), { efectivo: 0, nequi: 0, daviplata: 0, bancolombia: 0, datafono: 0, rappi: 0 });

    const paymentMixData = [
      { name: 'Efectivo', value: paymentMethods.efectivo },
      { name: 'Nequi', value: paymentMethods.nequi },
      { name: 'Davi/Bancol.', value: paymentMethods.daviplata + paymentMethods.bancolombia },
      { name: 'Datáfonos', value: paymentMethods.datafono },
      { name: 'Rappi', value: paymentMethods.rappi },
    ].filter(i => i.value > 0);

    const daysOfWeek = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
    const salesByWeekday = dataset.reduce((acc, curr) => {
      const d = new Date(curr.fecha + 'T12:00:00');
      const dayIndex = (d.getDay() + 6) % 7;
      if (!acc[dayIndex]) acc[dayIndex] = { count: 0, total: 0, visits: 0 };
      acc[dayIndex].count += 1;
      acc[dayIndex].total += curr.totalRecaudado;
      acc[dayIndex].visits += curr.visitas || 0;
      return acc;
    }, {} as Record<number, { count: number, total: number, visits: number }>);

    const weekdayData = daysOfWeek.map((day, index) => {
      const stats = salesByWeekday[index];
      const totalValue = stats ? (analyticsMetric === 'sales' ? stats.total : stats.visits) : 0;
      const avgValue = stats && stats.count > 0 ? totalValue / stats.count : 0;
      return {
        name: day.slice(0, 3),
        full: day,
        total: totalValue,
        avg: avgValue,
        count: stats ? stats.count : 0
      };
    });

    const currentYearMonths = months.map((m, mIdx) => {
      const data: any = { name: m.slice(0, 3) };
      const total = arqueos.filter(a => {
        const d = new Date(a.fecha + 'T12:00:00');
        return d.getFullYear() === selectedYear && d.getMonth() === mIdx;
      }).reduce((sum, a) => ({
        sales: sum.sales + (a.totalRecaudado || 0),
        visits: sum.visits + (a.visitas || 0)
      }), { sales: 0, visits: 0 });
      data.sales = total.sales;
      data.visits = total.visits;
      if (compareYear !== null) {
        const compTotal = arqueos.filter(a => {
          const d = new Date(a.fecha + 'T12:00:00');
          return d.getFullYear() === compareYear && d.getMonth() === mIdx;
        }).reduce((sum, a) => ({
          sales: sum.sales + (a.totalRecaudado || 0),
          visits: sum.visits + (a.visitas || 0)
        }), { sales: 0, visits: 0 });
        data.salesComp = compTotal.sales;
        data.visitsComp = compTotal.visits;
      }
      return data;
    });

    const yearsMap: Record<number, { sales: number; visits: number }> = {};
    arqueos.forEach(a => {
      const year = new Date(a.fecha + 'T12:00:00').getFullYear();
      if (!yearsMap[year]) yearsMap[year] = { sales: 0, visits: 0 };
      yearsMap[year].sales += a.totalRecaudado || 0;
      yearsMap[year].visits += a.visitas || 0;
    });

    const yearlyHistoryData = Object.keys(yearsMap).sort().map(y => ({
      name: y,
      amount: yearsMap[parseInt(y)].sales,
      visits: yearsMap[parseInt(y)].visits
    }));

    const intraMonthComparisonData = daysOfWeek.map((dayName, idx) => {
      const dayData: any = { name: dayName };
      dataset.filter(a => ((new Date(a.fecha + 'T12:00:00').getDay() + 6) % 7) === idx)
        .sort((a, b) => a.fecha.localeCompare(b.fecha))
        .forEach((a, i) => {
          dayData[`Semana ${i + 1}`] = analyticsMetric === 'sales' ? a.totalRecaudado : a.visitas;
        });
      return dayData;
    });

    const availableYears = Array.from(new Set(arqueos.map(a => new Date(a.fecha + 'T12:00:00').getFullYear()))).sort();
    const yoyData = months.map((m, mIdx) => {
      const data: any = { name: m.slice(0, 3) };
      availableYears.forEach(y => {
        data[y] = arqueos.filter(a => {
          const d = new Date(a.fecha + 'T12:00:00');
          return d.getFullYear() === y && d.getMonth() === mIdx;
        }).reduce((sum, a) => sum + (analyticsMetric === 'sales' ? (a.totalRecaudado || 0) : (a.visitas || 0)), 0);
      });
      return data;
    });

    return {
      totalSales, totalVisits, avgTicket,
      daysWithSales: dataset.length,
      salesByDayData,
      monthlyHistoryData: currentYearMonths,
      yearlyHistoryData,
      intraMonthComparisonData,
      yoyData,
      availableYears,
      paymentMixData,
      weekdayData,
      comparisonData: showCompare ? daysOfWeek.map((dayName, idx) => {
        const dayData: any = { name: dayName };
        arqueos.filter(a => {
          const d = new Date(a.fecha + 'T12:00:00');
          return d.getMonth() === compareMonth && d.getFullYear() === compareYear && ((d.getDay() + 6) % 7) === idx;
        }).sort((a, b) => a.fecha.localeCompare(b.fecha))
          .forEach((a, i) => {
            dayData[`Semana ${i + 1} (Comp)`] = analyticsMetric === 'sales' ? a.totalRecaudado : a.visitas;
          });
        return dayData;
      }) : null
    };
  }, [arqueos, selectedMonth, selectedYear, analyticsMetric, compareMonth, compareYear, filterWeekday, filterWeek, showCompare]);

  const chartData = useMemo(() => {
    let data: any[] = [];
    let runningBalance = 0;
    if (periodMode === 'month') {
      const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();
      for (let i = 1; i <= daysInMonth; i++) {
        const dStr = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
        const dayIn = transactions.filter(t => t.date === dStr && t.type === TransactionType.INCOME).reduce((s, t) => s + t.amount, 0);
        const dayOut = transactions.filter(t => t.date === dStr && t.type === TransactionType.EXPENSE).reduce((s, t) => s + t.amount, 0);
        runningBalance += (dayIn - dayOut);
        data.push({ name: i.toString(), income: dayIn, expense: dayOut, balance: runningBalance });
      }
    } else if (periodMode === 'year') {
      for (let i = 0; i < 12; i++) {
        const mIn = transactions.filter(t => {
          const d = new Date(t.date + 'T00:00:00');
          return d.getFullYear() === selectedYear && d.getMonth() === i && t.type === TransactionType.INCOME;
        }).reduce((s, t) => s + t.amount, 0);
        const mOut = transactions.filter(t => {
          const d = new Date(t.date + 'T00:00:00');
          return d.getFullYear() === selectedYear && d.getMonth() === i && t.type === TransactionType.EXPENSE;
        }).reduce((s, t) => s + t.amount, 0);
        runningBalance += (mIn - mOut);
        data.push({ name: months[i].substring(0, 3), income: mIn, expense: mOut, balance: runningBalance });
      }
    }
    return data;
  }, [transactions, periodMode, selectedYear, selectedMonth]);

  const financialStats = useMemo(() => {
    const income = chartData.reduce((s, d) => s + (d.income || 0), 0);
    const expense = chartData.reduce((s, d) => s + (d.expense || 0), 0);
    return { income, expense, balance: income - expense };
  }, [chartData]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">

      {/* --- Header Section --- */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-white">Panel de Control</h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1 font-medium">
            Visión general del rendimiento operativo y financiero.
          </p>
        </div>

        <div className="flex bg-white dark:bg-slate-800 p-1.5 rounded-xl border border-gray-200 dark:border-slate-700 shadow-sm">
          <Button
            variant={activeTab === 'analytics' ? 'secondary' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('analytics')}
            className={activeTab === 'analytics' ? 'bg-slate-100 dark:bg-slate-700 font-semibold text-slate-800' : ''}
          >
            <ChartBarIcon className="w-4 h-4 mr-2" />
            Analítica
          </Button>
          <Button
            variant={activeTab === 'financial' ? 'secondary' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('financial')}
            className={activeTab === 'financial' ? 'bg-slate-100 dark:bg-slate-700 font-semibold text-slate-800' : ''}
          >
            <BanknotesIcon className="w-4 h-4 mr-2" />
            Finanzas
          </Button>
        </div>
      </div>

      {activeTab === 'analytics' ? (
        <div className="space-y-6">

          {/* --- Toolbar / Filters --- */}
          <Card noPadding className="flex flex-col xl:flex-row justify-between items-center bg-white dark:bg-slate-800 shadow-sm border-gray-100 dark:border-slate-700 p-2 gap-4">

            <div className="flex flex-wrap items-center gap-2 p-2">
              <div className="flex bg-slate-100 dark:bg-slate-700/50 p-1 rounded-lg">
                {[
                  { id: 'daily', label: 'Día' },
                  { id: 'weekly', label: 'Semana' },
                  { id: 'monthly', label: 'Mes' },
                  { id: 'yearly', label: 'Año' },
                  { id: 'yoy', label: 'YoY' }
                ].map(v => (
                  <button
                    key={v.id}
                    onClick={() => setAnalyticsView(v.id as any)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${analyticsView === v.id
                      ? 'bg-white text-primary shadow-sm'
                      : 'text-slate-500 hover:text-slate-700'}`}
                  >
                    {v.label}
                  </button>
                ))}
              </div>

              <div className="h-6 w-px bg-gray-200 mx-2 hidden lg:block" />

              {/* Date Filters */}
              <div className="flex items-center gap-2">
                {analyticsView !== 'yearly' && analyticsView !== 'yoy' && (
                  <Select
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                    className="w-32 h-9 text-xs font-semibold border-gray-200 bg-white"
                  >
                    {months.map((m, i) => <option key={i} value={i}>{m}</option>)}
                  </Select>
                )}
                <Input
                  type="number"
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                  className="w-20 h-9 text-center text-xs font-semibold border-gray-200 bg-white"
                />
              </div>

              {/* Extra Filters (Daily) */}
              {analyticsView === 'daily' && (
                <>
                  <div className="h-6 w-px bg-gray-200 mx-2 hidden lg:block" />
                  <div className="flex items-center gap-2">
                    <Select value={filterWeekday ?? ''} onChange={(e) => setFilterWeekday(e.target.value === '' ? null : parseInt(e.target.value))} className="w-28 h-9 text-xs border-gray-200">
                      <option value="">Todos los Días</option>
                      {DAYS_OF_WEEK.map((d, i) => <option key={i} value={i}>{d}</option>)}
                    </Select>
                  </div>
                </>
              )}
            </div>

            <div className="flex items-center gap-3 px-4">
              {/* Compare Toggle */}
              {analyticsView !== 'yoy' && (
                <div className="flex items-center gap-2">
                  <Button
                    variant={showCompare ? 'primary' : 'outline'}
                    size="sm"
                    onClick={() => setShowCompare(!showCompare)}
                    className="text-xs h-8"
                  >
                    {showCompare ? 'Comparando' : 'Comparar'}
                  </Button>

                  {showCompare && (
                    <div className="flex gap-1 animate-in slide-in-from-left-2 items-center">
                      {analyticsView !== 'monthly' && analyticsView !== 'yearly' && (
                        <Select value={compareMonth} onChange={(e) => setCompareMonth(parseInt(e.target.value))} className="w-24 h-8 text-xs border-orange-200 bg-orange-50/50">
                          {months.map((m, i) => <option key={i} value={i}>{m.slice(0, 3)}</option>)}
                        </Select>
                      )}
                      <Input type="number" value={compareYear} onChange={(e) => setCompareYear(parseInt(e.target.value))} className="w-16 h-8 text-xs text-center border-orange-200 bg-orange-50/50" />
                    </div>
                  )}
                </div>
              )}

              <div className="h-6 w-px bg-gray-200 mx-2 hidden lg:block" />

              {/* Metrics Toggle */}
              <div className="flex bg-slate-100 dark:bg-slate-700/50 p-1 rounded-lg">
                <button onClick={() => setAnalyticsMetric('sales')} className={`p-1.5 rounded-md transition-all ${analyticsMetric === 'sales' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400'}`} title="Ventas"><BanknotesIcon className="w-4 h-4" /></button>
                <button onClick={() => setAnalyticsMetric('visits')} className={`p-1.5 rounded-md transition-all ${analyticsMetric === 'visits' ? 'bg-white text-orange-600 shadow-sm' : 'text-slate-400'}`} title="Visitas"><UsersIcon className="w-4 h-4" /></button>
                <button onClick={() => setAnalyticsMetric('both')} className={`p-1.5 rounded-md transition-all ${analyticsMetric === 'both' ? 'bg-white text-violet-600 shadow-sm' : 'text-slate-400'}`} title="Ambos"><ArrowTrendingUpIcon className="w-4 h-4" /></button>
              </div>
            </div>

          </Card>

          {!analyticsData ? (
            <Card className="py-20 text-center border-dashed">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-50 mb-4">
                <CalendarIcon className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-slate-500 font-medium">No hay datos para el periodo seleccionado.</p>
            </Card>
          ) : (
            <>
              {/* KPIs Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                {[
                  { label: 'Ventas Totales', value: formatCurrency(analyticsData.totalSales), icon: BanknotesIcon, color: 'text-indigo-600', bg: 'bg-indigo-50' },
                  { label: 'Visitas', value: `${analyticsData.totalVisits} Pax`, icon: UsersIcon, color: 'text-orange-600', bg: 'bg-orange-50' },
                  { label: 'Promedio Diario', value: formatCurrency(analyticsData.daysWithSales > 0 ? analyticsData.totalSales / analyticsData.daysWithSales : 0), icon: ChartBarIcon, color: 'text-violet-600', bg: 'bg-violet-50' },
                  { label: 'Ticket Medio', value: formatCurrency(analyticsData.avgTicket), icon: UserIcon, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                  { label: 'Días Operativos', value: analyticsData.daysWithSales, icon: CalendarIcon, color: 'text-blue-600', bg: 'bg-blue-50' },
                ].map((kpi, i) => (
                  <Card key={i} className="flex flex-col justify-between hover:shadow-md transition-shadow duration-200 border-l-4 border-l-transparent hover:border-l-primary" noPadding={false}>
                    <div className="flex justify-between items-start mb-2">
                      <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest leading-tight">{kpi.label}</p>
                      <div className={`p-1.5 rounded-lg ${kpi.bg}`}>
                        <kpi.icon className={`w-4 h-4 ${kpi.color}`} />
                      </div>
                    </div>
                    <p className="text-xl lg:text-2xl font-semibold text-slate-800 dark:text-white truncate tracking-tight">{kpi.value}</p>
                  </Card>
                ))}
              </div>

              {/* Main Chart */}
              <Card className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-semibold text-slate-800 dark:text-white flex items-center gap-2">
                      Análisis de Evolución
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">Comparativa temporal de ingresos y afluencia</p>
                  </div>
                </div>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    {analyticsView === 'daily' ? (
                      <ComposedChart data={analyticsData.salesByDayData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} dy={10} />
                        <YAxis yAxisId="left" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} tickFormatter={(v) => `$${v / 1000}k`} hide={analyticsMetric === 'visits'} />
                        <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} hide={analyticsMetric === 'sales'} />
                        <Tooltip
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const data = payload[0].payload;
                              return (
                                <div className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-xl border border-gray-100 dark:border-slate-700 text-xs">
                                  <p className="font-semibold text-slate-700 mb-2 border-b pb-1">Día {data.name}</p>
                                  <div className="space-y-1">
                                    <p className="text-indigo-600 font-semibold flex justify-between gap-4"><span>Ventas:</span> <span>{formatCurrency(data.amount)}</span></p>
                                    <p className="text-orange-600 font-semibold flex justify-between gap-4"><span>Visitas:</span> <span>{data.visits} Pax</span></p>
                                    {data.amountComp !== undefined && (
                                      <div className="pt-2 mt-2 border-t border-dashed">
                                        <p className="text-slate-400 flex justify-between gap-4"><span>Comp. Ventas:</span> <span>{formatCurrency(data.amountComp)}</span></p>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Legend wrapperStyle={{ paddingTop: '20px' }} iconType="circle" />

                        {(analyticsMetric === 'sales' || analyticsMetric === 'both') && (
                          <Bar yAxisId="left" dataKey="amount" fill="#6366f1" radius={[4, 4, 0, 0]} name={`Ventas ${selectedYear}`} maxBarSize={50} />
                        )}
                        {(analyticsMetric === 'visits' || analyticsMetric === 'both') && (
                          <Line yAxisId="right" type="monotone" dataKey="visits" stroke="#f97316" strokeWidth={3} dot={{ r: 4, strokeWidth: 2, fill: '#fff' }} name={`Visitas ${selectedYear}`} />
                        )}
                        {showCompare && (
                          <Bar yAxisId="left" dataKey="amountComp" fill="#cbd5e1" radius={[4, 4, 0, 0]} name={`Ventas ${compareYear} (Comp)`} maxBarSize={50} />
                        )}
                        {showCompare && analyticsMetric === 'both' && (
                          <Line yAxisId="right" type="monotone" dataKey="visitsComp" stroke="#94a3b8" strokeWidth={2} strokeDasharray="4 4" dot={{ r: 3 }} name={`Visitas ${compareYear} (Comp)`} />
                        )}
                      </ComposedChart>
                    ) : analyticsView === 'weekly' ? (
                      <LineChart data={showCompare ? analyticsData.intraMonthComparisonData.map((d, i) => ({ ...d, ...analyticsData.comparisonData?.[i] })) : analyticsData.intraMonthComparisonData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} dy={10} />
                        <YAxis tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} tickFormatter={(v) => analyticsMetric === 'sales' ? `$${v / 1000}k` : v} />
                        <Tooltip formatter={(v: any) => analyticsMetric === 'sales' ? formatCurrency(v) : v} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                        <Legend wrapperStyle={{ paddingTop: '20px' }} iconType="circle" />
                        {[1, 2, 3, 4, 5].map(w => (
                          <React.Fragment key={w}>
                            <Line type="monotone" dataKey={`Semana ${w}`} stroke={COLORS[w - 1]} strokeWidth={3} dot={{ r: 4, strokeWidth: 2, fill: '#fff' }} name={`Sem ${w} (${selectedYear})`} connectNulls />
                            {showCompare && <Line type="monotone" dataKey={`Semana ${w} (Comp)`} stroke={COLORS[w - 1]} strokeWidth={2} strokeDasharray="4 4" opacity={0.5} dot={false} name={`Sem ${w} (${compareYear})`} connectNulls />}
                          </React.Fragment>
                        ))}
                      </LineChart>
                    ) : analyticsView === 'monthly' ? (
                      <BarChart data={analyticsData.monthlyHistoryData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} dy={10} />
                        <YAxis tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} tickFormatter={(v) => analyticsMetric === 'sales' ? `$${v / 1000}k` : v} />
                        <Tooltip formatter={(v: any) => analyticsMetric === 'sales' ? formatCurrency(v) : v} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                        <Legend wrapperStyle={{ paddingTop: '20px' }} iconType="circle" />
                        <Bar dataKey={analyticsMetric === 'sales' ? 'sales' : 'visits'} fill="#6366f1" name={selectedYear.toString()} radius={[4, 4, 0, 0]} maxBarSize={60} />
                        {showCompare && <Bar dataKey={analyticsMetric === 'sales' ? 'salesComp' : 'visitsComp'} fill="#cbd5e1" name={compareYear.toString()} radius={[4, 4, 0, 0]} maxBarSize={60} />}
                      </BarChart>
                    ) : analyticsView === 'yearly' ? (
                      <BarChart data={analyticsData.yearlyHistoryData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} dy={10} />
                        <YAxis tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} tickFormatter={(v) => analyticsMetric === 'sales' ? `$${v / 1000}k` : v} />
                        <Tooltip formatter={(v: any) => analyticsMetric === 'sales' ? formatCurrency(v) : v} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                        <Bar dataKey={analyticsMetric === 'sales' ? 'amount' : 'visits'} fill="#4f46e5" radius={[4, 4, 0, 0]} maxBarSize={60} />
                      </BarChart>
                    ) : (
                      <LineChart data={analyticsData.yoyData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} dy={10} />
                        <YAxis tick={{ fontSize: 11, fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} tickFormatter={(v) => analyticsMetric === 'sales' ? `$${(v / 1000000).toFixed(1)}M` : v} />
                        <Tooltip formatter={(v: any) => analyticsMetric === 'sales' ? formatCurrency(v) : v} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                        <Legend wrapperStyle={{ paddingTop: '20px' }} iconType="circle" />
                        {analyticsData.availableYears.map((y, idx) => (<Line key={y} type="monotone" dataKey={y} stroke={COLORS[idx % COLORS.length]} strokeWidth={3} dot={{ r: 4, strokeWidth: 2, fill: '#fff' }} name={y.toString()} />))}
                      </LineChart>
                    )}
                  </ResponsiveContainer>
                </div>
              </Card>

              {/* Secondary Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card>
                  <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-6">Mix de Pagos</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie data={analyticsData.paymentMixData} innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value" stroke="none">
                          {analyticsData.paymentMixData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                        </Pie>
                        <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                        <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '11px', fontWeight: '500', color: '#64748B' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                <Card className="lg:col-span-2">
                  <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-6">Promedio por Día de Semana</h3>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={analyticsData.weekdayData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11, fontWeight: 'bold', fill: '#64748B' }} stroke="#94A3B8" axisLine={false} tickLine={false} dy={5} />
                        <Tooltip
                          cursor={{ fill: '#f1f5f9' }}
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                          formatter={(v: number, name: string) => [
                            name === 'avg' ? (analyticsMetric === 'sales' ? formatCurrency(v) : `${v.toFixed(1)} Pax`) : v,
                            name === 'avg' ? 'Promedio' : name
                          ]}
                        />
                        <Bar dataKey="avg" fill="#e0e7ff" radius={[4, 4, 4, 4]} barSize={40}>
                          {analyticsData.weekdayData.map((e, i) => (
                            <Cell key={i} fill={e.avg > 0 ? '#6366f1' : '#f1f5f9'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="grid grid-cols-7 gap-2 mt-4">
                    {analyticsData.weekdayData.map(d => (
                      <div key={d.full} className="text-center p-2 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                        <p className="text-[9px] font-semibold text-slate-400 mb-1">{d.name.toUpperCase()}</p>
                        <p className="text-[10px] font-semibold text-indigo-600 dark:text-blue-400">
                          {analyticsMetric === 'sales' ? `$${(d.avg / 1000).toFixed(0)}k` : d.avg.toFixed(1)}
                        </p>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            </>
          )}
        </div>
      ) : (
        /* --- Financial View --- */
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <Card noPadding className="flex justify-between items-center p-2 bg-white dark:bg-slate-800 shadow-sm border-gray-100 dark:border-slate-700">
            <div className="bg-slate-100 dark:bg-slate-700 p-1 rounded-lg flex gap-1">
              <Button variant={viewMode === 'projected' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('projected')} className={viewMode === 'projected' ? 'bg-white shadow-sm text-indigo-600' : ''}>Proyecciones</Button>
              <Button variant={viewMode === 'real' ? 'secondary' : 'ghost'} size="sm" onClick={() => setViewMode('real')} className={viewMode === 'real' ? 'bg-white shadow-sm text-emerald-600' : ''}>Ejecución</Button>
            </div>
            <div className="flex gap-2 px-2">
              <Select value={selectedMonth} onChange={(e) => setSelectedMonth(parseInt(e.target.value))} className="w-32 h-9 text-xs font-semibold border-gray-200">
                {months.map((m, i) => <option key={i} value={i}>{m}</option>)}
              </Select>
              <Input type="number" value={selectedYear} onChange={(e) => setSelectedYear(parseInt(e.target.value))} className="w-20 h-9 text-center text-xs font-semibold border-gray-200" />
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="flex flex-col justify-center bg-emerald-50/50 border-emerald-100">
              <p className="text-xs font-semibold text-emerald-600 uppercase mb-2 tracking-wider">Ingresos</p>
              <p className="text-3xl font-semibold text-emerald-700 tracking-tight">{formatCurrency(financialStats.income)}</p>
            </Card>
            <Card className="flex flex-col justify-center bg-rose-50/50 border-rose-100">
              <p className="text-xs font-semibold text-rose-600 uppercase mb-2 tracking-wider">Egresos</p>
              <p className="text-3xl font-semibold text-rose-700 tracking-tight">{formatCurrency(financialStats.expense)}</p>
            </Card>
            <Card className={`flex flex-col justify-center border-opacity-50 ${financialStats.balance >= 0 ? 'bg-indigo-50/50 border-indigo-100' : 'bg-orange-50/50 border-orange-100'}`}>
              <p className={`text-xs font-semibold uppercase mb-2 tracking-wider ${financialStats.balance >= 0 ? 'text-indigo-600' : 'text-orange-600'}`}>Flujo Neto</p>
              <p className={`text-3xl font-semibold tracking-tight ${financialStats.balance >= 0 ? 'text-indigo-700' : 'text-orange-700'}`}>{formatCurrency(financialStats.balance)}</p>
            </Card>
          </div>

          <Card>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold text-slate-800">Flujo de Caja Mensual</h3>
              <div className="flex gap-2 text-xs font-medium text-slate-500">
                <span className="flex items-center gap-1"><div className="w-3 h-3 rounded-full bg-emerald-500" /> Ingresos</span>
                <span className="flex items-center gap-1"><div className="w-3 h-3 rounded-full bg-rose-500" /> Egresos</span>
              </div>
            </div>
            <div className="h-96">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                  <XAxis dataKey="name" fontSize={11} fontWeight="500" stroke="#94A3B8" axisLine={false} tickLine={false} dy={10} />
                  <YAxis fontSize={11} stroke="#94A3B8" axisLine={false} tickLine={false} tickFormatter={(v) => `$${v / 1000}k`} />
                  <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                  <Bar dataKey="income" fill="#10b981" name="Ingresos" radius={[4, 4, 0, 0]} maxBarSize={40} />
                  <Bar dataKey="expense" fill="#f43f5e" name="Egresos" radius={[4, 4, 0, 0]} maxBarSize={40} />
                  <Line type="monotone" dataKey="balance" stroke="#6366f1" strokeWidth={3} dot={false} name="Saldo Acumulado" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default DashboardView;
